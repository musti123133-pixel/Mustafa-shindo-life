-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:32:18
-- Luau version 6, Types version 3
-- Time taken: 0.008083 seconds

local module = {
	idlanim = function() -- Line 7
		return 4855855974
	end;
	combat = function() -- Line 12
		return {9163259265, 9163261514, 9163263408, 9163266028}
	end;
	block = function() -- Line 17
		return 9163269527
	end;
	typ = function() -- Line 21
		return "saber"
	end;
	power = function() -- Line 25
		return 4816744006
	end;
	slicedelay = function() -- Line 29
		return 0.3
	end;
	damage = function() -- Line 32
		return 10
	end;
}
ReplicatedStorage = game.ReplicatedStorage -- Setting global
function module.heavyattack(arg1, arg2) -- Line 41
	if script.stamina.Value <= arg2.stamina2.Value then
		arg2.stamina2.Value = arg2.stamina2.Value - script.stamina.Value
	else
		return script.stamina.Value
	end
	spawn(function() -- Line 52
		--[[ Upvalues[2]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
		]]
		local var12_upvr = arg1
		local any_GetPlayerFromCharacter_result1_upvw = game.Players:GetPlayerFromCharacter(var12_upvr)
		if any_GetPlayerFromCharacter_result1_upvw == nil then
			any_GetPlayerFromCharacter_result1_upvw = var12_upvr
		end
		local module_2_upvr = require(ReplicatedStorage:WaitForChild("GlobalFunctions"))
		local var15_upvw = false
		if module_2_upvr.haspuppet(any_GetPlayerFromCharacter_result1_upvw) then
			var15_upvw = true
		end
		delay(0, function() -- Line 65
			--[[ Upvalues[5]:
				[1]: arg2 (readonly)
				[2]: var12_upvr (readonly)
				[3]: var15_upvw (read and write)
				[4]: module_2_upvr (readonly)
				[5]: any_GetPlayerFromCharacter_result1_upvw (read and write)
			]]
			local IntValue = Instance.new("IntValue")
			IntValue.Parent = arg2
			IntValue.Name = "hyperarmour"
			game.Debris:AddItem(IntValue, 1)
			arg2.heavyhit.Value = true
			local Attachment_2 = Instance.new("Attachment")
			Attachment_2.Parent = var12_upvr["Left Arm"]
			Attachment_2.Position = Vector3.new(0, -0.5, 0)
			local clone_2 = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone_2.Parent = Attachment_2
			clone_2:Emit(4)
			clone_2.Enabled = true
			game.Debris:AddItem(Attachment_2, 0.5)
			local Animation = Instance.new("Animation")
			Animation.AnimationId = "http://www.roblox.com/asset/?id="..9127600000
			arg2.canrunfromslice.Value = true
			local any_LoadAnimation_result1 = var12_upvr.Humanoid:LoadAnimation(Animation)
			if var15_upvw then
				any_LoadAnimation_result1 = var12_upvr.puppet.Humanoid:LoadAnimation(Animation)
			end
			any_LoadAnimation_result1:Play()
			local Attachment = Instance.new("Attachment")
			Attachment.Parent = var12_upvr["Right Arm"]
			Attachment.Position = Vector3.new(0, -0.5, 0)
			local clone = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone.Parent = Attachment
			clone:Emit(4)
			clone.Enabled = true
			game.Debris:AddItem(Attachment, 0.5)
			wait(0.5)
			if var15_upvw then
				for i = 1, 4 do
					wait(0.2)
					local var28 = var12_upvr.puppet.HumanoidRootPart.CFrame * CFrame.new(0, 0, -10 * i * 1.5)
					ReplicatedStorage.fire:FireAllClients(var12_upvr, {var28, 10}, "guitan")
					module_2_upvr.powerdamage(var12_upvr, 2 * (module_2_upvr.getallstats(any_GetPlayerFromCharacter_result1_upvw).taijutsu + 2), "blockbreakpushaway", var28, Vector3.new(50, 50, 50))
				end
			else
				i = 1
				for i_2 = i, 4 do
					wait(0.2)
					local var30 = var12_upvr.HumanoidRootPart.CFrame * CFrame.new(0, 0, -10 * i_2 * 1.5)
					ReplicatedStorage.fire:FireAllClients(var12_upvr, {var30, 10}, "guitan")
					module_2_upvr.powerdamage(var12_upvr, 2 * (module_2_upvr.getallstats(any_GetPlayerFromCharacter_result1_upvw).taijutsu + 2), "blockbreakpushaway", var30, Vector3.new(50, 50, 50))
				end
			end
			wait(0.5)
			arg2.canrunfromslice.Value = false
			arg2.heavyhit.Value = false
		end)
	end)
end
return module