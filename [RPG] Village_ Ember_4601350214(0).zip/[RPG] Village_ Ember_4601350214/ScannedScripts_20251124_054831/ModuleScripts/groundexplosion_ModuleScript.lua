-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:47:03
-- Luau version 6, Types version 3
-- Time taken: 0.006659 seconds

local module = {}
local ClientEffects_upvr = workspace.ClientEffects
local TweenService_upvr = game:GetService("TweenService")
function module.make(arg1, arg2) -- Line 46
	--[[ Upvalues[2]:
		[1]: ClientEffects_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	spawn(function() -- Line 47
		--[[ Upvalues[4]:
			[1]: arg1 (read and write)
			[2]: arg2 (readonly)
			[3]: ClientEffects_upvr (copied, readonly)
			[4]: TweenService_upvr (copied, readonly)
		]]
		local var7
		if typeof(arg1) == "CFrame" then
		else
			var7 = arg1
			arg1 = var7.CFrame
		end
		var7 = CFrame.new()
		local var8 = var7 + arg1.p
		var7 = 45
		if arg2 then
			var7 = arg2
		end
		local RaycastParams_new_result1 = RaycastParams.new()
		RaycastParams_new_result1.FilterType = Enum.RaycastFilterType.Whitelist
		RaycastParams_new_result1.FilterDescendantsInstances = {workspace.map, workspace.map2}
		RaycastParams_new_result1.IgnoreWater = true
		local var11 = var7 / 20
		for i = 1, 360, 30 do
			local var12 = i * math.pi / 180
			local var13 = var8 * CFrame.new(math.cos(var12) * 1 + 0, 0, math.sin(var12) * 1 + 0)
			local workspace_Raycast_result1 = workspace:Raycast(var13.p, ((var13 * CFrame.new(0, -2, 0)).p - var13.p).unit * 20, RaycastParams_new_result1)
			if workspace_Raycast_result1 then
				local children = script.rocktrail:GetChildren()
				local clone_upvr = children[math.random(1, #children)]:Clone()
				clone_upvr.Material = Enum.Material.Slate
				clone_upvr.CFrame = CFrame.new() + workspace_Raycast_result1.Position
				clone_upvr.Anchored = true
				clone_upvr.CFrame = CFrame.new(clone_upvr.Position * Vector3.new(1, 0, 1), var8.p * Vector3.new(1, 0, 1)) * CFrame.new(0, 0, -var7) + Vector3.new(0, workspace_Raycast_result1.Position.Y, 0)
				clone_upvr.Size = Vector3.new(var7 / 2, var11 + 4, var11 + 4)
				clone_upvr.Parent = ClientEffects_upvr
				clone_upvr.CanCollide = false
				clone_upvr.TopSurface = Enum.SurfaceType.SmoothNoOutlines
				clone_upvr.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
				clone_upvr.CFrame *= CFrame.Angles(math.random(-5, 5), 0, 0)
				spawn(function() -- Line 104
					--[[ Upvalues[2]:
						[1]: clone_upvr (readonly)
						[2]: TweenService_upvr (copied, readonly)
					]]
					wait(1)
					game.Debris:AddItem(clone_upvr, 2)
					TweenService_upvr:Create(clone_upvr, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {
						Transparency = 1;
						Size = Vector3.new(0, 0, 0);
						CFrame = clone_upvr.CFrame - Vector3.new(0, clone_upvr.Size.Y, 0);
					}):Play()
				end)
			end
		end
	end)
end
return module