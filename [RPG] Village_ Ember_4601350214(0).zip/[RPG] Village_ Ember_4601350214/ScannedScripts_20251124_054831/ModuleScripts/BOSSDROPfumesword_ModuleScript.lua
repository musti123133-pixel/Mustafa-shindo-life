-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:32:37
-- Luau version 6, Types version 3
-- Time taken: 0.026886 seconds

local module = {}
local function _(arg1, arg2) -- Line 7, Named "CreateRegion3FromLocAndSize"
	local var2 = arg2 / 2
	return Region3.new(arg1 - var2, arg1 + var2)
end
function PointOnCircle(arg1, arg2, arg3, arg4) -- Line 15
	return arg1 + arg3 * math.cos(arg4), arg2 + arg3 * math.sin(arg4)
end
function module.idlanim() -- Line 23
	return 4855855974
end
function module.combat() -- Line 28
	return {9163315564, 9163341152, 9163343858, 9163261514}
end
function module.block() -- Line 33
	return 9163317779
end
function module.typ() -- Line 37
	return "saber"
end
function module.power() -- Line 41
	return 4816744006
end
function module.slicedelay() -- Line 45
	return 0.3
end
function module.damage() -- Line 48
	return 10
end
function module.specdamage(arg1) -- Line 51
	return 5.6 * (require(ReplicatedStorage:WaitForChild("GlobalFunctions")).getallstats(arg1).taijutsu + 5.6)
end
ReplicatedStorage = game.ReplicatedStorage -- Setting global
local TweenService_upvr = game:GetService("TweenService")
local RunService_upvr = game:GetService("RunService")
function module.heavyattack(arg1, arg2) -- Line 66
	--[[ Upvalues[2]:
		[1]: TweenService_upvr (readonly)
		[2]: RunService_upvr (readonly)
	]]
	if script.stamina.Value <= arg2.stamina2.Value then
		arg2.stamina2.Value = arg2.stamina2.Value - script.stamina.Value
	else
		return script.stamina.Value
	end
	local KeyMods_upvr = game:GetService("ServerScriptService"):WaitForChild("KeyMods")
	spawn(function() -- Line 80
		--[[ Upvalues[5]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: TweenService_upvr (copied, readonly)
			[4]: RunService_upvr (copied, readonly)
			[5]: KeyMods_upvr (readonly)
		]]
		local var17_upvr = arg1
		local any_GetPlayerFromCharacter_result1_upvw = game.Players:GetPlayerFromCharacter(var17_upvr)
		if any_GetPlayerFromCharacter_result1_upvw == nil then
			any_GetPlayerFromCharacter_result1_upvw = var17_upvr
		else
		end
		local var19_upvw
		if any_GetPlayerFromCharacter_result1_upvw == nil then
			any_GetPlayerFromCharacter_result1_upvw = var17_upvr
			var19_upvw = var17_upvr:WaitForChild("mouse")
		else
			var19_upvw = workspace.projectileparent:WaitForChild(var17_upvr.Name.."mouse")
		end
		local module_2_upvr = require(ReplicatedStorage:WaitForChild("GlobalFunctions"))
		local var21_upvw = false
		if module_2_upvr.haspuppet(any_GetPlayerFromCharacter_result1_upvw) then
			var21_upvw = true
		end
		delay(0, function() -- Line 106
			--[[ Upvalues[9]:
				[1]: arg2 (readonly)
				[2]: var17_upvr (readonly)
				[3]: var21_upvw (read and write)
				[4]: var19_upvw (read and write)
				[5]: module_2_upvr (readonly)
				[6]: TweenService_upvr (copied, readonly)
				[7]: RunService_upvr (copied, readonly)
				[8]: KeyMods_upvr (copied, readonly)
				[9]: any_GetPlayerFromCharacter_result1_upvw (read and write)
			]]
			-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
			local IntValue = Instance.new("IntValue")
			IntValue.Parent = arg2
			IntValue.Name = "hyperarmour"
			game.Debris:AddItem(IntValue, 4)
			local HumanoidRootPart = var17_upvr.HumanoidRootPart
			if var21_upvw then
				HumanoidRootPart = var17_upvr.puppet.HumanoidRootPart
			end
			arg2.heavyhit.Value = true
			local Attachment = Instance.new("Attachment")
			Attachment.Parent = var17_upvr["Left Arm"]
			Attachment.Position = Vector3.new(0, -0.5, 0)
			local clone_2 = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone_2.Parent = Attachment
			clone_2:Emit(4)
			clone_2.Enabled = true
			game.Debris:AddItem(Attachment, 0.5)
			local Animation = Instance.new("Animation")
			Animation.AnimationId = "http://www.roblox.com/asset/?id="..9143198090
			arg2.canrunfromslice.Value = true
			local any_LoadAnimation_result1 = var17_upvr.Humanoid:LoadAnimation(Animation)
			if var21_upvw then
				any_LoadAnimation_result1 = var17_upvr.puppet.Humanoid:LoadAnimation(Animation)
			end
			any_LoadAnimation_result1:Play()
			local Attachment_2 = Instance.new("Attachment")
			Attachment_2.Parent = var17_upvr["Right Arm"]
			Attachment_2.Position = Vector3.new(0, -0.5, 0)
			local clone = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone.Parent = Attachment_2
			clone:Emit(4)
			clone.Enabled = true
			game.Debris:AddItem(Attachment_2, 0.5)
			wait(0.1)
			local var35
			if var21_upvw then
				var35 = var17_upvr.puppet.weapon.saber.Gun
			else
				var35 = var17_upvr.weapon.saber.Gun
			end
			var35.Part0 = nil
			local var36_upvw
			if var21_upvw then
				var36_upvw = var17_upvr.puppet.weapon.saber
			else
				var36_upvw = var17_upvr.weapon.saber
			end
			var36_upvw.CFrame = CFrame.new(HumanoidRootPart.CFrame.p, var19_upvw.CFrame.p) * CFrame.Angles((-math.pi/2), 0, 0) * CFrame.new(0, 0, -3)
			local ObjectValue_2 = Instance.new("ObjectValue")
			ObjectValue_2.Value = var17_upvr
			ObjectValue_2.Name = "owner"
			ObjectValue_2.Parent = var36_upvw
			var36_upvw.Anchored = true
			for _ = 1, 1 do
				module_2_upvr.sound(var36_upvw, 9165126326, 1)
				var36_upvw.CFrame = HumanoidRootPart.CFrame + Vector3.new(0, 1, 0)
				var36_upvw.Parent = workspace.projectileparent
				local ObjectValue = Instance.new("ObjectValue")
				ObjectValue.Value = var17_upvr
				ObjectValue.Name = "owner"
				ObjectValue.Parent = var36_upvw
				ReplicatedStorage.fire:FireAllClients(var17_upvr, var36_upvw, "fumetrailprojectile")
				local Attachment_4_upvr = Instance.new("Attachment")
				Attachment_4_upvr.Parent = workspace.Terrain
				local Attachment_3 = Instance.new("Attachment")
				Attachment_3.Parent = var36_upvw
				Attachment_4_upvr.WorldPosition = HumanoidRootPart.CFrame.p
				local AlignPosition = Instance.new("AlignPosition")
				AlignPosition.Responsiveness = 50
				AlignPosition.ApplyAtCenterOfMass = true
				AlignPosition.MaxForce = 999999
				AlignPosition.Attachment0 = Attachment_3
				AlignPosition.Attachment1 = Attachment_4_upvr
				AlignPosition.Parent = Attachment_3
				AlignPosition.MaxVelocity = 130
				spawn(function() -- Line 261
					--[[ Upvalues[9]:
						[1]: var36_upvw (read and write)
						[2]: var17_upvr (copied, readonly)
						[3]: Attachment_4_upvr (readonly)
						[4]: var19_upvw (copied, read and write)
						[5]: TweenService_upvr (copied, readonly)
						[6]: RunService_upvr (copied, readonly)
						[7]: KeyMods_upvr (copied, readonly)
						[8]: module_2_upvr (copied, readonly)
						[9]: any_GetPlayerFromCharacter_result1_upvw (copied, read and write)
					]]
					local var44_upvw = false
					delay(0, function() -- Line 268
						--[[ Upvalues[10]:
							[1]: var17_upvr (copied, readonly)
							[2]: Attachment_4_upvr (copied, readonly)
							[3]: var19_upvw (copied, read and write)
							[4]: var36_upvw (readonly)
							[5]: var44_upvw (read and write)
							[6]: TweenService_upvr (copied, readonly)
							[7]: RunService_upvr (copied, readonly)
							[8]: KeyMods_upvr (copied, readonly)
							[9]: module_2_upvr (copied, readonly)
							[10]: any_GetPlayerFromCharacter_result1_upvw (copied, read and write)
						]]
						-- KONSTANTERROR: [0] 1. Error Block 42 start (CF ANALYSIS FAILED)
						local any_create_result1 = require(ReplicatedStorage.alljutsu.main.nearestplayer).create(var17_upvr, 120)
						local var48
						if any_create_result1 and any_create_result1.Parent:FindFirstChild("Humanoid") then
							var48 = any_create_result1
						end
						if var48 then
							Attachment_4_upvr.WorldPosition = var48.CFrame.p
						else
							Attachment_4_upvr.WorldPosition = var19_upvw.Position
						end
						local magnitude = (var36_upvw.CFrame.p - Attachment_4_upvr.WorldPosition).magnitude
						-- KONSTANTERROR: [0] 1. Error Block 42 end (CF ANALYSIS FAILED)
						-- KONSTANTERROR: [223] 164. Error Block 33 start (CF ANALYSIS FAILED)
						for i_2 = 5, magnitude, 15 do
							local var50
							if var44_upvw then break end
							if var48 then
								Attachment_4_upvr.WorldPosition = var48.CFrame.p
								var50 = Attachment_4_upvr.WorldPosition
							end
							local PointOnCircle_result1, PointOnCircle_result2 = PointOnCircle(magnitude * 0.5, 0, magnitude * 0.5, math.pi - math.pi / magnitude * i_2)
							local cframe = CFrame.new(CFrame.new(var36_upvw.CFrame.p, var50):pointToWorldSpace(Vector3.new((PointOnCircle_result2) * (math.random(-1, 1) * 0.1), PointOnCircle_result2 * 0, -PointOnCircle_result1)))
							local any_toEulerAnglesXYZ_result1, any_toEulerAnglesXYZ_result2, any_toEulerAnglesXYZ_result3 = CFrame.new(var36_upvw.CFrame.p, cframe.p) * CFrame.Angles((-math.pi/2), 0, 0) * CFrame.new(0, 0, -3):toEulerAnglesXYZ()
							local any_Create_result1 = TweenService_upvr:Create(var36_upvw, TweenInfo.new(0.08, Enum.EasingStyle.Linear, Enum.EasingDirection.In, 0, false, 0), {
								CFrame = cframe * CFrame.Angles(any_toEulerAnglesXYZ_result1, any_toEulerAnglesXYZ_result2, any_toEulerAnglesXYZ_result3);
							})
							any_Create_result1:Play()
							local var60_upvw = false
							spawn(function() -- Line 501
								--[[ Upvalues[4]:
									[1]: RunService_upvr (copied, readonly)
									[2]: var36_upvw (copied, readonly)
									[3]: var44_upvw (copied, read and write)
									[4]: var60_upvw (read and write)
								]]
								-- KONSTANTERROR: [0] 1. Error Block 19 start (CF ANALYSIS FAILED)
								RunService_upvr.Heartbeat:wait()
								-- KONSTANTERROR: [0] 1. Error Block 19 end (CF ANALYSIS FAILED)
								-- KONSTANTERROR: [8] 7. Error Block 23 start (CF ANALYSIS FAILED)
								if var36_upvw:IsDescendantOf(workspace.projectileparent) then
									-- KONSTANTWARNING: GOTO [19] #15
								end
								-- KONSTANTERROR: [8] 7. Error Block 23 end (CF ANALYSIS FAILED)
							end)
							any_Create_result1.Completed:wait()
							var60_upvw = true
						end
						-- KONSTANTERROR: [223] 164. Error Block 33 end (CF ANALYSIS FAILED)
					end)
				end)
				game.Debris:AddItem(var36_upvw, 4)
				game.Debris:AddItem(Attachment_4_upvr, 4)
			end
			any_LoadAnimation_result1:Stop()
			game.Debris:AddItem(var36_upvw, 2)
			var36_upvw.Parent = workspace.projectileparent
			wait(0.2)
			arg2.canrunfromslice.Value = false
			arg2.heavyhit.Value = false
		end)
	end)
end
return module