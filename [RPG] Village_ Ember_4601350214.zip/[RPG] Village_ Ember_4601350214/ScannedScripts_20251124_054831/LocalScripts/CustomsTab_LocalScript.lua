-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:48:12
-- Luau version 6, Types version 3
-- Time taken: 0.023696 seconds

-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.Health, false)
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local Character = LocalPlayer_upvr.Character
if not Character then
	Character = LocalPlayer_upvr.CharacterAdded:wait()
end
local CustomTab_upvr = script.Parent:WaitForChild("Main").ingame.Menu.CustomTab
local tbl_2 = {"maska", "maskb", "maskc", "maskd", "maske", "maskf", "maskg", "maskh", "maski"}
local tbl = {"cloaka", "cloakb", "cloakc", "cloakd", "cloake"}
local List = CustomTab_upvr.List
local List2 = CustomTab_upvr.List2
local var41 = false
if workspace:FindFirstChild("CC") then
	var41 = true
end
local var43_upvw = false
if var41 then
	for _, v in pairs({
		Konohagakure = 8472120;
		Sunagakure = 8472172;
		Kumogakure = 8472176;
		Kirigakure = 8472169;
		Iwagakure = 8472183;
	}) do
		if LocalPlayer_upvr:IsInGroup(v) and 9 <= LocalPlayer_upvr:GetRankInGroup(v) then
			var43_upvw = true
		end
	end
end
for i_2 = 1, #tbl_2 do
	getmask = ReplicatedStorage_upvr.custo.mask[tbl_2[i_2]]:Clone() -- Setting global
	local ViewportFrame_2 = Instance.new("ViewportFrame", List["item"..i_2])
	ViewportFrame_2.Size = UDim2.new(1, 0, 1, 0)
	ViewportFrame_2.ZIndex = 9
	ViewportFrame_2.Name = "canclick"
	ViewportFrame_2.BackgroundTransparency = 1
	getmask.Head.BrickColor = BrickColor.new("Ghost grey")
	getmask.Head.Transparency = 0
	local Camera_2 = Instance.new("Camera", ViewportFrame_2)
	Camera_2.CameraType = "Scriptable"
	ViewportFrame_2.CurrentCamera = Camera_2
	getmask.Parent = ViewportFrame_2
	Camera_2.CFrame = getmask.Head.CFrame * CFrame.new(0, 0, -2) * CFrame.Angles(0, math.pi, 0)
	if tbl_2[i_2] == "maskd" then
		Camera_2.CFrame = getmask.Head.CFrame * CFrame.Angles(0.5, 0, 0) * CFrame.new(0, 0, -3) * CFrame.Angles(0, math.pi, 0)
	end
	getmask.Name = "item"
	local StringValue = Instance.new("StringValue")
	StringValue.Name = "main"
	StringValue.Parent = List["item"..i_2]
	StringValue.Value = tbl_2[i_2]
end
for i_3 = 1, #tbl do
	getmask = ReplicatedStorage_upvr.custo.Flaks[tbl[i_3]]:Clone() -- Setting global
	local ViewportFrame = Instance.new("ViewportFrame", List2["cloak"..i_3])
	ViewportFrame.Size = UDim2.new(1, 0, 1, 0)
	ViewportFrame.ZIndex = 9
	ViewportFrame.Name = "canclick2"
	ViewportFrame.BackgroundTransparency = 1
	ViewportFrame.Visible = false
	local Camera = Instance.new("Camera", ViewportFrame)
	Camera.CameraType = "Scriptable"
	ViewportFrame.CurrentCamera = Camera
	getmask.Parent = ViewportFrame
	Camera.CFrame = getmask.Torso.CFrame * CFrame.new(0, -0.5, 6)
	getmask.Name = "item"
	local StringValue_2 = Instance.new("StringValue")
	StringValue_2.Name = "main"
	StringValue_2.Parent = List2["cloak"..i_3]
	StringValue_2.Value = tbl[i_3]
	local _
end
newpaste = CustomTab_upvr.item.id -- Setting global
newpaste.Changed:Connect(function() -- Line 171
	--[[ Upvalues[1]:
		[1]: CustomTab_upvr (readonly)
	]]
	CustomTab_upvr.item.preview.Image = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
	if CustomTab_upvr.item.thisimg:FindFirstChild("canclick") then
		CustomTab_upvr.item.thisimg:FindFirstChild("canclick").item.mask.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
	end
	if CustomTab_upvr.item.thisimg:FindFirstChild("canclick2") then
		if CustomTab_upvr.item.thisimg:FindFirstChild("canclick2").item.customize:FindFirstChild("head") then
			CustomTab_upvr.item.thisimg:FindFirstChild("canclick2").item.customize.head.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
		end
		if CustomTab_upvr.item.thisimg:FindFirstChild("canclick2").item.customize:FindFirstChild("tor") then
			CustomTab_upvr.item.thisimg:FindFirstChild("canclick2").item.customize.tor.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
		end
		if CustomTab_upvr.item.thisimg:FindFirstChild("canclick2").item.customize:FindFirstChild("larm") then
			CustomTab_upvr.item.thisimg:FindFirstChild("canclick2").item.customize.larm.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
		end
		if CustomTab_upvr.item.thisimg:FindFirstChild("canclick2").item.customize:FindFirstChild("rarm") then
			CustomTab_upvr.item.thisimg:FindFirstChild("canclick2").item.customize.rarm.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
		end
	end
end)
local var55_upvw
CustomTab_upvr.item.unequip.MouseButton1Down:connect(function() -- Line 215
	--[[ Upvalues[2]:
		[1]: var55_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
	]]
	if var55_upvw then
	else
		return
	end
	LocalPlayer_upvr.startevent:FireServer("unequipcustom", var55_upvw.main.Value)
end)
local MarketplaceService_upvr = game:GetService("MarketplaceService")
CustomTab_upvr.item.confirm.MouseButton1Down:connect(function() -- Line 222
	--[[ Upvalues[5]:
		[1]: var55_upvw (read and write)
		[2]: CustomTab_upvr (readonly)
		[3]: LocalPlayer_upvr (readonly)
		[4]: var43_upvw (read and write)
		[5]: MarketplaceService_upvr (readonly)
	]]
	if var55_upvw then
	else
		return
	end
	if CustomTab_upvr.item.thisimg:FindFirstChild("canclick2") then
		LocalPlayer_upvr.startevent:FireServer("customcape", var55_upvw.main.Value, CustomTab_upvr.item.preview.Image)
	elseif CustomTab_upvr.item.thisimg:FindFirstChild("canclick") then
		if not LocalPlayer_upvr.gamepasses:FindFirstChild("customs") then
			if var43_upvw then
			else
				MarketplaceService_upvr:PromptGamePassPurchase(LocalPlayer_upvr, 11039194)
				return
			end
		end
		LocalPlayer_upvr.startevent:FireServer("custom", var55_upvw.main.Value, CustomTab_upvr.item.preview.Image)
	end
end)
for _, v_2_upvr in pairs(List:GetChildren()) do
	if v_2_upvr:FindFirstChild("canclick") then
		v_2_upvr.MouseButton1Down:connect(function() -- Line 251
			--[[ Upvalues[3]:
				[1]: CustomTab_upvr (readonly)
				[2]: v_2_upvr (readonly)
				[3]: var55_upvw (read and write)
			]]
			CustomTab_upvr.item.thisimg:ClearAllChildren()
			CustomTab_upvr.item.ryo2.Text = '0'
			local clone = v_2_upvr.canclick:Clone()
			clone.Parent = CustomTab_upvr.item.thisimg
			clone.item.mask.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
			var55_upvw = v_2_upvr
		end)
	end
end
for var70, v_3_upvr in pairs(List2:GetChildren()) do
	if v_3_upvr:FindFirstChild("canclick2") then
		v_3_upvr.MouseButton1Down:connect(function() -- Line 281
			--[[ Upvalues[5]:
				[1]: CustomTab_upvr (readonly)
				[2]: ReplicatedStorage_upvr (readonly)
				[3]: v_3_upvr (readonly)
				[4]: LocalPlayer_upvr (readonly)
				[5]: var55_upvw (read and write)
			]]
			CustomTab_upvr.item.thisimg:ClearAllChildren()
			local Value = ReplicatedStorage_upvr.custo.Flaks:FindFirstChild(v_3_upvr.main.Value).rc.Value
			if LocalPlayer_upvr.gamepasses:FindFirstChild("customs") then
				Value /= 2
			end
			CustomTab_upvr.item.ryo2.Text = Value
			if LocalPlayer_upvr.gamepasses:FindFirstChild("customs") then
				CustomTab_upvr.item.ryo2.Text = Value.." / 50%"
			end
			local clone_2 = v_3_upvr.canclick2:Clone()
			clone_2.Parent = CustomTab_upvr.item.thisimg
			clone_2.Visible = true
			if clone_2.item.customize:FindFirstChild("head") then
				clone_2.item.customize.head.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
			end
			if clone_2.item.customize:FindFirstChild("tor") then
				clone_2.item.customize.tor.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
			end
			if clone_2.item.customize:FindFirstChild("larm") then
				clone_2.item.customize.larm.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
			end
			if clone_2.item.customize:FindFirstChild("rarm") then
				clone_2.item.customize.rarm.TextureID = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..newpaste.Text
			end
			var55_upvw = v_3_upvr
		end)
	end
end
local Text_upvr = CustomTab_upvr.item.confirm.Text
function var70(arg1) -- Line 332
	--[[ Upvalues[2]:
		[1]: CustomTab_upvr (readonly)
		[2]: Text_upvr (readonly)
	]]
	if arg1.Name == "customs" then
		CustomTab_upvr.item.confirm.Text = Text_upvr
	end
end
LocalPlayer_upvr.gamepasses.ChildAdded:connect(var70)
var70 = "customs"
if not LocalPlayer_upvr.gamepasses:FindFirstChild(var70) and var43_upvw then
end