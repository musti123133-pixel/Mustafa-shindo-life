-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:47:51
-- Luau version 6, Types version 3
-- Time taken: 0.008962 seconds

local module = {}
local ClientEffects_upvr = workspace.ClientEffects
local TweenService_upvr = game:GetService("TweenService")
function module.make(arg1, arg2) -- Line 16
	--[[ Upvalues[2]:
		[1]: ClientEffects_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	spawn(function() -- Line 17
		--[[ Upvalues[4]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: ClientEffects_upvr (copied, readonly)
			[4]: TweenService_upvr (copied, readonly)
		]]
		local var7_upvr = arg2
		local function emit(arg1_2) -- Line 36
			--[[ Upvalues[1]:
				[1]: emit (readonly)
			]]
			for _, v_upvr in pairs(arg1_2:GetChildren()) do
				task.spawn(function() -- Line 41
					--[[ Upvalues[1]:
						[1]: v_upvr (readonly)
					]]
					local var14_upvr = v_upvr
					if var14_upvr:IsA("Attachment") then
					else
						task.delay(var14_upvr:GetAttribute("EmitDelay"), function() -- Line 44
							--[[ Upvalues[1]:
								[1]: var14_upvr (readonly)
							]]
							var14_upvr:Emit(var14_upvr:GetAttribute("EmitCount"))
						end)
					end
				end)
				emit(v_upvr)
			end
		end
		local HumanoidRootPart_upvr = arg1:WaitForChild("HumanoidRootPart")
		task.delay(0.1, function() -- Line 63
			--[[ Upvalues[3]:
				[1]: HumanoidRootPart_upvr (readonly)
				[2]: ClientEffects_upvr (copied, readonly)
				[3]: emit (readonly)
			]]
			local clone_4 = script.emit2:Clone()
			clone_4.CFrame = HumanoidRootPart_upvr.CFrame * CFrame.new(0, 0, -30) * CFrame.Angles((math.pi/2), 0, 0) - Vector3.new(0, 2, 0)
			clone_4.Parent = ClientEffects_upvr
			emit(clone_4)
			task.wait(1)
			clone_4:Destroy()
		end)
		task.wait(0.2)
		local TweenInfo_new_result1_upvr = TweenInfo.new(0.2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
		local function ScaleModel_upvr(arg1_3, arg2_2) -- Line 97, Named "ScaleModel"
			--[[ Upvalues[2]:
				[1]: TweenService_upvr (copied, readonly)
				[2]: TweenInfo_new_result1_upvr (readonly)
			]]
			local Position_2_upvr = arg1_3.PrimaryPart.Position
			for _, v_2_upvr in ipairs(arg1_3:GetDescendants()) do
				if v_2_upvr:IsA("BasePart") then
					local Position = v_2_upvr.Position
					TweenService_upvr:Create(v_2_upvr, TweenInfo_new_result1_upvr, {
						Size = Vector3.new(arg2_2 * v_2_upvr.Size.x, arg2_2 * v_2_upvr.Size.y, arg2_2 * v_2_upvr.Size.z);
					}):Play()
					TweenService_upvr:Create(v_2_upvr, TweenInfo_new_result1_upvr, {
						CFrame = v_2_upvr.CFrame - Position + Position_2_upvr + (Position - Position_2_upvr) * arg2_2 + Vector3.new(0, 3, 0);
					}):Play()
					coroutine.wrap(function() -- Line 129
						--[[ Upvalues[4]:
							[1]: v_2_upvr (readonly)
							[2]: Position_2_upvr (readonly)
							[3]: TweenService_upvr (copied, readonly)
							[4]: TweenInfo_new_result1_upvr (copied, readonly)
						]]
						local var30_upvr = v_2_upvr
						local Position_3 = var30_upvr.Position
						wait(3)
						coroutine.wrap(function() -- Line 138
							--[[ Upvalues[1]:
								[1]: var30_upvr (readonly)
							]]
							local clone_3 = script.EXPLODE:Clone()
							clone_3.CFrame = var30_upvr.CFrame
							clone_3.Parent = workspace
							local function emit_upvr(arg1_4) -- Line 145, Named "emit"
								--[[ Upvalues[1]:
									[1]: emit_upvr (readonly)
								]]
								for _, v_3_upvr in pairs(arg1_4:GetChildren()) do
									task.spawn(function() -- Line 150
										--[[ Upvalues[1]:
											[1]: v_3_upvr (readonly)
										]]
										local var40_upvr = v_3_upvr
										if var40_upvr:IsA("Attachment") then
										else
											task.delay(var40_upvr:GetAttribute("EmitDelay"), function() -- Line 153
												--[[ Upvalues[1]:
													[1]: var40_upvr (readonly)
												]]
												var40_upvr:Emit(var40_upvr:GetAttribute("EmitCount"))
											end)
										end
									end)
									emit_upvr(v_3_upvr)
								end
							end
							emit_upvr(clone_3)
							wait(1)
							clone_3:Destroy()
						end)()
						TweenService_upvr:Create(var30_upvr, TweenInfo_new_result1_upvr, {
							Size = Vector3.new(var30_upvr.Size.x, 0 * var30_upvr.Size.y, var30_upvr.Size.z);
							Transparency = 1;
							CFrame = var30_upvr.CFrame - Position_3 + Position_2_upvr + (Position_3 - Position_2_upvr) * 0 - Vector3.new(0, 3, 0);
						}):Play()
					end)()
				end
			end
		end
		for i_4_upvr = 1, 4 do
			task.wait(0.1)
			task.spawn(function() -- Line 197
				--[[ Upvalues[5]:
					[1]: var7_upvr (readonly)
					[2]: i_4_upvr (readonly)
					[3]: ClientEffects_upvr (copied, readonly)
					[4]: ScaleModel_upvr (readonly)
					[5]: emit (readonly)
				]]
				local clone_2 = script.emit:Clone()
				local var45 = var7_upvr * CFrame.new(math.random(-30, 30), 0, -15 * i_4_upvr) + Vector3.new(0, -2, 0)
				clone_2.CFrame = var45 * CFrame.Angles((math.pi/2), 0, 0)
				clone_2.Parent = ClientEffects_upvr
				local var46 = var45 * CFrame.Angles(0, math.random(-6, 6), 0)
				local clone = script.Model:Clone()
				clone:SetPrimaryPartCFrame(var46)
				clone.Parent = ClientEffects_upvr
				ScaleModel_upvr(clone, 3)
				emit(clone_2)
				task.wait(0.3)
				local clone_5 = script.EXPLODE:Clone()
				clone_5.CFrame = var46
				clone_5.Parent = ClientEffects_upvr
				emit(clone_5)
				wait(1)
				clone_2:Destroy()
				clone_5:Destroy()
			end)
		end
	end)
end
return module