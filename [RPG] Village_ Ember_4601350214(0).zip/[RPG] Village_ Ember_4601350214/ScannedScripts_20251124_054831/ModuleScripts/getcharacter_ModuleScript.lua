-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:33:40
-- Luau version 6, Types version 3
-- Time taken: 0.002343 seconds

local module = {}
local ReplicatedStorage = game:GetService("ReplicatedStorage")
serverscript = game.ServerScriptService -- Setting global
getcusto = workspace:WaitForChild("custo") -- Setting global
function module.create(arg1) -- Line 16
	if arg1 then
	else
		return
	end
	local any_GetPlayerFromCharacter_result1 = game.Players:GetPlayerFromCharacter(arg1)
	if any_GetPlayerFromCharacter_result1 then
		local var4 = any_GetPlayerFromCharacter_result1
	end
	local var5
	if workspace.projectileparent:FindFirstChild(var4.Name.."mouse") then
		var5 = workspace.projectileparent:FindFirstChild(var4.Name.."mouse")
	else
		var5 = arg1.mouse
	end
	local module_2 = {var4}
	module_2[2] = arg1
	module_2[3] = var5
	return module_2
end
return module