-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:32:25
-- Luau version 6, Types version 3
-- Time taken: 0.024093 seconds

local module = {
	idlanim = function() -- Line 6
		return 4855855974
	end;
	combat = function() -- Line 11
		return {9128038984, 9128043954, 9128047846, 9163298622}
	end;
	block = function() -- Line 16
		return 9163269527
	end;
	typ = function() -- Line 20
		return "saber"
	end;
	power = function() -- Line 24
		return 4816744006
	end;
	slicedelay = function() -- Line 28
		return 0.3
	end;
	damage = function() -- Line 31
		return 10
	end;
	specdamage = function(arg1) -- Line 37
		return 2.2 * (require(ReplicatedStorage:WaitForChild("GlobalFunctions")).getallstats(arg1).taijutsu + 2.2)
	end;
}
function CreateRegion3FromLocAndSize(arg1, arg2) -- Line 52
	return Region3.new(Point1, arg1 + arg2 / 2)
end
ReplicatedStorage = game.ReplicatedStorage -- Setting global
function module.heavyattack(arg1, arg2) -- Line 62
	if script.stamina.Value <= arg2.stamina2.Value then
		arg2.stamina2.Value = arg2.stamina2.Value - script.stamina.Value
	else
		return script.stamina.Value
	end
	spawn(function() -- Line 77
		--[[ Upvalues[2]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
		]]
		local var14_upvr = arg1
		local any_GetPlayerFromCharacter_result1 = game.Players:GetPlayerFromCharacter(var14_upvr)
		local var16_upvw
		if any_GetPlayerFromCharacter_result1 == nil then
			any_GetPlayerFromCharacter_result1 = var14_upvr
			var16_upvw = var14_upvr:WaitForChild("mouse")
		else
			var16_upvw = workspace.projectileparent:WaitForChild(var14_upvr.Name.."mouse")
		end
		local module_2_upvr = require(ReplicatedStorage:WaitForChild("GlobalFunctions"))
		local var18_upvw = false
		if module_2_upvr.haspuppet(any_GetPlayerFromCharacter_result1) then
			var18_upvw = true
		end
		delay(0, function() -- Line 95
			--[[ Upvalues[5]:
				[1]: arg2 (readonly)
				[2]: var14_upvr (readonly)
				[3]: var18_upvw (read and write)
				[4]: var16_upvw (read and write)
				[5]: module_2_upvr (readonly)
			]]
			-- KONSTANTERROR: [0] 1. Error Block 41 start (CF ANALYSIS FAILED)
			local IntValue_3 = Instance.new("IntValue")
			IntValue_3.Parent = arg2
			IntValue_3.Name = "hyperarmour"
			game.Debris:AddItem(IntValue_3, 1)
			local HumanoidRootPart_2 = var14_upvr.HumanoidRootPart
			if var18_upvw then
				HumanoidRootPart_2 = var14_upvr.puppet.HumanoidRootPart
			end
			arg2.heavyhit.Value = true
			local IntValue_4 = Instance.new("IntValue")
			IntValue_4.Parent = var14_upvr.combat
			IntValue_4.Name = "hyperarmour"
			game.Debris:AddItem(IntValue_4, 1)
			if var18_upvw then
				script.sss.Attachment:Clone().Parent = var14_upvr.puppet.weapon.saber.blade.SWORD
			else
				-- KONSTANTERROR: Expression was reused, decompilation is incorrect
				script.sss.Attachment:Clone().Parent = var14_upvr.weapon.saber.blade.SWORD
			end
			local tbl_2 = {9128038984, 9128043954, 9128047846}
			if var18_upvw then
			end
			local Animation = Instance.new("Animation")
			Animation.AnimationId = "http://www.roblox.com/asset/?id="..7244432782
			local any_LoadAnimation_result1 = var14_upvr.Humanoid:LoadAnimation(Animation)
			if var18_upvw then
				any_LoadAnimation_result1 = var14_upvr.puppet.Humanoid:LoadAnimation(Animation)
			end
			any_LoadAnimation_result1:play()
			local StringValue_4 = Instance.new("StringValue")
			StringValue_4.Name = "shindaiswordcounter"
			StringValue_4.Parent = var14_upvr
			game.Debris:AddItem(StringValue_4, 3)
			local StringValue_3 = Instance.new("StringValue")
			StringValue_3.Name = "SPEEDBOOST"
			StringValue_3.Parent = var14_upvr
			game.Debris:AddItem(StringValue_3, 3)
			-- KONSTANTERROR: Expression was reused, decompilation is incorrect
			module_2_upvr.sound(script.sss.Attachment:Clone().Parent, 9132940672, 2)
			local var38_upvw = false
			local function var39() -- Line 195
				--[[ Upvalues[1]:
					[1]: var38_upvw (read and write)
				]]
				var38_upvw = true
			end
			delay(3, var39)
			-- KONSTANTERROR: [0] 1. Error Block 41 end (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [304] 217. Error Block 21 start (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [304] 217. Error Block 21 end (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [285] 201. Error Block 38 start (CF ANALYSIS FAILED)
			if delay(3, var39) then
				-- KONSTANTERROR: Expression was reused, decompilation is incorrect (x2)
				if delay(3, var39) and StringValue_4 and delay(3, var39) then
					if var38_upvw then
						-- KONSTANTWARNING: GOTO [305] #218
					end
					-- KONSTANTWARNING: GOTO [304] #217
				end
				-- KONSTANTWARNING: GOTO [305] #218
			end
			-- KONSTANTERROR: [285] 201. Error Block 38 end (CF ANALYSIS FAILED)
		end)
	end)
end
return module