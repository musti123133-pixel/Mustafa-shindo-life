-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:32:24
-- Luau version 6, Types version 3
-- Time taken: 0.016681 seconds

local module_upvr = {
	idlanim = function() -- Line 8
		return 4855855974
	end;
	combat = function() -- Line 13
		return {9163315564, 9163341152, 9163343858, 9163261514}
	end;
	block = function() -- Line 18
		return 9163269527
	end;
	typ = function() -- Line 22
		return "saber"
	end;
	power = function() -- Line 26
		return 4816744006
	end;
	slicedelay = function() -- Line 30
		return 0.3
	end;
	damage = function() -- Line 33
		return 10
	end;
	specdamage = function(arg1) -- Line 36
		return 1 * (require(ReplicatedStorage:WaitForChild("GlobalFunctions")).getallstats(arg1).taijutsu + 1)
	end;
}
ReplicatedStorage = game.ReplicatedStorage -- Setting global
local TweenService_upvr = game:GetService("TweenService")
function module_upvr.heavyattack(arg1, arg2) -- Line 50
	--[[ Upvalues[2]:
		[1]: module_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	if script.stamina.Value <= arg2.stamina2.Value then
		arg2.stamina2.Value = arg2.stamina2.Value - script.stamina.Value
	else
		return script.stamina.Value
	end
	local KeyMods_upvr = game:GetService("ServerScriptService"):WaitForChild("KeyMods")
	spawn(function() -- Line 65
		--[[ Upvalues[5]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: KeyMods_upvr (readonly)
			[4]: module_upvr (copied, readonly)
			[5]: TweenService_upvr (copied, readonly)
		]]
		local var15_upvr = arg1
		local any_GetPlayerFromCharacter_result1_upvw = game.Players:GetPlayerFromCharacter(var15_upvr)
		if any_GetPlayerFromCharacter_result1_upvw == nil then
			any_GetPlayerFromCharacter_result1_upvw = var15_upvr
		else
		end
		local module_upvr_2 = require(ReplicatedStorage:WaitForChild("GlobalFunctions"))
		local var18_upvw = false
		if module_upvr_2.haspuppet(any_GetPlayerFromCharacter_result1_upvw) then
			var18_upvw = true
		end
		delay(0, function() -- Line 85
			--[[ Upvalues[8]:
				[1]: arg2 (readonly)
				[2]: var15_upvr (readonly)
				[3]: var18_upvw (read and write)
				[4]: module_upvr_2 (readonly)
				[5]: KeyMods_upvr (copied, readonly)
				[6]: module_upvr (copied, readonly)
				[7]: any_GetPlayerFromCharacter_result1_upvw (read and write)
				[8]: TweenService_upvr (copied, readonly)
			]]
			local IntValue = Instance.new("IntValue")
			IntValue.Parent = arg2
			IntValue.Name = "hyperarmour"
			game.Debris:AddItem(IntValue, 1)
			local HumanoidRootPart_upvw = var15_upvr.HumanoidRootPart
			if var18_upvw then
				HumanoidRootPart_upvw = var15_upvr.puppet.HumanoidRootPart
			end
			arg2.heavyhit.Value = true
			local Attachment_2 = Instance.new("Attachment")
			Attachment_2.Parent = var15_upvr["Left Arm"]
			Attachment_2.Position = Vector3.new(0, -0.5, 0)
			local clone_3 = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone_3.Parent = Attachment_2
			clone_3:Emit(4)
			clone_3.Enabled = true
			game.Debris:AddItem(Attachment_2, 0.5)
			local Animation = Instance.new("Animation")
			Animation.AnimationId = "http://www.roblox.com/asset/?id="..9143198090
			arg2.canrunfromslice.Value = true
			local any_LoadAnimation_result1 = var15_upvr.Humanoid:LoadAnimation(Animation)
			if var18_upvw then
				any_LoadAnimation_result1 = var15_upvr.puppet.Humanoid:LoadAnimation(Animation)
			end
			any_LoadAnimation_result1:Play()
			local Attachment = Instance.new("Attachment")
			Attachment.Parent = var15_upvr["Right Arm"]
			Attachment.Position = Vector3.new(0, -0.5, 0)
			local clone_2 = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone_2.Parent = Attachment
			clone_2:Emit(4)
			clone_2.Enabled = true
			game.Debris:AddItem(Attachment, 1)
			module_upvr_2.sound(HumanoidRootPart_upvw, 9129624471, 2)
			module_upvr_2.sound(HumanoidRootPart_upvw, 9164980773, 1)
			if var18_upvw then
			else
			end
			wait(0.2)
			spawn(function() -- Line 159
				--[[ Upvalues[7]:
					[1]: HumanoidRootPart_upvw (read and write)
					[2]: var15_upvr (copied, readonly)
					[3]: KeyMods_upvr (copied, readonly)
					[4]: module_upvr (copied, readonly)
					[5]: any_GetPlayerFromCharacter_result1_upvw (copied, read and write)
					[6]: module_upvr_2 (copied, readonly)
					[7]: TweenService_upvr (copied, readonly)
				]]
				local clone = script.pyramid:Clone()
				clone.CFrame = HumanoidRootPart_upvw.CFrame - Vector3.new(0, 2, 0)
				clone.Parent = workspace.projectileparent
				local ObjectValue = Instance.new("ObjectValue")
				ObjectValue.Value = var15_upvr
				ObjectValue.Name = "owner"
				ObjectValue.Parent = clone
				require(KeyMods_upvr.alljutsu.main.hitdetection).multicreate(var15_upvr, clone, module_upvr.specdamage(any_GetPlayerFromCharacter_result1_upvw), "", "", 0.5)
				module_upvr_2.sound(clone, 9165862280, 2)
				local any_Create_result1_3 = TweenService_upvr:Create(clone, TweenInfo.new(0.4, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
					Size = Vector3.new(30, 2, 30);
					CFrame = clone.CFrame * CFrame.new(0, 0, -15);
				})
				any_Create_result1_3:Play()
				any_Create_result1_3.Completed:wait()
				module_upvr_2.sound(clone, 9129998150, 1)
				local any_Create_result1 = TweenService_upvr:Create(clone, TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
					Size = Vector3.new(60, 60, 60);
					CFrame = clone.CFrame * CFrame.new(0, 29, -30);
				})
				any_Create_result1:Play()
				any_Create_result1.Completed:wait()
				local any_Create_result1_2 = TweenService_upvr:Create(clone, TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 3, false, 0), {
					CFrame = clone.CFrame * CFrame.Angles(0, math.pi, 0);
				})
				any_Create_result1_2:Play()
				any_Create_result1_2.Completed:wait()
				local module = require(ReplicatedStorage:WaitForChild("GlobalFunctions"))
				module.powerdamage(var15_upvr, 4 * (module.getallstats(any_GetPlayerFromCharacter_result1_upvw).taijutsu + 4), "pushfar", clone.CFrame * CFrame.new(0, -60, 0), Vector3.new(40, 40, 40), "")
				ReplicatedStorage.fire:FireAllClients(var15_upvr, {clone.CFrame * CFrame.new(0, -29, 0), 0.1}, "pyramidexplosion")
				module.sound(clone, 9127480044, 2)
				TweenService_upvr:Create(clone, TweenInfo.new(1, Enum.EasingStyle.Elastic, Enum.EasingDirection.In, 0, false, 0), {
					Size = Vector3.new(0, 0, 0);
					CFrame = clone.CFrame * CFrame.new(0, -30, 0);
				}):Play()
				game.Debris:AddItem(clone, 1)
			end)
			wait(1)
			arg2.canrunfromslice.Value = false
			arg2.heavyhit.Value = false
		end)
	end)
end
return module_upvr