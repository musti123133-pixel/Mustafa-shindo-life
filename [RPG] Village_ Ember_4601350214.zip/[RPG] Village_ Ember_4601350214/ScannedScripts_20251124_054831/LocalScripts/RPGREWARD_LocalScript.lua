-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:48:13
-- Luau version 6, Types version 3
-- Time taken: 0.012786 seconds

-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.Health, false)
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local Character = LocalPlayer_upvr.Character
if not Character then
	Character = LocalPlayer_upvr.CharacterAdded:wait()
end
local Main_upvr = script.Parent:WaitForChild("Main")
local RPG = Main_upvr.ingame.Missionrpg.RPG
local rpgrewards_upvr = LocalPlayer_upvr:WaitForChild("statz").rpgrewards
local tbl_upvr = {RPG.D, RPG.C, RPG.B, RPG.A, RPG.S}
local mouse_upvr = LocalPlayer_upvr:GetMouse()
function spawnfollowmouse() -- Line 33
	--[[ Upvalues[2]:
		[1]: Main_upvr (readonly)
		[2]: mouse_upvr (readonly)
	]]
	Main_upvr.followmouse.Unlock.Story.Visible = false
	Main_upvr.followmouse.Position = UDim2.new(0, mouse_upvr.X, 0, mouse_upvr.Y)
	Main_upvr.followmouse.Visible = true
	for _, v in pairs(Main_upvr.followmouse:GetChildren()) do
		v.Visible = false
	end
end
for _, v_2_upvr in pairs(tbl_upvr) do
	v_2_upvr.icon.MouseButton1Down:connect(function() -- Line 49
		--[[ Upvalues[2]:
			[1]: LocalPlayer_upvr (readonly)
			[2]: v_2_upvr (readonly)
		]]
		LocalPlayer_upvr.startevent:FireServer("claimrewardquest", v_2_upvr.Name)
	end)
	v_2_upvr.icon.MouseEnter:connect(function() -- Line 56
		--[[ Upvalues[3]:
			[1]: Main_upvr (readonly)
			[2]: rpgrewards_upvr (readonly)
			[3]: v_2_upvr (readonly)
		]]
		-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
		spawnfollowmouse()
		Main_upvr.followmouse.Statinfo.Visible = true
		local Value = rpgrewards_upvr.completed.Value
		-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [21] 14. Error Block 60 start (CF ANALYSIS FAILED)
		if rpgrewards_upvr.do1.Value then
			Main_upvr.followmouse.Statinfo.bg.info.Text = "Reward Already Claimed"
		elseif 10 <= Value then
			Main_upvr.followmouse.Statinfo.bg.info.Text = "Click Icon To Claim Reward."
		else
			Main_upvr.followmouse.Statinfo.bg.info.Text = (10 - Value).." Quest needed for this reward."
		end
		-- KONSTANTERROR: [21] 14. Error Block 60 end (CF ANALYSIS FAILED)
	end)
	v_2_upvr.MouseLeave:connect(function() -- Line 160
		spawnfollowmouse()
	end)
	local _
end
function updatething() -- Line 168
	--[[ Upvalues[2]:
		[1]: tbl_upvr (readonly)
		[2]: rpgrewards_upvr (readonly)
	]]
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	for i_3 = 1, #tbl_upvr do
		local Value_2 = rpgrewards_upvr.completed.Value
		if i_3 == 1 then
			if 10 <= Value_2 then
				Value_2 = 10
			end
		end
		if i_3 == 2 then
			if 30 <= Value_2 then
				Value_2 = 30
			end
		end
		if i_3 == 3 then
			if 50 <= Value_2 then
				Value_2 = 50
			end
		end
		if i_3 == 4 then
			if 70 <= Value_2 then
				Value_2 = 70
			end
		end
		if i_3 == 5 then
			if 100 <= Value_2 then
				Value_2 = 100
			end
			local var42 = 100
		end
		local bar = tbl_upvr[i_3].bar
		bar.hb2.Rotation = 180 * -((Value_2 - var42 / 2) / (var42 - var42 / 2))
		bar.hb2.Visible = true
		bar.deplete.Visible = false
		local var44 = Value_2
		if var44 <= var42 / 2 then
			bar.hb2.Visible = false
			bar.deplete.Visible = true
			bar.deplete.Rotation = 180 * -(var44 * 2 / var42)
		end
		if var44 <= 0 then
			bar.hb2.Visible = false
			bar.deplete.Visible = false
		end
		if Value_2 == 0 then
			bar.hb.Visible = false
			bar.hb2.Visible = false
			bar.deplete.Visible = false
		else
			bar.hb.Visible = true
		end
	end
end
updatething()
for _, v_3 in pairs(rpgrewards_upvr:GetChildren()) do
	v_3.Changed:connect(function() -- Line 270
		updatething()
	end)
end