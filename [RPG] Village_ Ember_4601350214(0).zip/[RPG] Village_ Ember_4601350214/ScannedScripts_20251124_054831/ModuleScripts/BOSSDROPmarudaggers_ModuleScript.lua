-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:32:36
-- Luau version 6, Types version 3
-- Time taken: 0.016445 seconds

local module = {
	idlanim = function() -- Line 5
		return 4855855974
	end;
	combat = function() -- Line 10
		return {10797926900, 10797947383, 10797926900, 10797985730}
	end;
	block = function() -- Line 15
		return 9163310359
	end;
	typ = function() -- Line 19
		return "saber"
	end;
	power = function() -- Line 23
		return 4816744006
	end;
	slicedelay = function() -- Line 27
		return 0.3
	end;
	damage = function() -- Line 30
		return 10
	end;
	specdamage = function(arg1) -- Line 35
		return 0.5 * (require(ReplicatedStorage:WaitForChild("GlobalFunctions")).getallstats(arg1).taijutsu + 0.5)
	end;
}
ReplicatedStorage = game.ReplicatedStorage -- Setting global
local TweenService_upvr = game:GetService("TweenService")
function module.heavyattack(arg1, arg2) -- Line 52
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	if script.stamina.Value <= arg2.stamina2.Value then
		arg2.stamina2.Value = arg2.stamina2.Value - script.stamina.Value
	else
		return script.stamina.Value
	end
	local hitdetection_upvr = require(game:GetService("ServerScriptService"):WaitForChild("KeyMods").alljutsu.main.hitdetection)
	spawn(function() -- Line 69
		--[[ Upvalues[4]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: TweenService_upvr (copied, readonly)
			[4]: hitdetection_upvr (readonly)
		]]
		local var16_upvr = arg1
		local any_GetPlayerFromCharacter_result1_upvw = game.Players:GetPlayerFromCharacter(var16_upvr)
		local var18_upvw
		if any_GetPlayerFromCharacter_result1_upvw == nil then
			any_GetPlayerFromCharacter_result1_upvw = var16_upvr
			var18_upvw = var16_upvr:WaitForChild("mouse")
		else
			var18_upvw = workspace.projectileparent:WaitForChild(var16_upvr.Name.."mouse")
		end
		local module_2_upvr = require(ReplicatedStorage:WaitForChild("GlobalFunctions"))
		local var20_upvw = false
		if module_2_upvr.haspuppet(any_GetPlayerFromCharacter_result1_upvw) then
			var20_upvw = true
		end
		delay(0, function() -- Line 90
			--[[ Upvalues[8]:
				[1]: arg2 (readonly)
				[2]: var16_upvr (readonly)
				[3]: var20_upvw (read and write)
				[4]: module_2_upvr (readonly)
				[5]: var18_upvw (read and write)
				[6]: TweenService_upvr (copied, readonly)
				[7]: any_GetPlayerFromCharacter_result1_upvw (read and write)
				[8]: hitdetection_upvr (copied, readonly)
			]]
			local IntValue = Instance.new("IntValue")
			IntValue.Parent = arg2
			IntValue.Name = "hyperarmour"
			game.Debris:AddItem(IntValue, 1)
			local HumanoidRootPart = var16_upvr.HumanoidRootPart
			arg2.heavyhit.Value = true
			local Attachment_2 = Instance.new("Attachment")
			Attachment_2.Parent = var16_upvr["Left Arm"]
			Attachment_2.Position = Vector3.new(0, -0.5, 0)
			local clone_4 = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone_4.Parent = Attachment_2
			clone_4:Emit(4)
			clone_4.Enabled = true
			game.Debris:AddItem(Attachment_2, 0.5)
			local Animation = Instance.new("Animation")
			Animation.AnimationId = "http://www.roblox.com/asset/?id="..10798123870
			arg2.canrunfromslice.Value = true
			local any_LoadAnimation_result1 = var16_upvr.Humanoid:LoadAnimation(Animation)
			if var20_upvw then
				any_LoadAnimation_result1 = var16_upvr.puppet.Humanoid:LoadAnimation(Animation)
			end
			any_LoadAnimation_result1:Play()
			local Attachment = Instance.new("Attachment")
			Attachment.Parent = var16_upvr["Right Arm"]
			if var20_upvw then
				Attachment.Parent = var16_upvr.puppet["Right Arm"]
			end
			Attachment.Position = Vector3.new(0, -0.5, 0)
			local clone_2 = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone_2.Parent = Attachment
			clone_2:Emit(4)
			clone_2.Enabled = true
			game.Debris:AddItem(Attachment, 0.5)
			for _ = 1, 12 do
				task.wait(0.1)
				module_2_upvr.sound(HumanoidRootPart, 9158124575, 0.8)
				local CFrame = var18_upvw.CFrame
				if 80 < (HumanoidRootPart.Position - CFrame.p).magnitude then
					CFrame = CFrame.new(HumanoidRootPart.Position, CFrame.p) * CFrame.new(0, 0, -150)
				end
				local var38_upvr = CFrame.new(HumanoidRootPart.Position, CFrame.p) * CFrame.new(0, 0, -(HumanoidRootPart.Position - CFrame.p).magnitude)
				local magnitude = (HumanoidRootPart.Position - var38_upvr.Position).magnitude
				local TweenInfo_new_result1 = TweenInfo.new(0.4, Enum.EasingStyle.Linear, Enum.EasingDirection.In, 0, false, 0)
				;({}).Size = Vector3.new(magnitude + 15, 25, 25)
				module_2_upvr.sound(HumanoidRootPart, 9129843211, 10)
				local randint = math.random(-5, 5)
				local clone = script.main22:Clone()
				clone.CFrame = CFrame.new(HumanoidRootPart.Position, CFrame.p) * CFrame.Angles(0, 0, randint)
				clone.Parent = workspace.projectileparent
				TweenService_upvr:Create(clone, TweenInfo_new_result1, {
					CFrame = var38_upvr * CFrame.Angles(0, 0, randint);
				}):Play()
				game.Debris:AddItem(clone, 0.4)
				TweenService_upvr:Create(clone.grow1, TweenInfo_new_result1, {
					Size = Vector3.new(35.7630, 4.34199, 34.2211);
					Transparency = 1;
				}):Play()
				game.Debris:AddItem(clone, 0.4)
				TweenService_upvr:Create(clone.grow2, TweenInfo_new_result1, {
					Size = Vector3.new(45.0736, 5.47200, 43.1312);
					Transparency = 1;
				}):Play()
				game.Debris:AddItem(clone, 0.4)
				local clone_3 = script.Sphere:Clone()
				clone_3.Size = Vector3.new(magnitude + 20, 30, 30)
				clone_3.Transparency = 1
				clone_3.Color = Color3.fromRGB(255, 0, 0)
				game.Debris:AddItem(clone_3, 0.4)
				clone_3.CFrame = CFrame.new(HumanoidRootPart.Position, var38_upvr.Position) * CFrame.new(0, 0, -magnitude / 2) * CFrame.Angles(0, (math.pi/2), 0)
				clone_3.Parent = workspace.projectileparent
				local ObjectValue = Instance.new("ObjectValue")
				ObjectValue.Value = var16_upvr
				ObjectValue.Name = "owner"
				ObjectValue.Parent = clone_3
				TweenService_upvr:Create(clone_3, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1, false, 0), {
					Size = Vector3.new(magnitude + 15, 15, 15);
				}):Play()
				for _, v in pairs(clone_3:GetChildren()) do
					if v:IsA("ParticleEmitter") then
						v:Destroy()
					end
				end
				hitdetection_upvr.create(var16_upvr, clone_3, 0.7 * (module_2_upvr.getallstats(any_GetPlayerFromCharacter_result1_upvw).taijutsu + 0.7), "lithic", "", "")
				spawn(function() -- Line 366
					--[[ Upvalues[5]:
						[1]: var38_upvr (readonly)
						[2]: var16_upvr (copied, readonly)
						[3]: module_2_upvr (copied, readonly)
						[4]: any_GetPlayerFromCharacter_result1_upvw (copied, read and write)
						[5]: hitdetection_upvr (copied, readonly)
					]]
					wait(0.2)
					local clone_5 = script:FindFirstChild("BLACKFLAMES"):clone()
					clone_5.CFrame = var38_upvr
					local ObjectValue_2 = Instance.new("ObjectValue")
					ObjectValue_2.Value = var16_upvr
					ObjectValue_2.Name = "owner"
					ObjectValue_2.Parent = clone_5
					clone_5.Size = Vector3.new(20, 20, 20)
					clone_5.Parent = workspace.projectileparent
					hitdetection_upvr.multicreate(var16_upvr, clone_5, 0.25 * (module_2_upvr.getallstats(any_GetPlayerFromCharacter_result1_upvw).ninjutsu + 0.25), "blueburn", "", "", 2)
					game.Debris:AddItem(clone_5, 1)
					module_2_upvr.sound(clone_5, 9157993138, 0.8)
				end)
			end
			any_LoadAnimation_result1:Stop()
			arg2.canrunfromslice.Value = false
			arg2.heavyhit.Value = false
		end)
	end)
end
return module