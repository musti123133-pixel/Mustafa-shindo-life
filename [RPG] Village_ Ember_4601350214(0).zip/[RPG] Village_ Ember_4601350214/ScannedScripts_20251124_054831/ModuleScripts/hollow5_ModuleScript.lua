-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:44:57
-- Luau version 6, Types version 3
-- Time taken: 0.008669 seconds

local module = {}
local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
local RunService_upvr = game:GetService("RunService")
local TweenService_upvr = game:GetService("TweenService")
function module.start(arg1) -- Line 44
	--[[ Upvalues[3]:
		[1]: ReplicatedStorage_upvr (readonly)
		[2]: RunService_upvr (readonly)
		[3]: TweenService_upvr (readonly)
	]]
	spawn(function() -- Line 45
		--[[ Upvalues[4]:
			[1]: arg1 (readonly)
			[2]: ReplicatedStorage_upvr (copied, readonly)
			[3]: RunService_upvr (copied, readonly)
			[4]: TweenService_upvr (copied, readonly)
		]]
		local var6 = arg1
		local var7_upvr = var6
		local var8 = false
		if var6.Name == game.Players.LocalPlayer.Name then
			var8 = true
		end
		if var8 then
			workspace.Camera.CameraType = Enum.CameraType.Scriptable
			local tick_result1_upvw = tick()
			local LightningBolt_upvr = require(ReplicatedStorage_upvr.LightningBolt)
			local HumanoidRootPart_upvr = var7_upvr:WaitForChild("HumanoidRootPart")
			local any_Connect_result1_upvw = RunService_upvr.RenderStepped:Connect(function() -- Line 65
				--[[ Upvalues[4]:
					[1]: tick_result1_upvw (read and write)
					[2]: var7_upvr (readonly)
					[3]: LightningBolt_upvr (readonly)
					[4]: HumanoidRootPart_upvr (readonly)
				]]
				if tick_result1_upvw < tick() + 0.4 then
					tick_result1_upvw = tick()
					local Attachment_2 = Instance.new("Attachment", workspace.Terrain)
					Attachment_2.Position = var7_upvr.HumanoidRootPart.Position + Vector3.new(math.random(-8, 8), math.random(-8, 8), math.random(-8, 8))
					local Attachment_3 = Instance.new("Attachment", workspace.Terrain)
					Attachment_3.Position = (var7_upvr.HumanoidRootPart.CFrame * CFrame.new(0, 0, 0)).p
					game.Debris:AddItem(Attachment_3, 1)
					game.Debris:AddItem(Attachment_2, 1)
					local any_new_result1_2 = LightningBolt_upvr.new(Attachment_2, Attachment_3, 30)
					any_new_result1_2.PulseSpeed = 4
					any_new_result1_2.PulseLength = 0.4
					any_new_result1_2.Thickness = 0.4
					any_new_result1_2.FadeLength = 0.25
					any_new_result1_2.Color = Color3.fromRGB(255, 0, 0)
					local var16 = HumanoidRootPart_upvr.CFrame * CFrame.new(math.random(-10, 10), -3, math.random(-10, 10))
					local Attachment_4 = Instance.new("Attachment", workspace.Terrain)
					Attachment_4.Position = var16.p
					local Attachment = Instance.new("Attachment", workspace.Terrain)
					Attachment.Position = var16.p + Vector3.new(0, 20, 0)
					game.Debris:AddItem(Attachment, 2)
					game.Debris:AddItem(Attachment_4, 2)
					local any_new_result1 = LightningBolt_upvr.new(Attachment_4, Attachment, 30)
					any_new_result1.PulseSpeed = 4
					any_new_result1.PulseLength = 1
					any_new_result1.Thickness = 0.8
					any_new_result1.FadeLength = 0.25
					any_new_result1.Color = Color3.fromRGB(0, 0, 0)
				end
				workspace.Camera.CFrame = var7_upvr.Head.CFrame * CFrame.new(0, 0, -4) * CFrame.Angles(0.1, math.pi, 0)
			end)
			task.delay(0.9, function() -- Line 130
				--[[ Upvalues[2]:
					[1]: any_Connect_result1_upvw (read and write)
					[2]: var7_upvr (readonly)
				]]
				any_Connect_result1_upvw:Disconnect()
				workspace.Camera.CFrame = var7_upvr.HumanoidRootPart.CFrame * CFrame.new(0, 0, -8) * CFrame.Angles(0.1, math.pi, 0)
			end)
			task.delay(1.8, function() -- Line 137
				workspace.Camera.CameraType = Enum.CameraType.Custom
			end)
			local clone_upvr = script.aabv:Clone()
			clone_upvr.Parent = game.Lighting
			local TweenInfo_new_result1_upvr = TweenInfo.new(0.2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
			TweenService_upvr:Create(clone_upvr, TweenInfo_new_result1_upvr, {
				Contrast = 0;
				Saturation = -1;
			}):Play()
			game.Debris:AddItem(clone_upvr, 8)
			task.delay(0.5, function() -- Line 182
				--[[ Upvalues[3]:
					[1]: TweenService_upvr (copied, readonly)
					[2]: clone_upvr (readonly)
					[3]: TweenInfo_new_result1_upvr (readonly)
				]]
				TweenService_upvr:Create(clone_upvr, TweenInfo_new_result1_upvr, {
					Contrast = 0;
					Saturation = 0;
					TintColor = Color3.fromRGB(255, 255, 255);
				}):Play()
			end)
		end
	end)
end
return module