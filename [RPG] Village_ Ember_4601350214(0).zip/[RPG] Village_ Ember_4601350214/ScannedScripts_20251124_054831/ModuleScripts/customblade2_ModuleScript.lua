-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:32:32
-- Luau version 6, Types version 3
-- Time taken: 0.004327 seconds

local module = {
	idlanim = function() -- Line 5
		return 4855855974
	end;
	combat = function() -- Line 10
		return {9163327703, 9163329683, 9163332472, 9163334949}
	end;
}
local function _(arg1, arg2) -- Line 15, Named "CreateRegion3FromLocAndSize"
	local var5 = arg2 / 2
	return Region3.new(arg1 - var5, arg1 + var5)
end
function PointOnCircle(arg1, arg2, arg3, arg4) -- Line 23
	return arg1 + arg3 * math.cos(arg4), arg2 + arg3 * math.sin(arg4)
end
function module.block() -- Line 32
	return 5017767564
end
function module.typ() -- Line 36
	return "saber"
end
function module.power() -- Line 40
	return 4816744006
end
function module.slicedelay() -- Line 44
	return 0.3
end
function module.damage() -- Line 47
	return 10
end
function module.specdamage(arg1) -- Line 50
	return 1.2 * (require(ReplicatedStorage:WaitForChild("GlobalFunctions")).getallstats(arg1).taijutsu + 1.2)
end
ReplicatedStorage = game.ReplicatedStorage -- Setting global
function module.heavyattack(arg1, arg2) -- Line 64
	if script.stamina.Value <= arg2.stamina2.Value then
		arg2.stamina2.Value = arg2.stamina2.Value - script.stamina.Value
	else
		return script.stamina.Value
	end
	spawn(function() -- Line 79
		--[[ Upvalues[2]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
		]]
		local var14 = arg1
		local any_GetPlayerFromCharacter_result1 = game.Players:GetPlayerFromCharacter(var14)
		if any_GetPlayerFromCharacter_result1 == nil then
			any_GetPlayerFromCharacter_result1 = var14
		else
		end
		if require(ReplicatedStorage:WaitForChild("GlobalFunctions")).haspuppet(any_GetPlayerFromCharacter_result1) then
		end
	end)
end
return module