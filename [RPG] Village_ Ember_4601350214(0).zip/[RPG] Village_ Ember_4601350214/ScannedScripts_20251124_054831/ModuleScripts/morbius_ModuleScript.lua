-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:44:52
-- Luau version 6, Types version 3
-- Time taken: 0.005134 seconds

local module = {}
local ClientEffects_upvr = workspace.ClientEffects
local TweenService_upvr = game:GetService("TweenService")
function module.make(arg1, arg2) -- Line 44
	--[[ Upvalues[2]:
		[1]: ClientEffects_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	spawn(function() -- Line 45
		--[[ Upvalues[4]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: ClientEffects_upvr (copied, readonly)
			[4]: TweenService_upvr (copied, readonly)
		]]
		local var5 = arg2
		local clone_upvr_2 = script.Part:Clone()
		clone_upvr_2.Parent = workspace.ClientEffects
		clone_upvr_2.CFrame = var5
		delay(2, function() -- Line 63
			--[[ Upvalues[1]:
				[1]: clone_upvr_2 (readonly)
			]]
			clone_upvr_2.fire.Enabled = false
		end)
		game.Debris:AddItem(clone_upvr_2, 4)
		local clone_upvr = script.beastbomb:Clone()
		clone_upvr.Parent = ClientEffects_upvr
		clone_upvr.Size = Vector3.new()
		clone_upvr.CFrame = var5
		TweenService_upvr:Create(clone_upvr, TweenInfo.new(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
			Size = Vector3.new(30, 30, 30);
		}):Play()
		delay(0.5, function() -- Line 101
			--[[ Upvalues[2]:
				[1]: TweenService_upvr (copied, readonly)
				[2]: clone_upvr (readonly)
			]]
			TweenService_upvr:Create(clone_upvr, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 9, true, 0), {
				Size = Vector3.new(35, 35, 35);
			}):Play()
			delay(1, function() -- Line 127
				--[[ Upvalues[2]:
					[1]: TweenService_upvr (copied, readonly)
					[2]: clone_upvr (copied, readonly)
				]]
				TweenService_upvr:Create(clone_upvr, TweenInfo.new(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
					Transparency = 1;
					Size = Vector3.new(0, 0, 0);
				}):Play()
				game.Debris:AddItem(clone_upvr, 1)
			end)
		end)
	end)
end
return module