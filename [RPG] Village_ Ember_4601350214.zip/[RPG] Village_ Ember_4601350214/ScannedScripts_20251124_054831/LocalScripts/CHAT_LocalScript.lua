-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:43:22
-- Luau version 6, Types version 3
-- Time taken: 0.000959 seconds

if workspace:FindFirstChild("CC") or workspace.custo.Value then
	chat = game.Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("Chat") -- Setting global
	chat.Frame.ChatChannelParentFrame.Visible = false
	chat.Frame.ChatBarParentFrame.Position = UDim2.new(0, 0, 0.23, -42)
end