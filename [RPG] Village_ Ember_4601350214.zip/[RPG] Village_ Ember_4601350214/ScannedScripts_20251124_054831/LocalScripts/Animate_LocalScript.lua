-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:48:20
-- Luau version 6, Types version 3
-- Time taken: 0.176288 seconds

-- KONSTANTERROR: [0] 1. Error Block 32 start (CF ANALYSIS FAILED)
local LocalPlayer_upvr = game.Players.LocalPlayer
local Parent_upvr = script.Parent
local _ = Parent_upvr:WaitForChild("Torso")
local Humanoid_upvr = Parent_upvr:WaitForChild("Humanoid")
local combat_upvr = Parent_upvr:WaitForChild("combat")
local Animation_8 = Instance.new("Animation")
wait(2)
for _, v in pairs(Humanoid_upvr:GetPlayingAnimationTracks()) do
	v:Stop()
end
local var12_upvw = false
Animation_8.AnimationId = "http://www.roblox.com/asset/?id="..9128898804
if LocalPlayer_upvr.statz.race.Value == "celestial" then
	Animation_8.AnimationId = "http://www.roblox.com/asset/?id="..8461403091
end
local any_LoadAnimation_result1_9_upvw = Humanoid_upvr:LoadAnimation(Animation_8)
any_LoadAnimation_result1_9_upvw:Play()
any_LoadAnimation_result1_9_upvw.Priority = Enum.AnimationPriority.Action
Humanoid_upvr:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
Humanoid_upvr:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
local Animation_18 = Instance.new("Animation")
Animation_18.AnimationId = "http://www.roblox.com/asset/?id="..9146333649
if LocalPlayer_upvr.statz.race.Value == "celestial" then
	Animation_18.AnimationId = "http://www.roblox.com/asset/?id="..8461421332
end
local any_LoadAnimation_result1_11_upvw = Humanoid_upvr:LoadAnimation(Animation_18)
any_LoadAnimation_result1_11_upvw.Priority = Enum.AnimationPriority.Action2
local Animation_6 = Instance.new("Animation")
Animation_6.AnimationId = "http://www.roblox.com/asset/?id="..9102156017
local any_LoadAnimation_result1_6_upvr = Humanoid_upvr:LoadAnimation(Animation_6)
any_LoadAnimation_result1_6_upvr.Priority = Enum.AnimationPriority.Action3
Humanoid_upvr.JumpPower = 50
Humanoid_upvr:SetStateEnabled(Enum.HumanoidStateType.Swimming, false)
local Animation_2 = Instance.new("Animation")
Animation_2.AnimationId = "http://www.roblox.com/asset/?id="..9148605541
local any_LoadAnimation_result1_3_upvr = Humanoid_upvr:LoadAnimation(Animation_2)
any_LoadAnimation_result1_11_upvw.Priority = Enum.AnimationPriority.Action2
Parent_upvr.ChildAdded:Connect(function(arg1) -- Line 66
	--[[ Upvalues[1]:
		[1]: any_LoadAnimation_result1_3_upvr (readonly)
	]]
	spawn(function() -- Line 68
		--[[ Upvalues[1]:
			[1]: arg1 (readonly)
		]]
		delay(0.2, function() -- Line 70
			--[[ Upvalues[1]:
				[1]: arg1 (readonly)
			]]
			if arg1.Name == "treejump" then
				game.Debris:AddItem(arg1, 2)
			end
		end)
	end)
	if arg1.Name == "intangiblezetsu" or arg1.Name == "zetsudown" then
		any_LoadAnimation_result1_3_upvr:Play()
	end
end)
Parent_upvr.ChildRemoved:Connect(function(arg1) -- Line 87
	--[[ Upvalues[2]:
		[1]: Parent_upvr (readonly)
		[2]: any_LoadAnimation_result1_3_upvr (readonly)
	]]
	if arg1.Name == "intangiblezetsu" or arg1.Name == "zetsudown" then
		if Parent_upvr:FindFirstChild("intangiblezetsu") then return end
		any_LoadAnimation_result1_3_upvr:Stop()
	end
end)
local tbl_upvr = {
	cursemarksasuke2 = {
		run = 4894507334;
		idle = 5522925827;
	};
	cursemark = {
		run = 4894507334;
		idle = 5522925827;
	};
	mechaspiritmode = {
		run = 5186671969;
		idle = 5186631045;
	};
	jin = {
		run = 5186671969;
		idle = 5186631045;
	};
	jin7 = {
		run = 5205320260;
		idle = 5205315808;
	};
	jin1 = {
		run = 9146333649;
		idle = 5804488295;
	};
	jin2 = {
		run = 5186671969;
		idle = 5804519152;
	};
	lightjokei = {
		run = 9146333649;
		idle = 5503972794;
	};
	darkjokei = {
		run = 9146333649;
		idle = 5503972794;
	};
	goldjokei = {
		run = 9146333649;
		idle = 5503972794;
	};
	lightjokei2 = {
		run = 9146333649;
		idle = 6846996709;
	};
	lightjokei3 = {
		run = 9146333649;
		idle = 6847060084;
	};
	jotaroshizen = {
		run = 9146333649;
		idle = 6972267960;
	};
	jotaroshizen2 = {
		run = 9146333649;
		idle = 6972315183;
	};
	byakugan = {
		run = 9146333649;
		idle = 5503972794;
	};
	byakuganv2 = {
		run = 9146333649;
		idle = 5606711955;
	};
	byakugangold = {
		run = 9146333649;
		idle = 5503972794;
	};
	byakugangoldv2 = {
		run = 9146333649;
		idle = 5606711955;
	};
	papermode = {
		idle = 5828705869;
		run = 5828712995;
	};
	tentail = {
		run = 8461421332;
		idle = 8461403091;
	};
	dokutengoku = {
		idle = 8046316420;
		run = 5334608895;
	};
	dokuscorpion = {
		idle = 8046316420;
		run = 5334608895;
	};
	tentailx = {
		run = 8461421332;
		idle = 8461403091;
	};
	shindairengoku = {
		idle = 5334600504;
		run = 5334608895;
	};
	shindairamen = {
		run = 8461421332;
		idle = 8461403091;
	};
	shindairengokuyang = {
		idle = 5334600504;
		run = 5334608895;
	};
	inuzuka = {
		idle = 5886839431;
		run = 5186671969;
	};
	cursemark3 = {
		run = 6271303131;
		idle = 6271249810;
	};
	kenichi = {
		run = 9146333649;
		idle = 6280848680;
	};
	kenichi2 = {
		run = 9146333649;
		idle = 6280879368;
	};
	ryujikenichimode = {
		run = 9146333649;
		idle = 6280848680;
	};
	ryujikenichiwhitemode = {
		run = 9146333649;
		idle = 6280848680;
	};
	brucekenichi = {
		run = 9146333649;
		idle = 9631194731;
	};
	renshiki = {
		idle = 6480462628;
		run = 6480484558;
	};
	renshikigold = {
		idle = 6480462628;
		run = 6480484558;
	};
	renshikiruby = {
		idle = 6480462628;
		run = 6480484558;
	};
	rabbit = {
		run = 5186671969;
		idle = 5186631045;
	};
	vine = {
		idle = 6781350978;
		run = 6781745880;
	};
	xenodokei = {
		idle = 7100770261;
		run = 7101633487;
	};
	xenodokeiazure = {
		idle = 7100770261;
		run = 7101633487;
	};
	karmafate3 = {
		idle = 5334600504;
		run = 5334608895;
	};
	jayramaki = {
		run = 9146333649;
		idle = 7747717246;
	};
	jayramazure = {
		run = 9146333649;
		idle = 7747717246;
	};
	raionrengokumode = {
		run = 9146333649;
		idle = 7859398006;
	};
	raionsengokumode = {
		run = 9146333649;
		idle = 7859398006;
	};
	raionazuremode = {
		run = 9146333649;
		idle = 7859398006;
	};
	satorirengokumode = {
		idle = 5334600504;
		run = 5334608895;
	};
	satorigoldmode = {
		idle = 5334600504;
		run = 5334608895;
	};
	bankaiinfernomode = {
		run = 9146333649;
		idle = 7899801281;
	};
	riserinfernomode = {
		run = 9146333649;
		idle = 7899801281;
	};
	toshiroice = {
		run = 8346423764;
		idle = 8346411670;
	};
	subzeroice = {
		run = 8346423764;
		idle = 8346411670;
	};
	kagoku = {
		run = 8461421332;
		idle = 8461403091;
	};
	kagokuplatinum = {
		run = 8461421332;
		idle = 8461403091;
	};
	sengoku = {
		run = 9146333649;
		idle = 9128898804;
	};
	sengokuinferno = {
		run = 9146333649;
		idle = 9128898804;
	};
	tenseigan = {
		run = 8461421332;
		idle = 8461403091;
	};
	tengokuplatinum = {
		run = 8461421332;
		idle = 8461403091;
	};
	morbius = {
		run = 8666556431;
		idle = 8666519893;
	};
	borumaki = {
		run = 9146333649;
		idle = 9128898804;
	};
	borumakigold = {
		run = 9146333649;
		idle = 9128898804;
	};
	borumakigaiden = {
		run = 9146333649;
		idle = 9134872501;
	};
	borumakigaidenskin = {
		run = 9146333649;
		idle = 9134872501;
	};
	narumakisixpaths = {
		run = 9146333649;
		idle = 9134872501;
	};
	narumakisixpaths2 = {
		run = 9146333649;
		idle = 9230595186;
	};
	raiongaiden = {
		run = 9146333649;
		idle = 9290951406;
	};
	sengokugaiden = {
		run = 9146333649;
		idle = 9290951406;
	};
	jinshikimode = {
		run = 8461421332;
		idle = 8461403091;
	};
	mitsuky = {
		idle = 10558539180;
		run = 9146333649;
	};
	mitsukyplatinum = {
		idle = 10558539180;
		run = 9146333649;
	};
	cursemarkREWORK = {
		idle = 10640896219;
		run = 9146333649;
	};
	cursemarkREWORK2 = {
		idle = 10639657905;
		run = 10639676656;
	};
	godash = {
		idle = 12302454994;
		run = 9146333649;
	};
	hollow1 = {
		run = 9146333649;
		idle = 9445805614;
	};
	hollow12 = {
		run = 9146333649;
		idle = 9452350803;
	};
	hollow2 = {
		run = 9146333649;
		idle = 9676808926;
	};
	hollow4 = {
		run = 9146333649;
		idle = 10734467587;
	};
	hollow5 = {
		run = 9146333649;
		idle = 10913704782;
	};
	hollow6 = {
		run = 9146333649;
		idle = 11117227965;
	};
	hollow22 = {
		run = 9146333649;
		idle = 9452350803;
	};
	hollow3 = {
		run = 9146333649;
		idle = 10489139634;
	};
	hollow7 = {
		run = 9146333649;
		idle = 11117227965;
	};
	hollow7mode = {
		run = 11394961846;
		idle = 11394954054;
	};
	hollow8 = {
		run = 9146333649;
		idle = 11587407121;
	};
	hollow9 = {
		run = 11891816366;
		idle = 11891701022;
	};
	raidensaberu = {
		run = 8461421332;
		idle = 8461403091;
	};
	raidengold = {
		run = 8461421332;
		idle = 8461403091;
	};
	kamakiakuma = {
		run = 9146333649;
		idle = 11771995952;
	};
	kamakiakumainf = {
		run = 9146333649;
		idle = 11771995952;
	};
	RELL = {
		run = 9146333649;
		idle = 14247273314;
	};
}
local Animation = Instance.new("Animation")
Animation.AnimationId = "http://www.roblox.com/asset/?id="..5191938054
local any_LoadAnimation_result1_5_upvr = Humanoid_upvr:LoadAnimation(Animation)
any_LoadAnimation_result1_5_upvr:Play()
any_LoadAnimation_result1_5_upvr.Priority = Enum.AnimationPriority.Action
local Animation_19 = Instance.new("Animation")
Animation_19.AnimationId = "http://www.roblox.com/asset/?id="..0
local any_LoadAnimation_result1_12_upvr = Humanoid_upvr:LoadAnimation(Animation_19)
any_LoadAnimation_result1_12_upvr:Play()
any_LoadAnimation_result1_12_upvr.Priority = Enum.AnimationPriority.Action
local Animation_21 = Instance.new("Animation")
Animation_21.AnimationId = "http://www.roblox.com/asset/?id="..5450945815
local any_LoadAnimation_result1 = Humanoid_upvr:LoadAnimation(Animation_21)
any_LoadAnimation_result1:Play()
any_LoadAnimation_result1.Priority = Enum.AnimationPriority.Action
local Animation_22 = Instance.new("Animation")
Animation_22.AnimationId = "http://www.roblox.com/asset/?id="..5924199161
local any_LoadAnimation_result1_10 = Humanoid_upvr:LoadAnimation(Animation_22)
any_LoadAnimation_result1_10:Play()
any_LoadAnimation_result1_10.Priority = Enum.AnimationPriority.Action
local Animation_4 = Instance.new("Animation")
Animation_4.AnimationId = "http://www.roblox.com/asset/?id="..6971428994
local any_LoadAnimation_result1_2 = Humanoid_upvr:LoadAnimation(Animation_4)
any_LoadAnimation_result1_2:Play()
any_LoadAnimation_result1_2.Priority = Enum.AnimationPriority.Action
local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
function returntonroamlanim() -- Line 612
	--[[ Upvalues[6]:
		[1]: any_LoadAnimation_result1_11_upvw (read and write)
		[2]: any_LoadAnimation_result1_9_upvw (read and write)
		[3]: LocalPlayer_upvr (readonly)
		[4]: Parent_upvr (readonly)
		[5]: ReplicatedStorage_upvr (readonly)
		[6]: Humanoid_upvr (readonly)
	]]
	any_LoadAnimation_result1_11_upvw:Stop()
	any_LoadAnimation_result1_9_upvw:Stop()
	local Value = LocalPlayer_upvr.statz.fightingstyle.Value
	if workspace:FindFirstChild("arena") or Parent_upvr:FindFirstChild("forcearena") then
		Value = ""
		local SOME = ReplicatedStorage_upvr.arenacosmetics:FindFirstChild(LocalPlayer_upvr.statz.arena.character.Value)
		if SOME and SOME:FindFirstChild("fightingstyle") then
			Value = SOME:FindFirstChild("fightingstyle").Value
		end
	end
	SOME = 9128898804
	local var128 = SOME
	if LocalPlayer_upvr.statz.race.Value == "celestial" then
		var128 = 8461403091
	end
	local Animation_3 = Instance.new("Animation")
	Animation_3.AnimationId = "http://www.roblox.com/asset/?id="..var128
	local SOME_2 = ReplicatedStorage_upvr.alljutsu.FIGHTINGSTYLES:FindFirstChild(Value)
	if SOME_2 then
		Animation_3 = SOME_2.animations.idle
	end
	any_LoadAnimation_result1_9_upvw = Humanoid_upvr:LoadAnimation(Animation_3)
	any_LoadAnimation_result1_9_upvw:Play()
	any_LoadAnimation_result1_9_upvw.Priority = Enum.AnimationPriority.Action
	local Animation_17 = Instance.new("Animation")
	Animation_17.AnimationId = "http://www.roblox.com/asset/?id="..9146333649
	if LocalPlayer_upvr.statz.race.Value == "celestial" then
		Animation_17.AnimationId = "http://www.roblox.com/asset/?id="..8461421332
	end
	any_LoadAnimation_result1_11_upvw.Priority = Enum.AnimationPriority.Action2
	any_LoadAnimation_result1_11_upvw = Humanoid_upvr:LoadAnimation(Animation_17)
	if not workspace:FindFirstChild("arena") then
	end
end
returntonroamlanim()
combat_upvr:WaitForChild("KG")
wait(1)
function upd() -- Line 711
	--[[ Upvalues[6]:
		[1]: combat_upvr (readonly)
		[2]: tbl_upvr (readonly)
		[3]: Parent_upvr (readonly)
		[4]: any_LoadAnimation_result1_11_upvw (read and write)
		[5]: any_LoadAnimation_result1_9_upvw (read and write)
		[6]: Humanoid_upvr (readonly)
	]]
	local var132
	if var132 == "karmaember" or var132 == "karmadunes" or var132 == "karmahaze" or var132 == "karmanimbus" or var132 == "karmaobelisk" or combat_upvr.KG.currentmode.form.Value == 3 then
		var132 = "karmafate3"
	end
	if var132 == "cursemarkREWORK" and combat_upvr.KG.currentmode.form.Value == 2 then
		var132 = "cursemarkREWORK2"
	end
	if var132 == "hollow1" and 2 < combat_upvr.KG.currentmode.form.Value then
		var132 = "hollow12"
	end
	if var132 == "hollow7" and 3 < combat_upvr.KG.currentmode.form.Value then
		var132 = "hollow7mode"
	end
	if var132 == "raionrengokumode" and combat_upvr.KG.currentmode.form.Value == 2 then
		var132 = "cursemark"
	end
	if var132 == "raionsengokumode" and combat_upvr.KG.currentmode.form.Value == 2 then
		var132 = "cursemark"
	end
	if var132 == "raionazuremode" and combat_upvr.KG.currentmode.form.Value == 2 then
		var132 = "cursemark"
	end
	if var132 == "" then
		returntonroamlanim()
		var132 = combat_upvr.KG.currentkg.Value
	end
	if string.sub(var132, 1, 4) == "tail" or var132 == "rabbit" then
		if 99 <= combat_upvr.KG.currentmode.form.Value then
			var132 = ""
			-- KONSTANTWARNING: GOTO [166] #100
		end
	elseif not tbl_upvr[var132] then
		returntonroamlanim()
		var132 = combat_upvr.KG.currentkg.Value
	end
	if var132 == "" then
		returntonroamlanim()
	else
		if var132 == "kamakiakuma" and combat_upvr.KG.currentkg.form.Value == 2 then
			returntonroamlanim()
			return
		end
		if var132 == "kamakiakumainf" and combat_upvr.KG.currentkg.form.Value == 2 then
			returntonroamlanim()
			return
		end
		if var132 == "narumakisixpaths" and combat_upvr.KG.currentkg.form.Value == 2 then
			var132 = "narumakisixpaths2"
		end
		if var132 == "borumaki" and combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "kagoku"
		end
		if var132 == "borumakigold" and combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "kagoku"
		end
		if var132 == "kamaki" and combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "kagoku"
		end
		if var132 == "kamakipurple" and combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "kagoku"
		end
		if var132 == "sengoku" and combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "kagokuplatinum"
		end
		if var132 == "sengokuinferno" and combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "kagokuplatinum"
		end
		if var132 == "byakugan" or var132 == "byakugangold" or combat_upvr.KG.currentkg.form.Value == 2 or combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "byakuganv2"
		end
		if var132 == "lightjokei" and combat_upvr.KG.currentkg.form.Value == 2 then
			var132 = "lightjokei2"
		end
		if var132 == "lightjokei" and combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "lightjokei3"
		end
		if var132 == "jotaroshizen" and combat_upvr.KG.currentkg.form.Value == 2 then
			var132 = "jotaroshizen2"
		end
		if var132 == "darkjokei" and combat_upvr.KG.currentkg.form.Value == 2 then
			var132 = "lightjokei2"
		end
		if var132 == "goldjokei" and combat_upvr.KG.currentkg.form.Value == 2 then
			var132 = "lightjokei2"
		end
		if var132 == "darkjokei" and combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "lightjokei3"
		end
		if var132 == "goldjokei" and combat_upvr.KG.currentkg.form.Value == 3 then
			var132 = "lightjokei3"
		end
		if var132 == "xenodokei" and combat_upvr.KG.currentkg.form.Value == 2 then
			returntonroamlanim()
			return
		end
		if var132 == "xenodokeiazure" and combat_upvr.KG.currentkg.form.Value == 2 then
			returntonroamlanim()
			return
		end
		if var132 == "kenichi" and Parent_upvr.combat.KG.currentkg.form.Value == 2 then
			var132 = "kenichi2"
		end
		if string.sub(var132, 1, 4) == "tail" or var132 == "rabbit" then
			if var132 == "tail7" then
				var132 = "jin7"
			elseif var132 == "tail1" then
				var132 = "jin1"
			elseif var132 == "tail2" then
				var132 = "jin2"
			else
				var132 = "jin"
			end
		end
		if var132 == "mechaspiritmode" then
			if 2 <= combat_upvr.KG.currentmode.form.Value then
				var132 = "jin"
			else
				returntonroamlanim()
				return
			end
		end
		if var132 == "cursemark" then
			if combat_upvr.KG.currentmode.form.Value == 2 then
				var132 = "cursemarksasuke2"
			else
				returntonroamlanim()
				return
			end
		end
		print(var132)
		if tbl_upvr[var132] then
			local var133 = tbl_upvr[var132]
			any_LoadAnimation_result1_11_upvw:Stop()
			any_LoadAnimation_result1_9_upvw:Stop()
			local Animation_5 = Instance.new("Animation")
			Animation_5.AnimationId = "http://www.roblox.com/asset/?id="..var133.idle
			any_LoadAnimation_result1_9_upvw = Humanoid_upvr:LoadAnimation(Animation_5)
			any_LoadAnimation_result1_9_upvw.Priority = Enum.AnimationPriority.Action
			any_LoadAnimation_result1_9_upvw:Play()
			local Animation_16 = Instance.new("Animation")
			Animation_16.AnimationId = "http://www.roblox.com/asset/?id="..var133.run
			any_LoadAnimation_result1_11_upvw = Humanoid_upvr:LoadAnimation(Animation_16)
			any_LoadAnimation_result1_11_upvw.Priority = Enum.AnimationPriority.Action2
		end
	end
end
upd()
combat_upvr.KG.currentmode.Changed:connect(function(arg1) -- Line 1058
	upd()
end)
combat_upvr.KG.currentmode.form.Changed:connect(function(arg1) -- Line 1063
	upd()
end)
combat_upvr.KG.currentkg.Changed:connect(function(arg1) -- Line 1068
	upd()
end)
combat_upvr.KG.currentkg.form.Changed:connect(function(arg1) -- Line 1072
	upd()
end)
LocalPlayer_upvr.statz.fightingstyle.Changed:connect(function(arg1) -- Line 1077
	upd()
end)
LocalPlayer_upvr.statz.race.Changed:connect(function(arg1) -- Line 1081
	returntonroamlanim()
	upd()
end)
local Animation_20_upvr = Instance.new("Animation")
Animation_20_upvr.AnimationId = "rbxassetid://"..0
local any_LoadAnimation_result1_7_upvw = Humanoid_upvr:LoadAnimation(Animation_20_upvr)
Humanoid_upvr:GetPropertyChangedSignal("SeatPart"):Connect(function() -- Line 1095
	--[[ Upvalues[3]:
		[1]: any_LoadAnimation_result1_7_upvw (read and write)
		[2]: Humanoid_upvr (readonly)
		[3]: Animation_20_upvr (readonly)
	]]
	any_LoadAnimation_result1_7_upvw:Stop()
	if Humanoid_upvr.SeatPart and Humanoid_upvr.SeatPart:FindFirstChild("ANIM") then
		Animation_20_upvr.AnimationId = "rbxassetid://"..Humanoid_upvr.SeatPart.ANIM.Value
		any_LoadAnimation_result1_7_upvw = Humanoid_upvr:LoadAnimation(Animation_20_upvr)
		any_LoadAnimation_result1_7_upvw.Priority = Enum.AnimationPriority.Action4
		any_LoadAnimation_result1_7_upvw:Play()
	end
end)
Humanoid_upvr:GetPropertyChangedSignal("Jump"):Connect(function() -- Line 1110
	--[[ Upvalues[2]:
		[1]: Parent_upvr (readonly)
		[2]: Humanoid_upvr (readonly)
	]]
	if Parent_upvr.combat.disable.Value or Parent_upvr.combat:FindFirstChild("attacked") or Parent_upvr.combat:FindFirstChild("landed") then
		Humanoid_upvr.Jump = false
		jumping = false -- Setting global
	end
	if Humanoid_upvr.PlatformStand or Parent_upvr.combat.ragdoll.Value then
		Humanoid_upvr.Jump = false
		jumping = false -- Setting global
	end
end)
local Animation_15 = Instance.new("Animation")
Animation_15.AnimationId = "rbxassetid://"..9102293591
local any_LoadAnimation_result1_8_upvr = Humanoid_upvr:LoadAnimation(Animation_15)
any_LoadAnimation_result1_8_upvr.Priority = Enum.AnimationPriority.Action3
local Animation_13 = Instance.new("Animation")
Animation_13.AnimationId = "rbxassetid://"..9102293591
Humanoid_upvr:LoadAnimation(Animation_13).Priority = Enum.AnimationPriority.Action3
local Animation_7 = Instance.new("Animation")
Animation_7.AnimationId = "rbxassetid://"..4830496617
local any_LoadAnimation_result1_4_upvr = Humanoid_upvr:LoadAnimation(Animation_7)
any_LoadAnimation_result1_4_upvr.Priority = Enum.AnimationPriority.Action2
local Sound_upvr_2 = Instance.new("Sound")
Sound_upvr_2.SoundId = "rbxassetid://9165300727"
Sound_upvr_2.Volume = 1
Sound_upvr_2.Parent = script
local Sound_upvr_3 = Instance.new("Sound")
Sound_upvr_3.SoundId = "rbxassetid://9158959716"
Sound_upvr_3.Volume = 0.4
Sound_upvr_3.Parent = script
local Sound_upvr = Instance.new("Sound")
Sound_upvr.SoundId = "rbxassetid://9129760990"
Sound_upvr.Volume = 1
Sound_upvr.Parent = script
local var154_upvw = false
lowestFallHeight = 20 -- Setting global
maxFallHeight = 100 -- Setting global
isFalling = false -- Setting global
deb = false -- Setting global
Humanoid_upvr.WalkSpeed = 25
local var155_upvw = false
Humanoid_upvr.FreeFalling:connect(function() -- Line 1277
	--[[ Upvalues[2]:
		[1]: any_LoadAnimation_result1_11_upvw (read and write)
		[2]: any_LoadAnimation_result1_6_upvr (readonly)
	]]
	if jumping then
	else
		any_LoadAnimation_result1_11_upvw:Stop()
		any_LoadAnimation_result1_6_upvr:Stop()
	end
end)
Humanoid_upvr.StateChanged:Connect(function(arg1, arg2) -- Line 1286
	--[[ Upvalues[6]:
		[1]: var154_upvw (read and write)
		[2]: any_LoadAnimation_result1_6_upvr (readonly)
		[3]: Parent_upvr (readonly)
		[4]: combat_upvr (readonly)
		[5]: any_LoadAnimation_result1_4_upvr (readonly)
		[6]: any_LoadAnimation_result1_8_upvr (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [33] 23. Error Block 17 start (CF ANALYSIS FAILED)
	if combat_upvr.wallwalk.Value then return end
	Parent_upvr.combat.update:FireServer("inair", true)
	do
		return
	end
	-- KONSTANTERROR: [33] 23. Error Block 17 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [51] 36. Error Block 19 start (CF ANALYSIS FAILED)
	if arg2 == Enum.HumanoidStateType.Landed then
		if Parent_upvr.combat.isinair.Value then
			Parent_upvr.combat.update:FireServer("inair", false)
		end
		any_LoadAnimation_result1_6_upvr:Stop()
		any_LoadAnimation_result1_4_upvr:Stop()
		if var154_upvw then
			any_LoadAnimation_result1_8_upvr:Play()
		end
	end
	-- KONSTANTERROR: [51] 36. Error Block 19 end (CF ANALYSIS FAILED)
end)
Humanoid_upvr.Running:connect(function(arg1) -- Line 1354
	--[[ Upvalues[8]:
		[1]: Humanoid_upvr (readonly)
		[2]: any_LoadAnimation_result1_11_upvw (read and write)
		[3]: any_LoadAnimation_result1_6_upvr (readonly)
		[4]: any_LoadAnimation_result1_4_upvr (readonly)
		[5]: any_LoadAnimation_result1_7_upvw (read and write)
		[6]: Parent_upvr (readonly)
		[7]: combat_upvr (readonly)
		[8]: tbl_upvr (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [4] 4. Error Block 2 start (CF ANALYSIS FAILED)
	any_LoadAnimation_result1_11_upvw:Stop()
	any_LoadAnimation_result1_6_upvr:Stop()
	any_LoadAnimation_result1_4_upvr:Stop()
	do
		return
	end
	-- KONSTANTERROR: [4] 4. Error Block 2 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [17] 14. Error Block 3 start (CF ANALYSIS FAILED)
	any_LoadAnimation_result1_7_upvw:Stop()
	-- KONSTANTERROR: [17] 14. Error Block 3 end (CF ANALYSIS FAILED)
end)
Parent_upvr.combat.deflect.Changed:connect(function(arg1) -- Line 1500
	--[[ Upvalues[3]:
		[1]: any_LoadAnimation_result1_11_upvw (read and write)
		[2]: any_LoadAnimation_result1_6_upvr (readonly)
		[3]: any_LoadAnimation_result1_4_upvr (readonly)
	]]
	if arg1 then
		any_LoadAnimation_result1_11_upvw:Stop()
		any_LoadAnimation_result1_6_upvr:Stop()
		any_LoadAnimation_result1_4_upvr:Stop()
	end
end)
local var160_upvw = false
local var161_upvw = 0
local Animation_14_upvr = Instance.new("Animation")
Animation_14_upvr.AnimationId = "http://www.roblox.com/asset/?id="..0
puppetdashz = Humanoid_upvr:LoadAnimation(Animation_14_upvr) -- Setting global
Humanoid_upvr.Jumping:connect(function() -- Line 1530
	--[[ Upvalues[3]:
		[1]: combat_upvr (readonly)
		[2]: var155_upvw (read and write)
		[3]: Parent_upvr (readonly)
	]]
	if combat_upvr.canrunfromslice.Value or combat_upvr.canrun.Value or combat_upvr.disable.Value or combat_upvr:FindFirstChild("attacked") or combat_upvr:FindFirstChild("landed") or combat_upvr:FindFirstChild("nomove") then
		var155_upvw = true
	else
		if Parent_upvr.combat.disable.Value or Parent_upvr.combat:FindFirstChild("attacked") or Parent_upvr.combat:FindFirstChild("landed") then
			var155_upvw = true
			return
		end
		var155_upvw = true
	end
end)
local var164_upvw = false
local var165_upvw
local HumanoidRootPart_upvr = Parent_upvr.HumanoidRootPart
local Animator_upvr = Humanoid_upvr:WaitForChild("Animator")
local var168_upvw
function onJumpRequest() -- Line 1552
	--[[ Upvalues[14]:
		[1]: Humanoid_upvr (readonly)
		[2]: Parent_upvr (readonly)
		[3]: var164_upvw (read and write)
		[4]: var154_upvw (read and write)
		[5]: var165_upvw (read and write)
		[6]: var160_upvw (read and write)
		[7]: LocalPlayer_upvr (readonly)
		[8]: var161_upvw (read and write)
		[9]: HumanoidRootPart_upvr (readonly)
		[10]: Animation_14_upvr (readonly)
		[11]: Animator_upvr (readonly)
		[12]: var168_upvw (read and write)
		[13]: Sound_upvr_2 (readonly)
		[14]: any_LoadAnimation_result1_6_upvr (readonly)
	]]
	if Humanoid_upvr.PlatformStand or Parent_upvr.combat.ragdoll.Value then
	else
		if Parent_upvr.combat:FindFirstChild("attacked") then
		else
			Parent_upvr.combat.update:FireServer("spamspace")
		end
		if Parent_upvr.combat.canrunfromslice.Value or Parent_upvr.combat.canrun.Value or Parent_upvr.combat.disable.Value or Parent_upvr.combat:FindFirstChild("attacked") or Parent_upvr.combat:FindFirstChild("landed") or Parent_upvr.HumanoidRootPart.Anchored then return end
		if Humanoid_upvr.PlatformStand or Parent_upvr.combat.ragdoll.Value or Parent_upvr.combat:FindFirstChild("attacked") then return end
		if not Parent_upvr or not Humanoid_upvr or not Parent_upvr:IsDescendantOf(workspace) or Humanoid_upvr:GetState() == Enum.HumanoidStateType.Dead or Parent_upvr.fakehealth.Value <= 0 or Parent_upvr:FindFirstChild("stayonground") then return end
		if Parent_upvr.HumanoidRootPart:FindFirstChild("flyattachment") or Parent_upvr.HumanoidRootPart:FindFirstChild("stick") then return end
		if var164_upvw and not var154_upvw then
			var154_upvw = true
			Humanoid_upvr.JumpPower = var165_upvw * 1.5
			if var160_upvw then
				if LocalPlayer_upvr.statz.race.Value == "shinobi" then
					Humanoid_upvr.JumpPower = var165_upvw * 2.5
					-- KONSTANTWARNING: GOTO [520] #363
				end
			else
				local function INLINED() -- Internal function, doesn't exist in bytecode
					if 3 <= var161_upvw then
					else
						task.delay(0.3, function() -- Line 1618
							--[[ Upvalues[1]:
								[1]: var154_upvw (copied, read and write)
							]]
							var154_upvw = false
						end)
					end
					var161_upvw += 1
					return 0 < Humanoid_upvr.MoveDirection.magnitude
				end
				if LocalPlayer_upvr.statz.race.Value == "puppet" or workspace:FindFirstChild("EggEvent") or INLINED() and 2 <= var161_upvw and var161_upvw <= 3 then
					if 3 <= var161_upvw then
						var160_upvw = true
					end
					local var170 = CFrame.new(Parent_upvr.HumanoidRootPart.CFrame.p * Vector3.new(1, 0, 1), Parent_upvr.HumanoidRootPart.CFrame.p * Vector3.new(1, 0, 1) + Humanoid_upvr.MoveDirection) + Vector3.new(0, Parent_upvr.HumanoidRootPart.CFrame.Y, 0)
					Parent_upvr.HumanoidRootPart:ApplyImpulse(var170.lookVector * 1200)
					Parent_upvr.combat.update:FireServer("puppetboost")
					if math.acos((workspace.Camera.CFrame.p - HumanoidRootPart_upvr.Position).unit:Dot((var170 * CFrame.Angles(0, (math.pi/2), 0)).lookVector)) <= 1.0471975511965976 then
						puppetdashz:Stop()
						Animation_14_upvr.AnimationId = "http://www.roblox.com/asset/?id="..13193698000
						puppetdashz = Animator_upvr:LoadAnimation(Animation_14_upvr) -- Setting global
						puppetdashz.Priority = Enum.AnimationPriority.Action4
						puppetdashz:Play()
					elseif math.acos((workspace.Camera.CFrame.p - HumanoidRootPart_upvr.Position).unit:Dot((var170 * CFrame.Angles(0, (-math.pi/2), 0)).lookVector)) <= 1.0471975511965976 then
						puppetdashz:Stop()
						Animation_14_upvr.AnimationId = "http://www.roblox.com/asset/?id="..13193705218
						puppetdashz = Animator_upvr:LoadAnimation(Animation_14_upvr) -- Setting global
						puppetdashz.Priority = Enum.AnimationPriority.Action4
						puppetdashz:Play()
					elseif math.acos((workspace.Camera.CFrame.p - HumanoidRootPart_upvr.Position).unit:Dot(var170.lookVector)) <= 1.0471975511965976 then
						puppetdashz:Stop()
						Animation_14_upvr.AnimationId = "http://www.roblox.com/asset/?id="..13193769102
						puppetdashz = Animator_upvr:LoadAnimation(Animation_14_upvr) -- Setting global
						puppetdashz.Priority = Enum.AnimationPriority.Action4
						puppetdashz:Play()
					else
						puppetdashz:Stop()
						Animation_14_upvr.AnimationId = "http://www.roblox.com/asset/?id="..13193731783
						puppetdashz = Animator_upvr:LoadAnimation(Animation_14_upvr) -- Setting global
						puppetdashz.Priority = Enum.AnimationPriority.Action4
						puppetdashz:Play()
					end
				end
				if LocalPlayer_upvr.statz.race.Value == "shinobi" then
					var160_upvw = true
					task.delay(0.5, function() -- Line 1701
						--[[ Upvalues[1]:
							[1]: var154_upvw (copied, read and write)
						]]
						var154_upvw = false
					end)
				end
			end
			if Parent_upvr.combat.deflect.Value then
				Parent_upvr.combat.update:FireServer("sublog")
			end
			var168_upvw:Play()
			Sound_upvr_2:Play()
			Humanoid_upvr:ChangeState(Enum.HumanoidStateType.Jumping)
			any_LoadAnimation_result1_6_upvr:Stop()
			local IntValue_2 = Instance.new("IntValue")
			IntValue_2.Parent = Parent_upvr
			IntValue_2.Name = "dbljump"
			game.Debris:AddItem(IntValue_2, 1)
		end
	end
end
var154_upvw = false
var164_upvw = false
local var173_upvw = var164_upvw
var165_upvw = Humanoid_upvr.JumpPower
local Animation_12 = Instance.new("Animation")
Animation_12.AnimationId = "http://www.roblox.com/asset/?id="..9126997146
var168_upvw = Humanoid_upvr:LoadAnimation(Animation_12)
local var175_upvw = var168_upvw
var175_upvw.Priority = Enum.AnimationPriority.Action3
local Animation_11 = Instance.new("Animation")
Animation_11.AnimationId = "http://www.roblox.com/asset/?id="..9128029852
local any_LoadAnimation_result1_13_upvw = Humanoid_upvr:LoadAnimation(Animation_11)
any_LoadAnimation_result1_13_upvw.Priority = Enum.AnimationPriority.Action3
local Animation_10 = Instance.new("Animation")
Animation_10.AnimationId = "http://www.roblox.com/asset/?id="..5123189885
deathanimationz = Humanoid_upvr:LoadAnimation(Animation_10) -- Setting global
deathanimationz.Priority = Enum.AnimationPriority.Action3
local Animation_9_upvr = Instance.new("Animation")
Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..0
rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
rpanimz.Priority = Enum.AnimationPriority.Action4
local var180_upvw = false
local var181_upvw = false
local tbl_upvw = {}
function chatmsg(arg1) -- Line 1774
	--[[ Upvalues[9]:
		[1]: Parent_upvr (readonly)
		[2]: combat_upvr (readonly)
		[3]: LocalPlayer_upvr (readonly)
		[4]: var12_upvw (read and write)
		[5]: Animation_9_upvr (readonly)
		[6]: Humanoid_upvr (readonly)
		[7]: var180_upvw (read and write)
		[8]: var181_upvw (read and write)
		[9]: tbl_upvw (read and write)
	]]
	if string.sub(string.lower(arg1), 1, 2) == "/e" then
		Parent_upvr.combat.update:FireServer("emotes")
	end
	if combat_upvr.docrouch.Value then
		Parent_upvr.combat.update:FireServer("crouch", false)
	end
	if LocalPlayer_upvr.gamepasses:FindFirstChild("disrespectemotes") then
		if string.lower(arg1) == "/e lift" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..6399304088
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			Parent_upvr.combat.update:FireServer("emotes", "disrespect", "bar")
			var180_upvw = false
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
		if string.lower(arg1) == "/e pushup" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..6399314918
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			var180_upvw = false
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
		if string.lower(arg1) == "/e squat" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..6399332037
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			var180_upvw = false
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
		if string.lower(arg1) == "/e trash" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..6399783706
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			Parent_upvr.combat.update:FireServer("emotes", "disrespect", "trash")
			var180_upvw = false
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
		if string.lower(arg1) == "/e giggle" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..6399624289
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			var180_upvw = false
			Parent_upvr.combat.update:FireServer("emotes", "disrespect", "giggle")
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
	end
	if LocalPlayer_upvr.gamepasses:FindFirstChild("disgustingemotes") then
		if string.lower(arg1) == "/e barf" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..6399631911
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			Parent_upvr.combat.update:FireServer("emotes", "disgusting", "barf")
			var180_upvw = false
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
		if string.lower(arg1) == "/e spit" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..6399649659
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			Parent_upvr.combat.update:FireServer("emotes", "disgusting", "spit")
			var180_upvw = false
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
		if string.lower(arg1) == "/e fart" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..11282252692
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			Parent_upvr.combat.update:FireServer("emotes", "disgusting", "fart")
			var180_upvw = false
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
		if string.lower(arg1) == "/e cry" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..6399671799
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			Parent_upvr.combat.update:FireServer("emotes", "disgusting", "cry")
			var180_upvw = false
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
		if string.lower(arg1) == "/e clown" then
			var12_upvw = false
			rpanimz:Stop()
			Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..6400448876
			rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
			rpanimz:Play()
			Parent_upvr.combat.update:FireServer("emotes", "disgusting", "clown")
			var180_upvw = false
			if var181_upvw then
				var181_upvw:Destroy()
				var181_upvw = nil
			end
		end
	end
	if string.lower(arg1) == "/e none" then
		var12_upvw = false
		var180_upvw = false
		rpanimz:Stop()
		if var181_upvw then
			var181_upvw:Destroy()
			var181_upvw = nil
		end
		for _, v_2 in pairs(tbl_upvw) do
			v_2:Disconnect()
		end
		tbl_upvw = {}
	end
	if string.lower(arg1) == "/e sit" then
		var12_upvw = false
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5637922883
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = false
		if var181_upvw then
			var181_upvw:Destroy()
			var181_upvw = nil
		end
	end
	if string.lower(arg1) == "/e atease" then
		var12_upvw = false
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5637934327
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = true
		if var181_upvw then
			var181_upvw:Destroy()
			var181_upvw = nil
		end
	end
	if string.lower(arg1) == "/e lean" then
		var12_upvw = false
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5637945646
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = false
		if var181_upvw then
			var181_upvw:Destroy()
			var181_upvw = nil
		end
	end
	if string.lower(arg1) == "/e dance" then
		var12_upvw = false
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5712076137
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = false
		if var181_upvw then
			var181_upvw:Destroy()
			var181_upvw = nil
		end
	end
	if string.lower(arg1) == "/e bow" then
		var12_upvw = false
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5640363398
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = false
	end
	if string.lower(arg1) == "/e kneel" then
		var12_upvw = false
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5640380688
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = false
		if var181_upvw then
			var181_upvw:Destroy()
			var181_upvw = nil
		end
	end
	if string.lower(arg1) == "/e sleep" then
		var12_upvw = false
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5640389170
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = false
		if var181_upvw then
			var181_upvw:Destroy()
			var181_upvw = nil
		end
	end
	if string.lower(arg1) == "/e wave" then
		var12_upvw = false
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5640571919
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = false
		if var181_upvw then
			var181_upvw:Destroy()
			var181_upvw = nil
		end
	end
	if string.lower(arg1) == "/e raisehand" then
		var12_upvw = false
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5640373121
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = false
		if var181_upvw then
			var181_upvw:Destroy()
			var181_upvw = nil
		end
	end
	if string.lower(arg1) ~= "/e crouch" then
	end
end
LocalPlayer_upvr.Chatted:Connect(function(arg1) -- Line 2179
	chatmsg(arg1)
end)
combat_upvr.docrouch.Changed:connect(function(arg1) -- Line 2189
	--[[ Upvalues[7]:
		[1]: combat_upvr (readonly)
		[2]: var12_upvw (read and write)
		[3]: Animation_9_upvr (readonly)
		[4]: Humanoid_upvr (readonly)
		[5]: var180_upvw (read and write)
		[6]: Parent_upvr (readonly)
		[7]: var181_upvw (read and write)
	]]
	if combat_upvr.docrouch.Value then
		var12_upvw = true
		rpanimz:Stop()
		Animation_9_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5640568455
		rpanimz = Humanoid_upvr:LoadAnimation(Animation_9_upvr) -- Setting global
		rpanimz.Priority = Enum.AnimationPriority.Action4
		rpanimz:Play()
		var180_upvw = true
		rpanimz:AdjustSpeed(0)
	else
		rpanimz:Stop()
		if Parent_upvr:FindFirstChild("REMOVEEMOTE") then
			Parent_upvr.combat.update:FireServer("emotes")
		end
		if var181_upvw then
			Parent_upvr.combat.update:FireServer("crouch", false)
			var181_upvw:Destroy()
			var181_upvw = nil
			rpanimz:AdjustSpeed(1)
		end
	end
end)
Humanoid_upvr.Running:connect(function(arg1) -- Line 2219
	--[[ Upvalues[18]:
		[1]: Humanoid_upvr (readonly)
		[2]: any_LoadAnimation_result1_11_upvw (read and write)
		[3]: any_LoadAnimation_result1_6_upvr (readonly)
		[4]: any_LoadAnimation_result1_4_upvr (readonly)
		[5]: var180_upvw (read and write)
		[6]: combat_upvr (readonly)
		[7]: Parent_upvr (readonly)
		[8]: var12_upvw (read and write)
		[9]: var154_upvw (read and write)
		[10]: Sound_upvr_3 (readonly)
		[11]: any_LoadAnimation_result1_13_upvw (read and write)
		[12]: var155_upvw (read and write)
		[13]: Sound_upvr (readonly)
		[14]: var161_upvw (read and write)
		[15]: var160_upvw (read and write)
		[16]: var173_upvw (read and write)
		[17]: var175_upvw (read and write)
		[18]: var165_upvw (read and write)
	]]
	if Humanoid_upvr.SeatPart then
		any_LoadAnimation_result1_11_upvw:Stop()
		any_LoadAnimation_result1_6_upvr:Stop()
		any_LoadAnimation_result1_4_upvr:Stop()
	else
		if 10 < arg1 then
			if var180_upvw then
			else
				rpanimz:Stop()
				if combat_upvr.docrouch.Value then
					Parent_upvr.combat.update:FireServer("crouch", false)
				end
				if Parent_upvr:FindFirstChild("REMOVEEMOTE") then
					Parent_upvr.combat.update:FireServer("emotes")
				end
				rpanimz:AdjustSpeed(1)
			end
		end
		if var12_upvw then
			rpanimz:AdjustSpeed(arg1 / 16)
		end
		if Parent_upvr:FindFirstChild("cantjump") then
			Parent_upvr:FindFirstChild("cantjump"):Destroy()
		end
		if var154_upvw then
			Sound_upvr_3:Play()
			any_LoadAnimation_result1_13_upvw:Play()
		end
		if var155_upvw then
			local IntValue = Instance.new("IntValue")
			IntValue.Parent = Parent_upvr.combat
			IntValue.Name = "landed"
			game.Debris:AddItem(IntValue, 0.5)
			any_LoadAnimation_result1_13_upvw:Play()
			if var154_upvw then
			else
				Sound_upvr:Play()
			end
		end
		var161_upvw = 0
		var160_upvw = false
		var155_upvw = false
		var173_upvw = false
		var154_upvw = false
		var175_upvw:Stop()
		Humanoid_upvr.JumpPower = var165_upvw
	end
end)
Humanoid_upvr.FreeFalling:connect(function() -- Line 2317
	--[[ Upvalues[1]:
		[1]: var173_upvw (read and write)
	]]
	wait(0.2)
	var173_upvw = true
end)
game:GetService("UserInputService").JumpRequest:Connect(onJumpRequest)
function move(arg1) -- Line 2338
	--[[ Upvalues[9]:
		[1]: Parent_upvr (readonly)
		[2]: any_LoadAnimation_result1_6_upvr (readonly)
		[3]: any_LoadAnimation_result1_11_upvw (read and write)
		[4]: any_LoadAnimation_result1_4_upvr (readonly)
		[5]: combat_upvr (readonly)
		[6]: Humanoid_upvr (readonly)
		[7]: any_LoadAnimation_result1_5_upvr (readonly)
		[8]: any_LoadAnimation_result1_12_upvr (readonly)
		[9]: tbl_upvr (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [6] 6. Error Block 2 start (CF ANALYSIS FAILED)
	any_LoadAnimation_result1_6_upvr:Stop()
	any_LoadAnimation_result1_11_upvw:Stop()
	do
		return
	end
	-- KONSTANTERROR: [6] 6. Error Block 2 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [15] 13. Error Block 3 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [15] 13. Error Block 3 end (CF ANALYSIS FAILED)
end
local function var198(arg1) -- Line 2697
	--[[ Upvalues[3]:
		[1]: combat_upvr (readonly)
		[2]: tbl_upvr (readonly)
		[3]: any_LoadAnimation_result1_11_upvw (read and write)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [272] 151. Error Block 54 start (CF ANALYSIS FAILED)
	-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [276.1]
	-- KONSTANTERROR: [272] 151. Error Block 54 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [282] 158. Error Block 55 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [282] 158. Error Block 55 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [284] 159. Error Block 56 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [284] 159. Error Block 56 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [286] 160. Error Block 57 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [286] 160. Error Block 57 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [288] 161. Error Block 58 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [288] 161. Error Block 58 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [290] 162. Error Block 59 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [290] 162. Error Block 59 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [292] 163. Error Block 60 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [292] 163. Error Block 60 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [294] 164. Error Block 61 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [294] 164. Error Block 61 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [296] 165. Error Block 62 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [296] 165. Error Block 62 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [298] 166. Error Block 63 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [298] 166. Error Block 63 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [300] 167. Error Block 64 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [300] 167. Error Block 64 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [302] 168. Error Block 65 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [302] 168. Error Block 65 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [304] 169. Error Block 66 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [304] 169. Error Block 66 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [306] 170. Error Block 67 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [306] 170. Error Block 67 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [308] 171. Error Block 68 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [308] 171. Error Block 68 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [312] 173. Error Block 70 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [312] 173. Error Block 70 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [325] 180. Error Block 72 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [325] 180. Error Block 72 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [338] 187. Error Block 74 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [338] 187. Error Block 74 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [351] 194. Error Block 76 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [351] 194. Error Block 76 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [364] 201. Error Block 78 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [364] 201. Error Block 78 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [377] 208. Error Block 80 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [377] 208. Error Block 80 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [390] 215. Error Block 82 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [390] 215. Error Block 82 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [403] 222. Error Block 84 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [403] 222. Error Block 84 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [416] 229. Error Block 86 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [416] 229. Error Block 86 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [427] 235. Error Block 87 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [427] 235. Error Block 87 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [429] 236. Error Block 88 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [429] 236. Error Block 88 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [431] 237. Error Block 89 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [431] 237. Error Block 89 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [433] 238. Error Block 90 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [433] 238. Error Block 90 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [435] 239. Error Block 91 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [435] 239. Error Block 91 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [437] 240. Error Block 92 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [437] 240. Error Block 92 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [439] 241. Error Block 93 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [439] 241. Error Block 93 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [441] 242. Error Block 94 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [441] 242. Error Block 94 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [443] 243. Error Block 95 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [443] 243. Error Block 95 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [445] 244. Error Block 96 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [445] 244. Error Block 96 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [447] 245. Error Block 97 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTERROR: [447] 245. Error Block 97 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [451] 247. Error Block 99 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [451] 247. Error Block 99 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [464] 254. Error Block 101 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [464] 254. Error Block 101 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [477] 261. Error Block 118 start (CF ANALYSIS FAILED)
	local function INLINED_2() -- Internal function, doesn't exist in bytecode
		-- KONSTANTERROR: [488] 267. Error Block 104 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: Expression was reused, decompilation is incorrect
		-- KONSTANTERROR: [488] 267. Error Block 104 start (CF ANALYSIS FAILED)
		return nil ~= "karmadunes"
	end
	local function INLINED_3() -- Internal function, doesn't exist in bytecode
		-- KONSTANTERROR: Expression was reused, decompilation is incorrect
		return nil ~= "karmahaze"
	end
	local function INLINED_4() -- Internal function, doesn't exist in bytecode
		-- KONSTANTERROR: Expression was reused, decompilation is incorrect
		return nil ~= "karmanimbus"
	end
	if combat_upvr.KG.currentmode.form.Value ~= 4 or INLINED_2() or combat_upvr.KG.currentmode.form.Value ~= 3 or INLINED_3() or combat_upvr.KG.currentmode.form.Value ~= 3 or INLINED_4() or combat_upvr.KG.currentmode.form.Value ~= 3 then
		-- KONSTANTERROR: Expression was reused, decompilation is incorrect
		if nil == "karmaobelisk" and combat_upvr.KG.currentmode.form.Value == 3 then return end
		any_LoadAnimation_result1_11_upvw:Stop()
	end
	-- KONSTANTERROR: [477] 261. Error Block 118 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [545] 299. Error Block 114 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [545] 299. Error Block 114 end (CF ANALYSIS FAILED)
end
combat_upvr.run.Changed:connect(var198)
-- KONSTANTERROR: [0] 1. Error Block 32 end (CF ANALYSIS FAILED)
-- KONSTANTERROR: [1674] 1161. Error Block 30 start (CF ANALYSIS FAILED)
any_LoadAnimation_result1_9_upvw:Play()
if Parent_upvr:FindFirstChild("stayonground") then
	deathanimationz:Play()
else
	deathanimationz:Stop()
end
local _, wait_result2 = wait(0.1)
move(wait_result2)
-- KONSTANTERROR: [1674] 1161. Error Block 30 end (CF ANALYSIS FAILED)
-- KONSTANTERROR: [1638] 1138. Error Block 8 start (CF ANALYSIS FAILED)
-- KONSTANTERROR: [1638] 1138. Error Block 8 end (CF ANALYSIS FAILED)