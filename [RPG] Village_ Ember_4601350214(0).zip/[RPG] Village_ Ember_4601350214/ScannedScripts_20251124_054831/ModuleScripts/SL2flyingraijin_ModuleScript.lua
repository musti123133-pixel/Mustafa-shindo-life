-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:32:27
-- Luau version 6, Types version 3
-- Time taken: 0.007862 seconds

local module = {
	idlanim = function() -- Line 7
		return 4855855974
	end;
	combat = function() -- Line 12
		return {9163312873, 9163261514, 9163315564, 9163263408}
	end;
	block = function() -- Line 17
		return 9163317779
	end;
	typ = function() -- Line 21
		return "saber"
	end;
	power = function() -- Line 25
		return 4816744006
	end;
	slicedelay = function() -- Line 29
		return 0.3
	end;
	damage = function() -- Line 32
		return 10
	end;
	specdamage = function(arg1) -- Line 35
		return 5 * (require(ReplicatedStorage:WaitForChild("GlobalFunctions")).getallstats(arg1).taijutsu + 5)
	end;
}
ReplicatedStorage = game.ReplicatedStorage -- Setting global
function module.heavyattack(arg1, arg2) -- Line 49
	if script.stamina.Value <= arg2.stamina2.Value then
		arg2.stamina2.Value = arg2.stamina2.Value - script.stamina.Value
	else
		return script.stamina.Value
	end
	local KeyMods_upvr = game:GetService("ServerScriptService"):WaitForChild("KeyMods")
	spawn(function() -- Line 64
		--[[ Upvalues[3]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: KeyMods_upvr (readonly)
		]]
		local var14_upvr = arg1
		local any_GetPlayerFromCharacter_result1 = game.Players:GetPlayerFromCharacter(var14_upvr)
		if any_GetPlayerFromCharacter_result1 == nil then
			any_GetPlayerFromCharacter_result1 = var14_upvr
		else
		end
		local var16_upvw
		if any_GetPlayerFromCharacter_result1 == nil then
			any_GetPlayerFromCharacter_result1 = var14_upvr
			var16_upvw = var14_upvr:WaitForChild("mouse")
		else
			var16_upvw = workspace.projectileparent:WaitForChild(var14_upvr.Name.."mouse")
		end
		local module_2_upvr = require(ReplicatedStorage:WaitForChild("GlobalFunctions"))
		local var18_upvw = false
		if module_2_upvr.haspuppet(any_GetPlayerFromCharacter_result1) then
			var18_upvw = true
		end
		delay(0, function() -- Line 90
			--[[ Upvalues[5]:
				[1]: var18_upvw (read and write)
				[2]: var14_upvr (readonly)
				[3]: KeyMods_upvr (copied, readonly)
				[4]: var16_upvw (read and write)
				[5]: module_2_upvr (readonly)
			]]
			if var18_upvw then
				var14_upvr.puppet.weapon.saber:Destroy()
			else
				var14_upvr.weapon.saber:Destroy()
			end
			for _ = 1, 1 do
				wait(0.05)
				local clone = KeyMods_upvr.alljutsu.shuriken.ftg2:clone()
				clone.CFrame = CFrame.new((var14_upvr.HumanoidRootPart.CFrame * CFrame.new(0, 0, -3)).p, var16_upvw.CFrame.p) * CFrame.Angles((math.pi/2), 0, 0)
				clone.Name = "kunai"
				local ObjectValue_2 = Instance.new("ObjectValue")
				ObjectValue_2.Value = var14_upvr
				ObjectValue_2.Name = "owner"
				ObjectValue_2.Parent = clone
				clone.effect.Value = "ftg2"
				module_2_upvr.sound(var14_upvr.HumanoidRootPart, 5022788823, 3)
				module_2_upvr.sound(clone, 5022788494, 2)
				local any_create_result1 = require(KeyMods_upvr.alljutsu.main.nearestplayer).create(var14_upvr)
				local var25
				if any_create_result1 and any_create_result1.Parent:FindFirstChild("Humanoid") then
					var25 = any_create_result1
				end
				local ObjectValue = Instance.new("ObjectValue")
				ObjectValue.Value = var25
				ObjectValue.Name = "target"
				ObjectValue.Parent = clone
				if workspace:FindFirstChild("matchv2") then
				else
					local StringValue = Instance.new("StringValue")
					StringValue.Name = "tphit"
					StringValue.Parent = clone
				end
				clone.Anchored = true
				clone.Parent = workspace.projectileparent
				game.Debris:AddItem(clone, 1)
				local clone_2 = KeyMods_upvr.alljutsu.shuriken.follow:Clone()
				clone_2.Parent = clone
				clone_2.Disabled = false
			end
		end)
	end)
end
return module