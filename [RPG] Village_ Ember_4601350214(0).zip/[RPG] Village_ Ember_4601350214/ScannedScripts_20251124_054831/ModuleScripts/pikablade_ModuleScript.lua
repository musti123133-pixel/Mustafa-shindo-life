-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:32:23
-- Luau version 6, Types version 3
-- Time taken: 0.019889 seconds

local module = {}
local function _(arg1, arg2) -- Line 7, Named "CreateRegion3FromLocAndSize"
	local var2 = arg2 / 2
	return Region3.new(arg1 - var2, arg1 + var2)
end
function PointOnCircle(arg1, arg2, arg3, arg4) -- Line 15
	return arg1 + arg3 * math.cos(arg4), arg2 + arg3 * math.sin(arg4)
end
function module.idlanim() -- Line 23
	return 4855855974
end
function module.combat() -- Line 28
	return {9163312873, 9163261514, 9163315564, 9163263408}
end
function module.block() -- Line 33
	return 9163317779
end
function module.typ() -- Line 37
	return "saber"
end
function module.power() -- Line 41
	return 4816744006
end
function module.slicedelay() -- Line 45
	return 0.3
end
function module.damage() -- Line 48
	return 10
end
function module.specdamage(arg1) -- Line 51
	return 7.4 * (require(ReplicatedStorage:WaitForChild("GlobalFunctions")).getallstats(arg1).taijutsu + 7.4)
end
ReplicatedStorage = game.ReplicatedStorage -- Setting global
local TweenService_upvr = game:GetService("TweenService")
local RunService_upvr = game:GetService("RunService")
function module.heavyattack(arg1, arg2) -- Line 66
	--[[ Upvalues[2]:
		[1]: TweenService_upvr (readonly)
		[2]: RunService_upvr (readonly)
	]]
	if script.stamina.Value <= arg2.stamina2.Value then
		arg2.stamina2.Value = arg2.stamina2.Value - script.stamina.Value
	else
		return script.stamina.Value
	end
	spawn(function() -- Line 80
		--[[ Upvalues[4]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: TweenService_upvr (copied, readonly)
			[4]: RunService_upvr (copied, readonly)
		]]
		local var16_upvr = arg1
		local any_GetPlayerFromCharacter_result1_upvw = game.Players:GetPlayerFromCharacter(var16_upvr)
		if any_GetPlayerFromCharacter_result1_upvw == nil then
			any_GetPlayerFromCharacter_result1_upvw = var16_upvr
		else
		end
		local var18_upvw
		if any_GetPlayerFromCharacter_result1_upvw == nil then
			any_GetPlayerFromCharacter_result1_upvw = var16_upvr
			var18_upvw = var16_upvr:WaitForChild("mouse")
		else
			var18_upvw = workspace.projectileparent:WaitForChild(var16_upvr.Name.."mouse")
		end
		local module_2_upvr = require(ReplicatedStorage:WaitForChild("GlobalFunctions"))
		local var20_upvw = false
		if module_2_upvr.haspuppet(any_GetPlayerFromCharacter_result1_upvw) then
			var20_upvw = true
		end
		delay(0, function() -- Line 106
			--[[ Upvalues[8]:
				[1]: arg2 (readonly)
				[2]: var16_upvr (readonly)
				[3]: var20_upvw (read and write)
				[4]: var18_upvw (read and write)
				[5]: module_2_upvr (readonly)
				[6]: TweenService_upvr (copied, readonly)
				[7]: RunService_upvr (copied, readonly)
				[8]: any_GetPlayerFromCharacter_result1_upvw (read and write)
			]]
			-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
			local IntValue = Instance.new("IntValue")
			IntValue.Parent = arg2
			IntValue.Name = "hyperarmour"
			game.Debris:AddItem(IntValue, 4)
			local HumanoidRootPart_upvw = var16_upvr.HumanoidRootPart
			if var20_upvw then
				HumanoidRootPart_upvw = var16_upvr.puppet.HumanoidRootPart
			end
			arg2.heavyhit.Value = true
			local Attachment = Instance.new("Attachment")
			Attachment.Parent = var16_upvr["Left Arm"]
			Attachment.Position = Vector3.new(0, -0.5, 0)
			local clone = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone.Parent = Attachment
			clone:Emit(4)
			clone.Enabled = true
			game.Debris:AddItem(Attachment, 0.5)
			local Animation = Instance.new("Animation")
			Animation.AnimationId = "http://www.roblox.com/asset/?id="..9143198090
			arg2.canrunfromslice.Value = true
			local any_LoadAnimation_result1 = var16_upvr.Humanoid:LoadAnimation(Animation)
			if var20_upvw then
				any_LoadAnimation_result1 = var16_upvr.puppet.Humanoid:LoadAnimation(Animation)
			end
			any_LoadAnimation_result1:Play()
			local Attachment_4 = Instance.new("Attachment")
			Attachment_4.Parent = var16_upvr["Right Arm"]
			Attachment_4.Position = Vector3.new(0, -0.5, 0)
			local clone_2 = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone_2.Parent = Attachment_4
			clone_2:Emit(4)
			clone_2.Enabled = true
			game.Debris:AddItem(Attachment_4, 0.5)
			if var20_upvw then
				script.posion2:Clone().Parent = var16_upvr.puppet.weapon.saber.blade.SWORD
			else
				-- KONSTANTERROR: Expression was reused, decompilation is incorrect
				script.posion2:Clone().Parent = var16_upvr.weapon.saber.blade.SWORD
			end
			wait(0.1)
			local var34
			if var20_upvw then
				var34 = var16_upvr.puppet.weapon.saber.Gun
			else
				var34 = var16_upvr.weapon.saber.Gun
			end
			var34.Part0 = nil
			local var35_upvw
			if var20_upvw then
				var35_upvw = var16_upvr.puppet.weapon.saber
			else
				var35_upvw = var16_upvr.weapon.saber
			end
			var35_upvw.CFrame = CFrame.new(HumanoidRootPart_upvw.CFrame.p, var18_upvw.CFrame.p) * CFrame.Angles((-math.pi/2), 0, 0) * CFrame.new(0, 0, -3)
			local ObjectValue_2 = Instance.new("ObjectValue")
			ObjectValue_2.Value = var16_upvr
			ObjectValue_2.Name = "owner"
			ObjectValue_2.Parent = var35_upvw
			var35_upvw.Anchored = true
			module_2_upvr.sound(var16_upvr.HumanoidRootPart, 5022788823, 3)
			for _ = 1, 1 do
				module_2_upvr.sound(var35_upvw, 9165126326, 1)
				var35_upvw.CFrame = HumanoidRootPart_upvw.CFrame + Vector3.new(0, 1, 0)
				var35_upvw.Parent = workspace.projectileparent
				local ObjectValue = Instance.new("ObjectValue")
				ObjectValue.Value = var16_upvr
				ObjectValue.Name = "owner"
				ObjectValue.Parent = var35_upvw
				local Attachment_2_upvr = Instance.new("Attachment")
				Attachment_2_upvr.Parent = workspace.Terrain
				local Attachment_3 = Instance.new("Attachment")
				Attachment_3.Parent = var35_upvw
				Attachment_2_upvr.WorldPosition = HumanoidRootPart_upvw.CFrame.p
				local AlignPosition = Instance.new("AlignPosition")
				AlignPosition.Responsiveness = 50
				AlignPosition.ApplyAtCenterOfMass = true
				AlignPosition.MaxForce = 999999
				AlignPosition.Attachment0 = Attachment_3
				AlignPosition.Attachment1 = Attachment_2_upvr
				AlignPosition.Parent = Attachment_3
				AlignPosition.MaxVelocity = 130
				module_2_upvr.sound(var35_upvw, 5022788494, 2)
				spawn(function() -- Line 262
					--[[ Upvalues[9]:
						[1]: var35_upvw (read and write)
						[2]: var16_upvr (copied, readonly)
						[3]: Attachment_2_upvr (readonly)
						[4]: var18_upvw (copied, read and write)
						[5]: TweenService_upvr (copied, readonly)
						[6]: RunService_upvr (copied, readonly)
						[7]: module_2_upvr (copied, readonly)
						[8]: HumanoidRootPart_upvw (read and write)
						[9]: any_GetPlayerFromCharacter_result1_upvw (copied, read and write)
					]]
					local var43_upvw = false
					delay(0, function() -- Line 269
						--[[ Upvalues[10]:
							[1]: var16_upvr (copied, readonly)
							[2]: Attachment_2_upvr (copied, readonly)
							[3]: var18_upvw (copied, read and write)
							[4]: var35_upvw (readonly)
							[5]: var43_upvw (read and write)
							[6]: TweenService_upvr (copied, readonly)
							[7]: RunService_upvr (copied, readonly)
							[8]: module_2_upvr (copied, readonly)
							[9]: HumanoidRootPart_upvw (copied, read and write)
							[10]: any_GetPlayerFromCharacter_result1_upvw (copied, read and write)
						]]
						-- KONSTANTERROR: [0] 1. Error Block 42 start (CF ANALYSIS FAILED)
						local any_create_result1 = require(ReplicatedStorage.alljutsu.main.nearestplayer).create(var16_upvr, 120)
						local var47
						if any_create_result1 and any_create_result1.Parent:FindFirstChild("Humanoid") then
							var47 = any_create_result1
						end
						if var47 then
							Attachment_2_upvr.WorldPosition = var47.CFrame.p
						else
							Attachment_2_upvr.WorldPosition = var18_upvw.Position
						end
						local magnitude = (var35_upvw.CFrame.p - Attachment_2_upvr.WorldPosition).magnitude
						-- KONSTANTERROR: [0] 1. Error Block 42 end (CF ANALYSIS FAILED)
						-- KONSTANTERROR: [223] 164. Error Block 33 start (CF ANALYSIS FAILED)
						for i_2 = 5, magnitude, 15 do
							local var49
							if var43_upvw then break end
							if var47 then
								Attachment_2_upvr.WorldPosition = var47.CFrame.p
								var49 = Attachment_2_upvr.WorldPosition
							end
							local PointOnCircle_result1, PointOnCircle_result2 = PointOnCircle(magnitude * 0.5, 0, magnitude * 0.5, math.pi - math.pi / magnitude * i_2)
							local cframe = CFrame.new(CFrame.new(var35_upvw.CFrame.p, var49):pointToWorldSpace(Vector3.new((PointOnCircle_result2) * (math.random(-1, 1) * 0.1), PointOnCircle_result2 * 0.1, -PointOnCircle_result1)))
							local any_toEulerAnglesXYZ_result1, any_toEulerAnglesXYZ_result2, any_toEulerAnglesXYZ_result3 = CFrame.new(var35_upvw.CFrame.p, cframe.p) * CFrame.Angles((-math.pi/2), 0, 0) * CFrame.new(0, 0, -3):toEulerAnglesXYZ()
							local any_Create_result1 = TweenService_upvr:Create(var35_upvw, TweenInfo.new(0.08, Enum.EasingStyle.Linear, Enum.EasingDirection.In, 0, false, 0), {
								CFrame = cframe * CFrame.Angles(any_toEulerAnglesXYZ_result1, any_toEulerAnglesXYZ_result2, any_toEulerAnglesXYZ_result3);
							})
							any_Create_result1:Play()
							local var59_upvw = false
							spawn(function() -- Line 502
								--[[ Upvalues[4]:
									[1]: RunService_upvr (copied, readonly)
									[2]: var35_upvw (copied, readonly)
									[3]: var43_upvw (copied, read and write)
									[4]: var59_upvw (read and write)
								]]
								-- KONSTANTERROR: [0] 1. Error Block 19 start (CF ANALYSIS FAILED)
								RunService_upvr.Heartbeat:wait()
								-- KONSTANTERROR: [0] 1. Error Block 19 end (CF ANALYSIS FAILED)
								-- KONSTANTERROR: [8] 7. Error Block 23 start (CF ANALYSIS FAILED)
								if var35_upvw:IsDescendantOf(workspace.projectileparent) then
									-- KONSTANTWARNING: GOTO [19] #15
								end
								-- KONSTANTERROR: [8] 7. Error Block 23 end (CF ANALYSIS FAILED)
							end)
							any_Create_result1.Completed:wait()
							var59_upvw = true
						end
						-- KONSTANTERROR: [223] 164. Error Block 33 end (CF ANALYSIS FAILED)
					end)
				end)
				game.Debris:AddItem(var35_upvw, 4)
				game.Debris:AddItem(Attachment_2_upvr, 4)
			end
			any_LoadAnimation_result1:Stop()
			game.Debris:AddItem(var35_upvw, 2)
			var35_upvw.Parent = workspace.projectileparent
			wait(0.3)
			arg2.canrunfromslice.Value = false
			arg2.heavyhit.Value = false
		end)
	end)
end
return module