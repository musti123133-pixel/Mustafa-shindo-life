-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:45:53
-- Luau version 6, Types version 3
-- Time taken: 0.005205 seconds

local module = {}
local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
function module.make(arg1, arg2) -- Line 16
	--[[ Upvalues[1]:
		[1]: ReplicatedStorage_upvr (readonly)
	]]
	spawn(function() -- Line 17
		--[[ Upvalues[3]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: ReplicatedStorage_upvr (copied, readonly)
		]]
		local _1_upvr = arg2[1]
		local LightningBolt_upvr = require(ReplicatedStorage_upvr.LightningBolt)
		task.spawn(function() -- Line 37
			--[[ Upvalues[2]:
				[1]: _1_upvr (readonly)
				[2]: LightningBolt_upvr (readonly)
			]]
			for _ = 1, 30 do
				task.wait(0.1)
				local CFrame = _1_upvr.CFrame
				local var9 = CFrame * CFrame.new(math.random(-5, 5), math.random(-5, 5), math.random(-5, 5))
				local Attachment_2 = Instance.new("Attachment", _1_upvr)
				Attachment_2.WorldPosition = (CFrame.lookAt(CFrame.p, var9.p) * CFrame.new(0, 0, -20)).p
				local Attachment = Instance.new("Attachment", _1_upvr)
				Attachment.WorldPosition = (CFrame.lookAt(CFrame.p, var9.p) * CFrame.new(0, 0, -80)).p
				game.Debris:AddItem(Attachment, 2)
				game.Debris:AddItem(Attachment_2, 2)
				local any_new_result1 = LightningBolt_upvr.new(Attachment_2, Attachment, 20)
				any_new_result1.PulseSpeed = 5
				any_new_result1.PulseLength = 2
				any_new_result1.Thickness = 2
				any_new_result1.FadeLength = 0.25
				any_new_result1.Color = Color3.fromRGB(0, 0, 0)
			end
		end)
	end)
end
return module