-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:32:16
-- Luau version 6, Types version 3
-- Time taken: 0.008411 seconds

local module_upvr = {
	idlanim = function() -- Line 7
		return 4855855974
	end;
	combat = function() -- Line 12
		return {4855549219, 4855567518, 4855563129}
	end;
	block = function() -- Line 17
		return 9163317779
	end;
	typ = function() -- Line 21
		return "saber"
	end;
	power = function() -- Line 25
		return 4816744006
	end;
	slicedelay = function() -- Line 29
		return 0.3
	end;
	damage = function() -- Line 32
		return 10
	end;
	specdamage = function(arg1) -- Line 35
		return 1 * (require(ReplicatedStorage:WaitForChild("GlobalFunctions")).getallstats(arg1).taijutsu + 1)
	end;
}
ReplicatedStorage = game.ReplicatedStorage -- Setting global
function module_upvr.heavyattack(arg1, arg2) -- Line 49
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	if script.stamina.Value <= arg2.stamina2.Value then
		arg2.stamina2.Value = arg2.stamina2.Value - script.stamina.Value
	else
		return script.stamina.Value
	end
	spawn(function() -- Line 60
		--[[ Upvalues[3]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: module_upvr (copied, readonly)
		]]
		local var13_upvr = arg1
		local any_GetPlayerFromCharacter_result1_upvw = game.Players:GetPlayerFromCharacter(var13_upvr)
		if any_GetPlayerFromCharacter_result1_upvw == nil then
			any_GetPlayerFromCharacter_result1_upvw = var13_upvr
		else
		end
		local module_upvr_2 = require(ReplicatedStorage:WaitForChild("GlobalFunctions"))
		local var16_upvw = false
		if module_upvr_2.haspuppet(any_GetPlayerFromCharacter_result1_upvw) then
			var16_upvw = true
		end
		delay(0, function() -- Line 79
			--[[ Upvalues[6]:
				[1]: arg2 (readonly)
				[2]: var13_upvr (readonly)
				[3]: var16_upvw (read and write)
				[4]: module_upvr_2 (readonly)
				[5]: module_upvr (copied, readonly)
				[6]: any_GetPlayerFromCharacter_result1_upvw (read and write)
			]]
			local IntValue = Instance.new("IntValue")
			IntValue.Parent = arg2
			IntValue.Name = "hyperarmour"
			game.Debris:AddItem(IntValue, 1)
			local HumanoidRootPart_upvw = var13_upvr.HumanoidRootPart
			if var16_upvw then
				HumanoidRootPart_upvw = var13_upvr.puppet.HumanoidRootPart
			end
			arg2.heavyhit.Value = true
			local Animation = Instance.new("Animation")
			Animation.AnimationId = "http://www.roblox.com/asset/?id="..9128064667
			arg2.canrunfromslice.Value = true
			local any_LoadAnimation_result1 = var13_upvr.Humanoid:LoadAnimation(Animation)
			if var16_upvw then
				any_LoadAnimation_result1 = var13_upvr.puppet.Humanoid:LoadAnimation(Animation)
			end
			any_LoadAnimation_result1:Play()
			local Attachment = Instance.new("Attachment")
			Attachment.Parent = var13_upvr["Right Arm"]
			Attachment.Position = Vector3.new(0, -0.5, 0)
			local clone = ReplicatedStorage.elementfolder.hiteffects.charge:clone()
			clone.Parent = Attachment
			clone:Emit(4)
			clone.Enabled = true
			game.Debris:AddItem(Attachment, 0.5)
			delay(0.3, function() -- Line 122
				--[[ Upvalues[7]:
					[1]: arg2 (copied, readonly)
					[2]: HumanoidRootPart_upvw (read and write)
					[3]: var16_upvw (copied, read and write)
					[4]: module_upvr_2 (copied, readonly)
					[5]: var13_upvr (copied, readonly)
					[6]: module_upvr (copied, readonly)
					[7]: any_GetPlayerFromCharacter_result1_upvw (copied, read and write)
				]]
				arg2.effects.push.origpos.Value = HumanoidRootPart_upvw.CFrame * CFrame.new(0, 0, -10)
				arg2.effects.push.force.Value = 120
				arg2.effects.push.Value = true
				if var16_upvw then
					delay(0, function() -- Line 132
						--[[ Upvalues[4]:
							[1]: module_upvr_2 (copied, readonly)
							[2]: var13_upvr (copied, readonly)
							[3]: module_upvr (copied, readonly)
							[4]: any_GetPlayerFromCharacter_result1_upvw (copied, read and write)
						]]
						for _ = 1, 4 do
							wait(0.1)
							if module_upvr_2.saberdamage(var13_upvr, module_upvr.specdamage(any_GetPlayerFromCharacter_result1_upvw), "push", var13_upvr.puppet.HumanoidRootPart.CFrame) then break end
						end
					end)
				else
					delay(0, function() -- Line 143
						--[[ Upvalues[4]:
							[1]: module_upvr_2 (copied, readonly)
							[2]: var13_upvr (copied, readonly)
							[3]: module_upvr (copied, readonly)
							[4]: any_GetPlayerFromCharacter_result1_upvw (copied, read and write)
						]]
						for _ = 1, 4 do
							wait(0.1)
							if module_upvr_2.saberdamage(var13_upvr, module_upvr.specdamage(any_GetPlayerFromCharacter_result1_upvw), "push") then break end
						end
					end)
				end
				delay(0.2, function() -- Line 155
					--[[ Upvalues[1]:
						[1]: arg2 (copied, readonly)
					]]
					arg2.effects.push.Value = false
				end)
			end)
			wait(1)
			any_LoadAnimation_result1:Stop()
			arg2.canrunfromslice.Value = false
			arg2.heavyhit.Value = false
		end)
	end)
end
return module_upvr