-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:48:13
-- Luau version 6, Types version 3
-- Time taken: 0.027454 seconds

game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.Health, false)
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local Character_upvr = LocalPlayer_upvr.Character
if not Character_upvr then
	Character_upvr = LocalPlayer_upvr.CharacterAdded:wait()
end
local Humanoid_upvr = Character_upvr:WaitForChild("Humanoid")
local HumanoidRootPart_upvr = Character_upvr:WaitForChild("HumanoidRootPart")
local SusanooCustom_upvr = script.Parent:WaitForChild("Main").SusanooCustom
local alljutsu = game:GetService("ReplicatedStorage"):WaitForChild("alljutsu")
local custosusanoo_upvr = script.custosusanoo
local fullsusanoo_upvr = script.fullsusanoo
custosusanoo_upvr.torso.Part0 = HumanoidRootPart_upvr
local var13_upvw = 1
SusanooCustom_upvr.Frame.head.text.Text = "[HELMET #"..var13_upvw..']'
SusanooCustom_upvr.Frame.head.arrowright.MouseButton1Down:connect(function() -- Line 59
	--[[ Upvalues[3]:
		[1]: var13_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var13_upvw += 1
	if 7 < var13_upvw then
		var13_upvw = 1
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "head", var13_upvw)
	SusanooCustom_upvr.Frame.head.text.Text = "[HELMET #"..var13_upvw..']'
end)
SusanooCustom_upvr.Frame.head.arrowleft.MouseButton1Down:connect(function() -- Line 69
	--[[ Upvalues[3]:
		[1]: var13_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var13_upvw -= 1
	if var13_upvw <= 0 then
		var13_upvw = 7
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "head", var13_upvw)
	SusanooCustom_upvr.Frame.head.text.Text = "[HELMET #"..var13_upvw..']'
end)
local var16_upvw = 1
SusanooCustom_upvr.Frame.torso.text.Text = "[ARMOUR #"..var16_upvw..']'
SusanooCustom_upvr.Frame.torso.arrowright.MouseButton1Down:connect(function() -- Line 87
	--[[ Upvalues[3]:
		[1]: var16_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var16_upvw += 1
	if 7 < var16_upvw then
		var16_upvw = 1
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "torso", var16_upvw)
	SusanooCustom_upvr.Frame.torso.text.Text = "[ARMOUR #"..var16_upvw..']'
end)
SusanooCustom_upvr.Frame.torso.arrowleft.MouseButton1Down:connect(function() -- Line 97
	--[[ Upvalues[3]:
		[1]: var16_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var16_upvw -= 1
	if var16_upvw <= 0 then
		var16_upvw = 7
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "torso", var16_upvw)
	SusanooCustom_upvr.Frame.torso.text.Text = "[ARMOUR #"..var16_upvw..']'
end)
local var19_upvw = 0
SusanooCustom_upvr.Frame.acc1.text.Text = "[ACCESSORY #"..var19_upvw..']'
SusanooCustom_upvr.Frame.acc1.arrowright.MouseButton1Down:connect(function() -- Line 112
	--[[ Upvalues[3]:
		[1]: var19_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var19_upvw += 1
	if 1 < var19_upvw then
		var19_upvw = 0
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "acc1", var19_upvw)
	SusanooCustom_upvr.Frame.acc1.text.Text = "[ACCESSORY #"..var19_upvw..']'
end)
SusanooCustom_upvr.Frame.acc1.arrowleft.MouseButton1Down:connect(function() -- Line 122
	--[[ Upvalues[3]:
		[1]: var19_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var19_upvw -= 1
	if var19_upvw < 0 then
		var19_upvw = 1
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "acc1", var19_upvw)
	SusanooCustom_upvr.Frame.acc1.text.Text = "[ACCESSORY #"..var19_upvw..']'
end)
local var22_upvw = 0
SusanooCustom_upvr.Frame.acc2.text.Text = "[ACCESSORY #"..var22_upvw..']'
SusanooCustom_upvr.Frame.acc2.arrowright.MouseButton1Down:connect(function() -- Line 138
	--[[ Upvalues[3]:
		[1]: var22_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var22_upvw += 1
	if 1 < var22_upvw then
		var22_upvw = 0
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "acc2", var22_upvw)
	SusanooCustom_upvr.Frame.acc2.text.Text = "[ACCESSORY #"..var22_upvw..']'
end)
SusanooCustom_upvr.Frame.acc2.arrowleft.MouseButton1Down:connect(function() -- Line 148
	--[[ Upvalues[3]:
		[1]: var22_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var22_upvw -= 1
	if var22_upvw < 0 then
		var22_upvw = 1
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "acc2", var22_upvw)
	SusanooCustom_upvr.Frame.acc2.text.Text = "[ACCESSORY #"..var22_upvw..']'
end)
local var25_upvw = 1
SusanooCustom_upvr.Frame.sword.text.Text = "[WEAPON #"..var25_upvw..']'
SusanooCustom_upvr.Frame.sword.arrowright.MouseButton1Down:connect(function() -- Line 166
	--[[ Upvalues[3]:
		[1]: var25_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var25_upvw += 1
	if 3 < var25_upvw then
		var25_upvw = 1
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "weapon", var25_upvw)
	SusanooCustom_upvr.Frame.sword.text.Text = "[WEAPON #"..var25_upvw..']'
end)
SusanooCustom_upvr.Frame.sword.arrowleft.MouseButton1Down:connect(function() -- Line 176
	--[[ Upvalues[3]:
		[1]: var25_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
		[3]: SusanooCustom_upvr (readonly)
	]]
	var25_upvw -= 1
	if var25_upvw <= 0 then
		var25_upvw = 3
	end
	LocalPlayer_upvr.startevent:FireServer("csusanoo", "weapon", var25_upvw)
	SusanooCustom_upvr.Frame.sword.text.Text = "[WEAPON #"..var25_upvw..']'
end)
local MarketplaceService_upvr = game:GetService("MarketplaceService")
SusanooCustom_upvr.Frame.eyecolor.bg.MouseButton1Down:connect(function() -- Line 196
	--[[ Upvalues[2]:
		[1]: LocalPlayer_upvr (readonly)
		[2]: MarketplaceService_upvr (readonly)
	]]
	if 1 <= LocalPlayer_upvr.statz.spins.Value then
		LocalPlayer_upvr.startevent:FireServer("csusanoo", "eyecolor")
	else
		MarketplaceService_upvr:PromptProductPurchase(LocalPlayer_upvr, 1109970805)
	end
end)
SusanooCustom_upvr.Frame.color.bg.MouseButton1Down:connect(function() -- Line 206
	--[[ Upvalues[2]:
		[1]: LocalPlayer_upvr (readonly)
		[2]: MarketplaceService_upvr (readonly)
	]]
	if 5 <= LocalPlayer_upvr.statz.spins.Value then
		LocalPlayer_upvr.startevent:FireServer("csusanoo", "color")
	else
		MarketplaceService_upvr:PromptProductPurchase(LocalPlayer_upvr, 1109935991)
	end
end)
SusanooCustom_upvr.Frame.mseyes.bg.eye.Image = LocalPlayer_upvr.statz.customsusanoo.customeyes.Value
SusanooCustom_upvr.Frame.mseyes.text.Changed:Connect(function() -- Line 217
	--[[ Upvalues[2]:
		[1]: SusanooCustom_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
	]]
	if tonumber(SusanooCustom_upvr.Frame.mseyes.text.Text) then
		SusanooCustom_upvr.Frame.mseyes.bg.eye.Image = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..SusanooCustom_upvr.Frame.mseyes.text.Text
		LocalPlayer_upvr.startevent:FireServer("csusanoo", "customeyes", SusanooCustom_upvr.Frame.mseyes.bg.eye.Image)
	else
		SusanooCustom_upvr.Frame.mseyes.bg.eye.Image = "http://www.roblox.com/asset/?id=6012319091"
		LocalPlayer_upvr.startevent:FireServer("csusanoo", "customeyes", "http://www.roblox.com/asset/?id=6012319091")
	end
end)
local Animation_upvr = Instance.new("Animation")
Animation_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5862375879
griptrack = Humanoid_upvr:LoadAnimation(Animation_upvr) -- Setting global
griptrack:Play()
local combat_upvr = Character_upvr:WaitForChild("combat")
SusanooCustom_upvr:GetPropertyChangedSignal("Visible"):Connect(function() -- Line 247
	--[[ Upvalues[7]:
		[1]: SusanooCustom_upvr (readonly)
		[2]: custosusanoo_upvr (readonly)
		[3]: Character_upvr (readonly)
		[4]: fullsusanoo_upvr (readonly)
		[5]: HumanoidRootPart_upvr (readonly)
		[6]: Humanoid_upvr (readonly)
		[7]: combat_upvr (readonly)
	]]
	if SusanooCustom_upvr.Visible then
		custosusanoo_upvr.Parent = Character_upvr
		fullsusanoo_upvr.Parent = Character_upvr
		fullsusanoo_upvr.ftorso.CFrame = HumanoidRootPart_upvr.CFrame * CFrame.new(0, 21, 30)
		for _, v in pairs(Humanoid_upvr:GetPlayingAnimationTracks()) do
			v:Stop()
		end
		combat_upvr.update:FireServer("susanoocuso", true)
		customizesusanoo()
	else
		custosusanoo_upvr.Parent = script
		fullsusanoo_upvr.Parent = script
		combat_upvr.update:FireServer("susanoocuso", false)
		for _, v_8 in pairs(Humanoid_upvr:GetPlayingAnimationTracks()) do
			v_8:Stop()
		end
	end
end)
SusanooCustom_upvr.complete.MouseButton1Down:connect(function() -- Line 278
	--[[ Upvalues[1]:
		[1]: SusanooCustom_upvr (readonly)
	]]
	SusanooCustom_upvr.Visible = false
	SusanooCustom_upvr.Parent.ingame.Visible = true
end)
local function returncolor3_upvr(arg1) -- Line 291, Named "returncolor3"
	-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
	local _ = 1
	-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [34] 29. Error Block 4 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [34] 29. Error Block 4 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [13] 13. Error Block 16 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	if string.len(arg1) == ',' then
		-- KONSTANTWARNING: GOTO [44] #38
	end
	-- KONSTANTERROR: [13] 13. Error Block 16 end (CF ANALYSIS FAILED)
end
local function equipmodeltobod2_upvr(arg1, arg2) -- Line 313, Named "equipmodeltobod2"
	for _, v_2 in pairs(arg2:GetChildren()) do
		if v_2:IsA("Part") or v_2:IsA("MeshPart") then
			local SOME_2 = arg1:FindFirstChild(v_2.Name)
			if SOME_2 and (SOME_2:IsA("Part") or SOME_2:IsA("MeshPart")) or SOME_2 then
				local Weld = Instance.new("Weld")
				Weld.Part0 = SOME_2
				Weld.Part1 = v_2
				Weld.Parent = v_2
				Weld.Name = "main"
			end
		end
	end
end
local baresusanoo_upvr = custosusanoo_upvr.baresusanoo
local PARTS_upvr = alljutsu.CUSTOMSUSANOO.PARTS
local FS_upvr = alljutsu.CUSTOMSUSANOO.FS
function customizesusanoo() -- Line 330
	--[[ Upvalues[10]:
		[1]: baresusanoo_upvr (readonly)
		[2]: fullsusanoo_upvr (readonly)
		[3]: LocalPlayer_upvr (readonly)
		[4]: PARTS_upvr (readonly)
		[5]: equipmodeltobod2_upvr (readonly)
		[6]: returncolor3_upvr (readonly)
		[7]: custosusanoo_upvr (readonly)
		[8]: Animation_upvr (readonly)
		[9]: Humanoid_upvr (readonly)
		[10]: FS_upvr (readonly)
	]]
	baresusanoo_upvr.cosmetics.custo:ClearAllChildren()
	fullsusanoo_upvr.cosmetics.custo:ClearAllChildren()
	for _, v_3 in pairs(LocalPlayer_upvr.statz.customsusanoo:GetChildren()) do
		local SOME_3 = PARTS_upvr:FindFirstChild(v_3.Value)
		if SOME_3 then
			local clone_2 = SOME_3:Clone()
			clone_2.Parent = baresusanoo_upvr.cosmetics.custo
			equipmodeltobod2_upvr(baresusanoo_upvr, clone_2)
		end
	end
	local Color3_fromRGB_result1_2_upvr = Color3.fromRGB(returncolor3_upvr(LocalPlayer_upvr.statz.customsusanoo.color.Value))
	local Color3_fromRGB_result1 = Color3.fromRGB(returncolor3_upvr(LocalPlayer_upvr.statz.customsusanoo.eyecolor.Value))
	baresusanoo_upvr.larm1.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.larm2.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.larm3.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.rarm1.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.rarm2.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.rarm3.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.head.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.larm.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.rarm.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.torso.Color = Color3_fromRGB_result1_2_upvr
	baresusanoo_upvr.eyes.Color = Color3_fromRGB_result1
	local function scan(arg1) -- Line 368
		--[[ Upvalues[2]:
			[1]: Color3_fromRGB_result1_2_upvr (readonly)
			[2]: scan (readonly)
		]]
		if arg1.Name == "skincolor" and arg1:IsA("MeshPart") then
			arg1.Color = Color3_fromRGB_result1_2_upvr
		end
		for _, v_4 in ipairs(arg1:GetChildren()) do
			scan(v_4)
		end
	end
	scan(custosusanoo_upvr.baresusanoo.cosmetics.custo)
	griptrack:Stop()
	if LocalPlayer_upvr.statz.customsusanoo.weapon.Value == "weapon1" then
		Animation_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5862375879
		griptrack = Humanoid_upvr:LoadAnimation(Animation_upvr) -- Setting global
		griptrack:Play()
	end
	if LocalPlayer_upvr.statz.customsusanoo.weapon.Value == "weapon2" then
		Animation_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5862399745
		griptrack = Humanoid_upvr:LoadAnimation(Animation_upvr) -- Setting global
		griptrack:Play()
	end
	if LocalPlayer_upvr.statz.customsusanoo.weapon.Value == "weapon3" then
		Animation_upvr.AnimationId = "http://www.roblox.com/asset/?id="..5862523942
		griptrack = Humanoid_upvr:LoadAnimation(Animation_upvr) -- Setting global
		griptrack:Play()
	end
	for _, v_5 in pairs(LocalPlayer_upvr.statz.customsusanoo:GetChildren()) do
		local SOME = FS_upvr:FindFirstChild(v_5.Value)
		if SOME then
			local clone = SOME:Clone()
			clone.Parent = fullsusanoo_upvr.cosmetics.custo
			equipmodeltobod2_upvr(fullsusanoo_upvr, clone)
		end
	end
	fullsusanoo_upvr.flarm1.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.flarm2.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.flarm3.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.frarm1.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.frarm2.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.frarm3.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.flleg1.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.flleg2.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.frleg1.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.frleg2.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.fhead.Color = Color3_fromRGB_result1_2_upvr
	fullsusanoo_upvr.head.eyes.Color = Color3_fromRGB_result1
	fullsusanoo_upvr.ftorso.Color = Color3_fromRGB_result1_2_upvr
	local function scan_upvr(arg1) -- Line 479, Named "scan"
		--[[ Upvalues[2]:
			[1]: Color3_fromRGB_result1_2_upvr (readonly)
			[2]: scan_upvr (readonly)
		]]
		if arg1.Name == "skincolor" and arg1:IsA("MeshPart") then
			arg1.Color = Color3_fromRGB_result1_2_upvr
		end
		for _, v_6 in ipairs(arg1:GetChildren()) do
			scan_upvr(v_6)
		end
	end
	scan_upvr(fullsusanoo_upvr.cosmetics.custo)
	scan_upvr(fullsusanoo_upvr)
end
customizesusanoo()
for _, v_7 in pairs(LocalPlayer_upvr.statz.customsusanoo:GetChildren()) do
	v_7.Changed:connect(function() -- Line 509
		customizesusanoo()
	end)
end
SusanooCustom_upvr.numberofspins.Text = '['..LocalPlayer_upvr.statz.spins.Value.." Spins]"
LocalPlayer_upvr.statz.spins.Changed:connect(function() -- Line 518
	--[[ Upvalues[2]:
		[1]: SusanooCustom_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
	]]
	SusanooCustom_upvr.numberofspins.Text = '['..LocalPlayer_upvr.statz.spins.Value.." Spins]"
end)