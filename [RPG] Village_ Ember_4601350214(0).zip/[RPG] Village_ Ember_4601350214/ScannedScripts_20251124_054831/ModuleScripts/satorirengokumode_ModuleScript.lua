-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:44:53
-- Luau version 6, Types version 3
-- Time taken: 0.006982 seconds

local module = {}
local RunService_upvr = game:GetService("RunService")
local TweenService_upvr = game:GetService("TweenService")
function module.start(arg1) -- Line 44
	--[[ Upvalues[2]:
		[1]: RunService_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	spawn(function() -- Line 45
		--[[ Upvalues[3]:
			[1]: arg1 (readonly)
			[2]: RunService_upvr (copied, readonly)
			[3]: TweenService_upvr (copied, readonly)
		]]
		local var5 = arg1
		local var6_upvr = var5
		local var7 = false
		if var5.Name == game.Players.LocalPlayer.Name then
			var7 = true
		end
		if var7 then
			workspace.Camera.CameraType = Enum.CameraType.Scriptable
			local any_Connect_result1_upvw = RunService_upvr.RenderStepped:Connect(function() -- Line 70
				--[[ Upvalues[1]:
					[1]: var6_upvr (readonly)
				]]
				workspace.Camera.CFrame = var6_upvr.HumanoidRootPart.CFrame * CFrame.new(0, 0, -4) * CFrame.Angles(0.1, math.pi, 0) + Vector3.new(0, 2, 0)
			end)
			task.delay(1.7, function() -- Line 76
				--[[ Upvalues[1]:
					[1]: any_Connect_result1_upvw (read and write)
				]]
				any_Connect_result1_upvw:Disconnect()
				workspace.Camera.CameraType = Enum.CameraType.Custom
			end)
			local clone_upvr = script:WaitForChild("tomoe"):clone()
			game.Debris:AddItem(clone_upvr, 1.7)
			clone_upvr.tomoes.Transparency = 0
			clone_upvr.Parent = var6_upvr
			local var13_upvw = 0
			spawn(function() -- Line 91
				--[[ Upvalues[4]:
					[1]: var6_upvr (readonly)
					[2]: clone_upvr (readonly)
					[3]: RunService_upvr (copied, readonly)
					[4]: var13_upvw (read and write)
				]]
				-- KONSTANTERROR: [10] 10. Error Block 7 start (CF ANALYSIS FAILED)
				RunService_upvr.RenderStepped:wait()
				var13_upvw += 0.1
				clone_upvr.CFrame = workspace.Camera.CFrame * CFrame.new(0, 0, -6) * CFrame.Angles(0, math.pi, 0) * CFrame.Angles(0, 0, -var13_upvw)
				clone_upvr.tomoes.Transparency = clone_upvr.tomoes.Transparency + 0.01
				-- KONSTANTERROR: [10] 10. Error Block 7 end (CF ANALYSIS FAILED)
				-- KONSTANTERROR: [0] 1. Error Block 10 start (CF ANALYSIS FAILED)
				-- KONSTANTERROR: Expression was reused, decompilation is incorrect (x3)
				if clone_upvr.tomoes and clone_upvr.tomoes and clone_upvr.tomoes then
					-- KONSTANTWARNING: GOTO [10] #10
				end
				-- KONSTANTERROR: [0] 1. Error Block 10 end (CF ANALYSIS FAILED)
			end)
			local clone_5_upvr = script.aabv:Clone()
			clone_5_upvr.Parent = game.Lighting
			local TweenInfo_new_result1_2_upvr = TweenInfo.new(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0)
			TweenService_upvr:Create(clone_5_upvr, TweenInfo_new_result1_2_upvr, {
				Saturation = -1;
			}):Play()
			game.Debris:AddItem(clone_5_upvr, 8)
			task.delay(0.5, function() -- Line 136
				--[[ Upvalues[3]:
					[1]: TweenService_upvr (copied, readonly)
					[2]: clone_5_upvr (readonly)
					[3]: TweenInfo_new_result1_2_upvr (readonly)
				]]
				TweenService_upvr:Create(clone_5_upvr, TweenInfo_new_result1_2_upvr, {
					Contrast = 0;
					Saturation = 0;
					TintColor = Color3.fromRGB(255, 255, 255);
				}):Play()
			end)
		end
		local TweenInfo_new_result1 = TweenInfo.new(0.2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, -1, true, 0)
		local clone_4 = script.Head.at1:Clone()
		local clone_3 = script.Head.at2:Clone()
		local clone = script.Head.at3:Clone()
		local clone_2 = script.Head.at4:Clone()
		clone_4.Parent = var6_upvr.Head
		clone_3.Parent = var6_upvr.Head
		clone.Parent = var6_upvr.Head
		clone_2.Parent = var6_upvr.Head
		TweenService_upvr:Create(clone_4.fire, TweenInfo_new_result1, {
			Acceleration = Vector3.new(20, 0, 0);
		}):Play()
		TweenService_upvr:Create(clone_3.fire, TweenInfo_new_result1, {
			Acceleration = Vector3.new(-20, 0, 0);
		}):Play()
		TweenService_upvr:Create(clone.fire, TweenInfo_new_result1, {
			Acceleration = Vector3.new(-20, 0, 0);
		}):Play()
		TweenService_upvr:Create(clone_2.fire, TweenInfo_new_result1, {
			Acceleration = Vector3.new(20, 0, 0);
		}):Play()
		game.Debris:AddItem(clone_4, 1.7)
		game.Debris:AddItem(clone_3, 1.7)
		game.Debris:AddItem(clone, 1.7)
		game.Debris:AddItem(clone_2, 1.7)
	end)
end
return module