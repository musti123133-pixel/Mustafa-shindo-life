-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:48:14
-- Luau version 6, Types version 3
-- Time taken: 0.042042 seconds

-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.Health, false)
local module_upvr_2 = require(ReplicatedStorage_upvr:WaitForChild("GlobalFunctions"))
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local Character = LocalPlayer_upvr.Character
if not Character then
	Character = LocalPlayer_upvr.CharacterAdded:wait()
end
local BladeCustom_upvr = script.Parent:WaitForChild("Main").BladeCustom
local var30_upvw = "blade1"
local module_upvr = require(ReplicatedStorage_upvr:WaitForChild("custosaber"))
module_upvr.custosaber(LocalPlayer_upvr, BladeCustom_upvr)
function upd() -- Line 45
	--[[ Upvalues[4]:
		[1]: var30_upvw (read and write)
		[2]: module_upvr (readonly)
		[3]: LocalPlayer_upvr (readonly)
		[4]: BladeCustom_upvr (readonly)
	]]
	if var30_upvw == "blade2" then
		module_upvr.custosaber(LocalPlayer_upvr, BladeCustom_upvr, custo2)
	else
		module_upvr.custosaber(LocalPlayer_upvr, BladeCustom_upvr, custo1)
	end
end
weldtype = "single" -- Setting global
custo1 = {} -- Setting global
custo1.hilt = 1
custo1.handle = 1
custo1.blade = 1
custo1.texture = "http://www.roblox.com/asset/?id=9191645975"
custo2 = {} -- Setting global
custo2.hilt = 1
custo2.handle = 1
custo2.blade = 1
custo2.texture = "http://www.roblox.com/asset/?id=9191645975"
module_upvr.custosaber(LocalPlayer_upvr, BladeCustom_upvr, custo1)
local var32_upvw = 1
BladeCustom_upvr.Frame.blade.text.Text = "[BLADE #"..var32_upvw..']'
BladeCustom_upvr.Frame.type.blade.arrowright.MouseButton1Down:connect(function() -- Line 74
	--[[ Upvalues[4]:
		[1]: var32_upvw (read and write)
		[2]: BladeCustom_upvr (readonly)
		[3]: var30_upvw (read and write)
		[4]: LocalPlayer_upvr (readonly)
	]]
	var32_upvw += 1
	if 2 < var32_upvw then
		var32_upvw = 1
	end
	BladeCustom_upvr.Frame.type.blade.text.Text = "[BLADE #"..var32_upvw..']'
	var30_upvw = "blade"..var32_upvw
	LocalPlayer_upvr.startevent:FireServer("cblade", "whichblade", var30_upvw)
	upd()
end)
BladeCustom_upvr.Frame.type.blade.arrowleft.MouseButton1Down:connect(function() -- Line 86
	--[[ Upvalues[4]:
		[1]: var32_upvw (read and write)
		[2]: BladeCustom_upvr (readonly)
		[3]: var30_upvw (read and write)
		[4]: LocalPlayer_upvr (readonly)
	]]
	var32_upvw -= 1
	if var32_upvw <= 0 then
		var32_upvw = 2
	end
	BladeCustom_upvr.Frame.type.blade.text.Text = "[BLADE #"..var32_upvw..']'
	var30_upvw = "blade"..var32_upvw
	LocalPlayer_upvr.startevent:FireServer("cblade", "whichblade", var30_upvw)
	upd()
end)
local var35_upvw = 1
BladeCustom_upvr.Frame.blade.text.Text = "[BLADE #"..var35_upvw..']'
BladeCustom_upvr.Frame.type.arrowright.MouseButton1Down:connect(function() -- Line 109
	--[[ Upvalues[3]:
		[1]: var35_upvw (read and write)
		[2]: BladeCustom_upvr (readonly)
		[3]: var30_upvw (read and write)
	]]
	var35_upvw += 1
	if 2 < var35_upvw then
		var35_upvw = 1
	end
	if var35_upvw == 2 then
		BladeCustom_upvr.Frame.type.text.Text = "[DUAL]"
		BladeCustom_upvr.Frame.type.blade.Visible = true
		weldtype = "dual" -- Setting global
	end
	if var35_upvw == 1 then
		BladeCustom_upvr.Frame.type.text.Text = "[SINGLE]"
		BladeCustom_upvr.Frame.type.blade.Visible = false
		BladeCustom_upvr.Frame.type.blade.text.Text = "[BLADE #1]"
		weldtype = "single" -- Setting global
		var30_upvw = "blade1"
	end
	upd()
end)
BladeCustom_upvr.Frame.type.arrowleft.MouseButton1Down:connect(function() -- Line 133
	--[[ Upvalues[3]:
		[1]: var35_upvw (read and write)
		[2]: BladeCustom_upvr (readonly)
		[3]: var30_upvw (read and write)
	]]
	var35_upvw -= 1
	if var35_upvw <= 0 then
		var35_upvw = 2
	end
	if var35_upvw == 2 then
		BladeCustom_upvr.Frame.type.text.Text = "[DUAL]"
		BladeCustom_upvr.Frame.type.blade.Visible = true
		weldtype = "dual" -- Setting global
	end
	if var35_upvw == 1 then
		BladeCustom_upvr.Frame.type.text.Text = "[SINGLE]"
		BladeCustom_upvr.Frame.type.blade.Visible = false
		BladeCustom_upvr.Frame.type.blade.text.Text = "[BLADE #1]"
		weldtype = "single" -- Setting global
		var30_upvw = "blade1"
	end
	upd()
end)
local var38_upvw = 1
BladeCustom_upvr.Frame.blade.text.Text = "[BLADE #"..var38_upvw..']'
BladeCustom_upvr.Frame.blade.arrowright.MouseButton1Down:connect(function() -- Line 171
	--[[ Upvalues[3]:
		[1]: var38_upvw (read and write)
		[2]: var30_upvw (read and write)
		[3]: BladeCustom_upvr (readonly)
	]]
	var38_upvw += 1
	if 4 < var38_upvw then
		var38_upvw = 1
	end
	if var30_upvw == "blade1" then
		custo1.blade = var38_upvw
	else
		custo2.blade = var38_upvw
	end
	BladeCustom_upvr.Frame.blade.text.Text = "[BLADE #"..var38_upvw..']'
	upd()
end)
BladeCustom_upvr.Frame.blade.arrowleft.MouseButton1Down:connect(function() -- Line 190
	--[[ Upvalues[3]:
		[1]: var38_upvw (read and write)
		[2]: var30_upvw (read and write)
		[3]: BladeCustom_upvr (readonly)
	]]
	var38_upvw -= 1
	if var38_upvw <= 0 then
		var38_upvw = 4
	end
	if var30_upvw == "blade1" then
		custo1.blade = var38_upvw
	else
		custo2.blade = var38_upvw
	end
	BladeCustom_upvr.Frame.blade.text.Text = "[BLADE #"..var38_upvw..']'
	upd()
end)
local var41_upvw = 1
BladeCustom_upvr.Frame.handle.text.Text = "[HANDLE #"..var41_upvw..']'
BladeCustom_upvr.Frame.handle.arrowright.MouseButton1Down:connect(function() -- Line 216
	--[[ Upvalues[3]:
		[1]: var41_upvw (read and write)
		[2]: var30_upvw (read and write)
		[3]: BladeCustom_upvr (readonly)
	]]
	var41_upvw += 1
	if 4 < var41_upvw then
		var41_upvw = 1
	end
	if var30_upvw == "blade1" then
		custo1.handle = var41_upvw
	else
		custo2.handle = var41_upvw
	end
	BladeCustom_upvr.Frame.handle.text.Text = "[HANDLE #"..var41_upvw..']'
	upd()
end)
BladeCustom_upvr.Frame.handle.arrowleft.MouseButton1Down:connect(function() -- Line 234
	--[[ Upvalues[3]:
		[1]: var41_upvw (read and write)
		[2]: var30_upvw (read and write)
		[3]: BladeCustom_upvr (readonly)
	]]
	var41_upvw -= 1
	if var41_upvw <= 0 then
		var41_upvw = 4
	end
	if var30_upvw == "blade1" then
		custo1.handle = var41_upvw
	else
		custo2.handle = var41_upvw
	end
	BladeCustom_upvr.Frame.handle.text.Text = "[HANDLE #"..var41_upvw..']'
	upd()
end)
local var44_upvw = 0
BladeCustom_upvr.Frame.hilt.text.Text = "[HILT #"..var44_upvw..']'
BladeCustom_upvr.Frame.hilt.arrowright.MouseButton1Down:connect(function() -- Line 254
	--[[ Upvalues[3]:
		[1]: var44_upvw (read and write)
		[2]: var30_upvw (read and write)
		[3]: BladeCustom_upvr (readonly)
	]]
	var44_upvw += 1
	if 5 < var44_upvw then
		var44_upvw = 0
	end
	if var30_upvw == "blade1" then
		custo1.hilt = var44_upvw
	else
		custo2.hilt = var44_upvw
	end
	BladeCustom_upvr.Frame.hilt.text.Text = "[HILT #"..var44_upvw..']'
	upd()
end)
BladeCustom_upvr.Frame.hilt.arrowleft.MouseButton1Down:connect(function() -- Line 271
	--[[ Upvalues[3]:
		[1]: var44_upvw (read and write)
		[2]: var30_upvw (read and write)
		[3]: BladeCustom_upvr (readonly)
	]]
	var44_upvw -= 1
	if var44_upvw < 0 then
		var44_upvw = 5
	end
	if var30_upvw == "blade1" then
		custo1.hilt = var44_upvw
	else
		custo2.hilt = var44_upvw
	end
	BladeCustom_upvr.Frame.hilt.text.Text = "[HILT #"..var44_upvw..']'
	upd()
end)
local mouse_upvr = LocalPlayer_upvr:GetMouse()
spawn(function() -- Line 293
	--[[ Upvalues[2]:
		[1]: BladeCustom_upvr (readonly)
		[2]: mouse_upvr (readonly)
	]]
	local PREVIEW_upvr = BladeCustom_upvr.PREVIEW
	local cframe_upvr = CFrame.Angles(0, (math.pi/2), 0)
	local var51_upvw = false
	local var52_upvw = 0
	local var53_upvw = 0
	BladeCustom_upvr.PREVIEW.drag.MouseButton1Down:connect(function() -- Line 299
		--[[ Upvalues[4]:
			[1]: var52_upvw (read and write)
			[2]: mouse_upvr (copied, readonly)
			[3]: var53_upvw (read and write)
			[4]: var51_upvw (read and write)
		]]
		var52_upvw = mouse_upvr.X
		var53_upvw = mouse_upvr.Y
		var51_upvw = true
	end)
	BladeCustom_upvr.PREVIEW.drag.MouseButton1Up:connect(function() -- Line 304
		--[[ Upvalues[3]:
			[1]: PREVIEW_upvr (readonly)
			[2]: var51_upvw (read and write)
			[3]: cframe_upvr (readonly)
		]]
		if PREVIEW_upvr.saber:FindFirstChild("Camera") then
			if var51_upvw then
				local Camera_3 = PREVIEW_upvr.saber:FindFirstChild("Camera")
				if Camera_3 then
					Camera_3.CFrame = cframe_upvr * CFrame.new(0, 2, 6)
				end
			end
		end
		var51_upvw = false
	end)
	BladeCustom_upvr.PREVIEW.drag.MouseLeave:connect(function() -- Line 316
		--[[ Upvalues[3]:
			[1]: PREVIEW_upvr (readonly)
			[2]: var51_upvw (read and write)
			[3]: cframe_upvr (readonly)
		]]
		if PREVIEW_upvr.saber:FindFirstChild("Camera") then
			if var51_upvw then
				local Camera_2 = PREVIEW_upvr.saber:FindFirstChild("Camera")
				if Camera_2 then
					Camera_2.CFrame = cframe_upvr * CFrame.new(0, 2, 6)
				end
			end
		end
		var51_upvw = false
	end)
	PREVIEW_upvr.saber.ChildAdded:connect(function(arg1) -- Line 331
		--[[ Upvalues[2]:
			[1]: PREVIEW_upvr (readonly)
			[2]: cframe_upvr (readonly)
		]]
		wait(0.1)
		local Camera_4 = PREVIEW_upvr.saber:FindFirstChild("Camera")
		if Camera_4 then
			Camera_4.CFrame = cframe_upvr * CFrame.new(0, 2, 6)
		end
	end)
	local var63_upvw = 0
	local var64_upvw = 0
	mouse_upvr.Move:connect(function() -- Line 340
		--[[ Upvalues[8]:
			[1]: PREVIEW_upvr (readonly)
			[2]: var51_upvw (read and write)
			[3]: var63_upvw (read and write)
			[4]: var52_upvw (read and write)
			[5]: mouse_upvr (copied, readonly)
			[6]: var64_upvw (read and write)
			[7]: var53_upvw (read and write)
			[8]: cframe_upvr (readonly)
		]]
		local Camera = PREVIEW_upvr.saber:FindFirstChild("Camera")
		if Camera then
			if var51_upvw then
				var63_upvw = var52_upvw - mouse_upvr.X
				var64_upvw = var53_upvw - mouse_upvr.Y
				Camera.CFrame = cframe_upvr * CFrame.Angles(0, math.rad(var63_upvw * 2), 0) * CFrame.Angles(math.rad(var64_upvw), 0, 0) * CFrame.new(0, 2, 6)
			end
		end
	end)
end)
BladeCustom_upvr.Frame.bladetexture.bg.Image = LocalPlayer_upvr.statz.customblade.customtexture.Value
BladeCustom_upvr.Frame.bladetexture.text.Changed:Connect(function() -- Line 364
	--[[ Upvalues[2]:
		[1]: BladeCustom_upvr (readonly)
		[2]: var30_upvw (read and write)
	]]
	if tonumber(BladeCustom_upvr.Frame.bladetexture.text.Text) then
		BladeCustom_upvr.Frame.bladetexture.bg.Image = "https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId="..BladeCustom_upvr.Frame.bladetexture.text.Text
		if var30_upvw == "blade2" then
			custo2.texture = BladeCustom_upvr.Frame.bladetexture.bg.Image
		else
			custo1.texture = BladeCustom_upvr.Frame.bladetexture.bg.Image
		end
		upd()
	else
		BladeCustom_upvr.Frame.bladetexture.bg.Image = "http://www.roblox.com/asset/?id=9191645975"
		if var30_upvw == "blade2" then
			custo2.texture = BladeCustom_upvr.Frame.bladetexture.bg.Image
		else
			custo1.texture = BladeCustom_upvr.Frame.bladetexture.bg.Image
		end
		upd()
	end
end)
local combat_upvr = Character:WaitForChild("combat")
BladeCustom_upvr:GetPropertyChangedSignal("Visible"):Connect(function() -- Line 407
	--[[ Upvalues[3]:
		[1]: BladeCustom_upvr (readonly)
		[2]: combat_upvr (readonly)
		[3]: module_upvr_2 (readonly)
	]]
	if BladeCustom_upvr.Visible then
		combat_upvr.update:FireServer("susanoocuso", true)
		if BladeCustom_upvr.Visible then
			wait(1)
			if 20 <= 20 + 1 then
				local tbl = {9196345047, 9196345611, 9196345419, 919634578}
				module_upvr_2.sound(script, tbl[math.random(1, #tbl)])
			end
			-- KONSTANTWARNING: GOTO [13] #11
		end
	else
		combat_upvr.update:FireServer("susanoocuso", false)
		module_upvr_2.sound(script, 9196345161, 0.5)
	end
end)
BladeCustom_upvr.complete.MouseButton1Down:connect(function() -- Line 441
	--[[ Upvalues[1]:
		[1]: BladeCustom_upvr (readonly)
	]]
	BladeCustom_upvr.Visible = false
	BladeCustom_upvr.Parent.ingame.Visible = true
end)
BladeCustom_upvr.numberofspins.Text = '['..LocalPlayer_upvr.statz.spins.Value.." Spins]"
LocalPlayer_upvr.statz.spins.Changed:connect(function() -- Line 454
	--[[ Upvalues[2]:
		[1]: BladeCustom_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
	]]
	BladeCustom_upvr.numberofspins.Text = '['..LocalPlayer_upvr.statz.spins.Value.." Spins]"
end)
for _, v in pairs(LocalPlayer_upvr.statz.customblade.blade1:GetChildren()) do
	v.Changed:connect(function() -- Line 462
		--[[ Upvalues[3]:
			[1]: module_upvr (readonly)
			[2]: LocalPlayer_upvr (readonly)
			[3]: BladeCustom_upvr (readonly)
		]]
		wait(0.1)
		module_upvr.custosaber(LocalPlayer_upvr, BladeCustom_upvr)
	end)
	local var76_upvr
end
for _, v_2 in pairs(LocalPlayer_upvr.statz.customblade.blade2:GetChildren()) do
	v_2.Changed:connect(function() -- Line 469
		--[[ Upvalues[3]:
			[1]: var76_upvr (readonly)
			[2]: LocalPlayer_upvr (readonly)
			[3]: BladeCustom_upvr (readonly)
		]]
		wait(0.1)
		var76_upvr.custosaber(LocalPlayer_upvr, BladeCustom_upvr)
	end)
	local var81_upvr
end
for _, v_3 in pairs(LocalPlayer_upvr.statz.customblade:GetChildren()) do
	if v_3:IsA("Folder") then
	else
		v_3.Changed:connect(function() -- Line 477
			--[[ Upvalues[3]:
				[1]: var81_upvr (readonly)
				[2]: LocalPlayer_upvr (readonly)
				[3]: BladeCustom_upvr (readonly)
			]]
			wait(0.1)
			var81_upvr.custosaber(LocalPlayer_upvr, BladeCustom_upvr)
		end)
	end
end
function check() -- Line 489
	--[[ Upvalues[3]:
		[1]: ReplicatedStorage_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
		[3]: BladeCustom_upvr (readonly)
	]]
	local SOME = ReplicatedStorage_upvr.alljutsu.ALLKENSTYLES:FindFirstChild(LocalPlayer_upvr.statz.breathingstyle.Value)
	if SOME then
		BladeCustom_upvr.kentrain.title.Text = "[Kenjutsu: "..SOME.REALNAME.Value..']'
	end
	local SOME_6 = LocalPlayer_upvr.statz.genkailevel:FindFirstChild(LocalPlayer_upvr.statz.breathingstyle.Value.."trainer")
	if SOME_6 then
		BladeCustom_upvr.kentrain.bg.name.bar.num.Text = SOME_6.exp.Value..'/'..SOME_6.maxexp.Value
		BladeCustom_upvr.kentrain.bg.name.bar.move.Size = UDim2.new((1) * (SOME_6.exp.Value / SOME_6.maxexp.Value), 0, 1, 0)
	end
	local SOME_4 = ReplicatedStorage_upvr.alljutsu.ALLKENSTYLES:FindFirstChild(LocalPlayer_upvr.statz.breathingstyle2.Value)
	if SOME_4 then
		BladeCustom_upvr.kentrain2.title.Text = "[Kenjutsu: "..SOME_4.REALNAME.Value..']'
	end
	local SOME_2 = LocalPlayer_upvr.statz.genkailevel:FindFirstChild(LocalPlayer_upvr.statz.breathingstyle2.Value.."trainer")
	if SOME_2 then
		BladeCustom_upvr.kentrain2.bg.name.bar.num.Text = SOME_2.exp.Value..'/'..SOME_2.maxexp.Value
		BladeCustom_upvr.kentrain2.bg.name.bar.move.Size = UDim2.new((1) * (SOME_2.exp.Value / SOME_2.maxexp.Value), 0, 1, 0)
	end
end
check()
LocalPlayer_upvr.statz.breathingstyle.Changed:Connect(function() -- Line 524
	check()
end)
BladeCustom_upvr.kentrain.bg.enter.MouseButton1Down:connect(function() -- Line 531
	--[[ Upvalues[3]:
		[1]: LocalPlayer_upvr (readonly)
		[2]: module_upvr_2 (readonly)
		[3]: BladeCustom_upvr (readonly)
	]]
	local SOME_5 = LocalPlayer_upvr.statz.genkailevel:FindFirstChild(LocalPlayer_upvr.statz.breathingstyle.Value.."trainer")
	if SOME_5 then
		if 5 <= SOME_5.exp.Value then
			module_upvr_2.putnoti(LocalPlayer_upvr, "You are already maxed in this kenjutsu, try training another kenjutsu.")
			return
		end
		BladeCustom_upvr.Visible = false
		BladeCustom_upvr.Parent.ingame.Visible = true
		LocalPlayer_upvr.startevent:FireServer("trainkenmaster")
	end
end)
BladeCustom_upvr.kentrain2.bg.enter.MouseButton1Down:connect(function() -- Line 546
	--[[ Upvalues[3]:
		[1]: LocalPlayer_upvr (readonly)
		[2]: module_upvr_2 (readonly)
		[3]: BladeCustom_upvr (readonly)
	]]
	local SOME_3 = LocalPlayer_upvr.statz.genkailevel:FindFirstChild(LocalPlayer_upvr.statz.breathingstyle2.Value.."trainer")
	if SOME_3 then
		if 5 <= SOME_3.exp.Value then
			module_upvr_2.putnoti(LocalPlayer_upvr, "You are already maxed in this kenjutsu, try training another kenjutsu.")
			return
		end
		BladeCustom_upvr.Visible = false
		BladeCustom_upvr.Parent.ingame.Visible = true
		LocalPlayer_upvr.startevent:FireServer("trainkenmaster2")
	end
end)
if LocalPlayer_upvr.statz.unlocked:FindFirstChild("kenjutsuslot2") then
	BladeCustom_upvr.kentrain2.Visible = true
end
LocalPlayer_upvr.statz.unlocked.ChildAdded:connect(function() -- Line 566
	--[[ Upvalues[2]:
		[1]: LocalPlayer_upvr (readonly)
		[2]: BladeCustom_upvr (readonly)
	]]
	wait(0.1)
	if LocalPlayer_upvr.statz.unlocked:FindFirstChild("kenjutsuslot2") then
		BladeCustom_upvr.kentrain2.Visible = true
	end
end)
BladeCustom_upvr.top.save.MouseButton1Down:connect(function() -- Line 576
	--[[ Upvalues[2]:
		[1]: LocalPlayer_upvr (readonly)
		[2]: module_upvr_2 (readonly)
	]]
	if 10000 <= LocalPlayer_upvr.statz.arena.cash.Value and 20 <= LocalPlayer_upvr.statz.spins.Value then
		LocalPlayer_upvr.startevent:FireServer("cblade", "buy", {custo1, custo2, weldtype})
	else
		module_upvr_2.putnoti(LocalPlayer_upvr, "Not Enough RC/SPINS to obtain a custom blade.")
		return
	end
end)