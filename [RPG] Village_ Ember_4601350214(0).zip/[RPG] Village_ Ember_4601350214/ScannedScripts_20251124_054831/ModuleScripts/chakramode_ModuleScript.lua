-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:44:51
-- Luau version 6, Types version 3
-- Time taken: 0.006679 seconds

local module = {}
local ClientEffects_upvr = workspace.ClientEffects
local TweenService_upvr = game:GetService("TweenService")
function module.make(arg1, arg2) -- Line 44
	--[[ Upvalues[2]:
		[1]: ClientEffects_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	spawn(function() -- Line 45
		--[[ Upvalues[4]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: ClientEffects_upvr (copied, readonly)
			[4]: TweenService_upvr (copied, readonly)
		]]
		local _2 = arg2[2]
		local _1 = arg2[1]
		local clone_upvr = script.beastbomb:Clone()
		clone_upvr.Color = _2
		clone_upvr.Parent = ClientEffects_upvr
		clone_upvr.Size = Vector3.new()
		clone_upvr.CFrame = _1
		TweenService_upvr:Create(clone_upvr, TweenInfo.new(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
			Size = Vector3.new(20, 20, 20);
		}):Play()
		delay(0.5, function() -- Line 88
			--[[ Upvalues[2]:
				[1]: TweenService_upvr (copied, readonly)
				[2]: clone_upvr (readonly)
			]]
			TweenService_upvr:Create(clone_upvr, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 4, true, 0), {
				Size = Vector3.new(20 + math.random(10, 15), 20 + math.random(10, 15), 20 + math.random(10, 15));
			}):Play()
			delay(0.4, function() -- Line 114
				--[[ Upvalues[2]:
					[1]: TweenService_upvr (copied, readonly)
					[2]: clone_upvr (copied, readonly)
				]]
				TweenService_upvr:Create(clone_upvr, TweenInfo.new(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
					Transparency = 1;
					Size = Vector3.new(20, 20, 20);
				}):Play()
				game.Debris:AddItem(clone_upvr, 1)
			end)
		end)
		for _ = 1, 7 do
			wait(0.1)
			local clone = script.Ring2:Clone()
			clone.Parent = ClientEffects_upvr
			clone.Color = _2
			clone.CFrame = _1 - Vector3.new(0, 20, 0)
			game.Debris:AddItem(clone, 1)
			TweenService_upvr:Create(clone, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, true, 0), {
				Size = Vector3.new(50, 2, 50);
			}):Play()
			TweenService_upvr:Create(clone, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, false, 0), {
				CFrame = clone.CFrame * CFrame.Angles(0, math.pi, 0) + Vector3.new(0, 50, 0);
				Transparency = 1;
			}):Play()
		end
	end)
end
return module