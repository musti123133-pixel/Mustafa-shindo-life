-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:43:46
-- Luau version 6, Types version 3
-- Time taken: 0.006776 seconds

local module = {}
local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
local TweenService_upvr = game:GetService("TweenService")
function module.make(arg1, arg2) -- Line 44
	--[[ Upvalues[2]:
		[1]: ReplicatedStorage_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	spawn(function() -- Line 45
		--[[ Upvalues[4]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: ReplicatedStorage_upvr (copied, readonly)
			[4]: TweenService_upvr (copied, readonly)
		]]
		-- KONSTANTERROR: [61] 47. Error Block 4 start (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [61] 47. Error Block 4 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [0] 1. Error Block 21 start (CF ANALYSIS FAILED)
		-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [61.9]
		if nil then
			-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [62.1]
			-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [87.5]
			nil:SetPrimaryPartCFrame(nil.CFrame * CFrame.Angles(0, 0, 0) * CFrame.new(math.random(-2, 2), 0, math.random(-2, 2)))
			if math.random(1, 2) == 1 then
				-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [97.4]
				nil.sound(nil, 9128248753, 0.1)
			end
			-- KONSTANTERROR: Expression was reused, decompilation is incorrect
			for _, v in pairs(nil.enemyclone:GetChildren()) do
				-- KONSTANTERROR: Expression was reused, decompilation is incorrect
				v:SetPrimaryPartCFrame(nil.CFrame * CFrame.new(math.random(-5, 5), 0, math.random(-5, 5)))
				local Attachment = Instance.new("Attachment")
				Attachment.Parent = workspace.Terrain
				Attachment.WorldPosition = v.Torso.CFrame.p
				local clone = ReplicatedStorage_upvr.flicker.flicker:Clone()
				clone.Parent = Attachment
				clone:Emit(1)
				game.Debris:AddItem(Attachment, 2)
			end
			-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [176.6]
			-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [176.7]
			-- KONSTANTWARNING: GOTO [51] #39
		end
		-- KONSTANTERROR: [0] 1. Error Block 21 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [177] 129. Error Block 17 start (CF ANALYSIS FAILED)
		nil:Destroy()
		-- KONSTANTERROR: [177] 129. Error Block 17 end (CF ANALYSIS FAILED)
	end)
end
return module