-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-11-24 02:48:16
-- Luau version 6, Types version 3
-- Time taken: 0.046013 seconds

local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.Health, false)
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local Character = LocalPlayer_upvr.Character
if not Character then
	Character = LocalPlayer_upvr.CharacterAdded:wait()
end
local ingame_upvr = script.Parent:WaitForChild("Main").ingame
local MovesetsTab_upvr = ingame_upvr.Menu.MovesetsTab
local alljutsu_upvr = ReplicatedStorage_upvr.alljutsu
local tbl_upvr = {}
function collectallmodule(arg1) -- Line 35
	--[[ Upvalues[1]:
		[1]: tbl_upvr (readonly)
	]]
	for _, v in pairs(arg1:GetChildren()) do
		if v:IsA("ModuleScript") then
			tbl_upvr[v.Name] = v
		end
		collectallmodule(v)
	end
end
collectallmodule(alljutsu_upvr)
local function _(arg1) -- Line 57, Named "findmodule"
	--[[ Upvalues[2]:
		[1]: ReplicatedStorage_upvr (readonly)
		[2]: tbl_upvr (readonly)
	]]
	local SOME_35 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(arg1)
	if SOME_35 then
		return SOME_35
	end
	return tbl_upvr[arg1]
end
MovesetsTab_upvr.outfit1.sear.MouseButton1Down:connect(function() -- Line 95
	--[[ Upvalues[6]:
		[1]: MovesetsTab_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
		[3]: ReplicatedStorage_upvr (readonly)
		[4]: tbl_upvr (readonly)
		[5]: alljutsu_upvr (readonly)
		[6]: ingame_upvr (readonly)
	]]
	for _, v_2 in pairs(MovesetsTab_upvr:GetChildren()) do
		if v_2:IsA("ImageLabel") then
			v_2.Image = "http://www.roblox.com/asset/?id=4855243579"
		end
	end
	local save1_2 = LocalPlayer_upvr.statz.movesetsaving.save1
	for _, v_3 in pairs(MovesetsTab_upvr:GetChildren()) do
		local SOME_9 = save1_2:FindFirstChild(string.lower(v_3.Name))
		if save1_2:FindFirstChild(string.lower(v_3.Name)) then
			local Value_41 = SOME_9.Value
			local var69
			local SOME_12 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_41)
			if SOME_12 then
				var69 = SOME_12
			else
				var69 = tbl_upvr[Value_41]
			end
			if var69 then
				local Value_38 = SOME_9.Value
				var69 = nil
				local var72 = var69
				local SOME_10 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_38)
				if SOME_10 then
					var72 = SOME_10
				else
					var72 = tbl_upvr[Value_38]
				end
				if var72:FindFirstChild("img") then
					local Value_29 = SOME_9.Value
					local var75
					local SOME_2 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_29)
					if SOME_2 then
						var75 = SOME_2
					else
						var75 = tbl_upvr[Value_29]
					end
					v_3.Image = var75.img.Texture
				end
			end
		end
	end
	if alljutsu_upvr:FindFirstChild(save1_2.c.Value) then
		MovesetsTab_upvr.C.Image = alljutsu_upvr:FindFirstChild(save1_2.c.Value).img.Texture
	end
	local Value_27 = save1_2.rightarmsword.Value
	local var78
	local SOME_36 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_27)
	if SOME_36 then
		var78 = SOME_36
	else
		var78 = tbl_upvr[Value_27]
	end
	if var78 then
		local Value_28 = save1_2.rightarmsword.Value
		local var81
		local SOME_18 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_28)
		if SOME_18 then
			var81 = SOME_18
		else
			var81 = tbl_upvr[Value_28]
		end
		MovesetsTab_upvr.wep.Image = var81.img.Texture
	end
	local Value_35 = save1_2.throwable.Value
	local var84
	local SOME_47 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_35)
	if SOME_47 then
		var84 = SOME_47
	else
		var84 = tbl_upvr[Value_35]
	end
	if var84 then
		MovesetsTab_upvr.E.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save1_2.throwable.Value).Image
	end
	local Value_19 = save1_2.throwable2.Value
	local var87
	local SOME_41 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_19)
	if SOME_41 then
		var87 = SOME_41
	else
		var87 = tbl_upvr[Value_19]
	end
	if var87 then
		MovesetsTab_upvr.e2.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save1_2.throwable2.Value).Image
	end
end)
MovesetsTab_upvr.outfit2.sear.MouseButton1Down:connect(function() -- Line 128
	--[[ Upvalues[6]:
		[1]: MovesetsTab_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
		[3]: ReplicatedStorage_upvr (readonly)
		[4]: tbl_upvr (readonly)
		[5]: alljutsu_upvr (readonly)
		[6]: ingame_upvr (readonly)
	]]
	for _, v_4 in pairs(MovesetsTab_upvr:GetChildren()) do
		if v_4:IsA("ImageLabel") then
			v_4.Image = "http://www.roblox.com/asset/?id=4855243579"
		end
	end
	local save2 = LocalPlayer_upvr.statz.movesetsaving.save2
	for _, v_5 in pairs(MovesetsTab_upvr:GetChildren()) do
		local SOME_27 = save2:FindFirstChild(string.lower(v_5.Name))
		if save2:FindFirstChild(string.lower(v_5.Name)) then
			local Value_25 = SOME_27.Value
			local var107
			local SOME_13 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_25)
			if SOME_13 then
				var107 = SOME_13
			else
				var107 = tbl_upvr[Value_25]
			end
			if var107 then
				local Value_34 = SOME_27.Value
				var107 = nil
				local var110 = var107
				local SOME_48 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_34)
				if SOME_48 then
					var110 = SOME_48
				else
					var110 = tbl_upvr[Value_34]
				end
				if var110:FindFirstChild("img") then
					local Value_39 = SOME_27.Value
					local var113
					local SOME_22 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_39)
					if SOME_22 then
						var113 = SOME_22
					else
						var113 = tbl_upvr[Value_39]
					end
					v_5.Image = var113.img.Texture
				end
			end
		end
	end
	if alljutsu_upvr:FindFirstChild(save2.c.Value) then
		MovesetsTab_upvr.C.Image = alljutsu_upvr:FindFirstChild(save2.c.Value).img.Texture
	end
	local Value_6 = save2.rightarmsword.Value
	local var116
	local SOME_42 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_6)
	if SOME_42 then
		var116 = SOME_42
	else
		var116 = tbl_upvr[Value_6]
	end
	if var116 then
		local Value_9 = save2.rightarmsword.Value
		local var119
		local SOME_15 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_9)
		if SOME_15 then
			var119 = SOME_15
		else
			var119 = tbl_upvr[Value_9]
		end
		MovesetsTab_upvr.wep.Image = var119.img.Texture
	end
	local Value_42 = save2.throwable.Value
	local var122
	local SOME_17 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_42)
	if SOME_17 then
		var122 = SOME_17
	else
		var122 = tbl_upvr[Value_42]
	end
	if var122 then
		MovesetsTab_upvr.E.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save2.throwable.Value).Image
	end
	local Value_5 = save2.throwable2.Value
	local var125
	local SOME_24 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_5)
	if SOME_24 then
		var125 = SOME_24
	else
		var125 = tbl_upvr[Value_5]
	end
	if var125 then
		MovesetsTab_upvr.e2.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save2.throwable2.Value).Image
	end
end)
MovesetsTab_upvr.outfit3.sear.MouseButton1Down:connect(function() -- Line 159
	--[[ Upvalues[6]:
		[1]: MovesetsTab_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
		[3]: ReplicatedStorage_upvr (readonly)
		[4]: tbl_upvr (readonly)
		[5]: alljutsu_upvr (readonly)
		[6]: ingame_upvr (readonly)
	]]
	for _, v_6 in pairs(MovesetsTab_upvr:GetChildren()) do
		if v_6:IsA("ImageLabel") then
			v_6.Image = "http://www.roblox.com/asset/?id=4855243579"
		end
	end
	local save3 = LocalPlayer_upvr.statz.movesetsaving.save3
	for _, v_7 in pairs(MovesetsTab_upvr:GetChildren()) do
		local SOME_21 = save3:FindFirstChild(string.lower(v_7.Name))
		if save3:FindFirstChild(string.lower(v_7.Name)) then
			local Value_4 = SOME_21.Value
			local var145
			local SOME_45 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_4)
			if SOME_45 then
				var145 = SOME_45
			else
				var145 = tbl_upvr[Value_4]
			end
			if var145 then
				local Value_23 = SOME_21.Value
				var145 = nil
				local var148 = var145
				local SOME_19 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_23)
				if SOME_19 then
					var148 = SOME_19
				else
					var148 = tbl_upvr[Value_23]
				end
				if var148:FindFirstChild("img") then
					local Value_7 = SOME_21.Value
					local var151
					local SOME_37 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_7)
					if SOME_37 then
						var151 = SOME_37
					else
						var151 = tbl_upvr[Value_7]
					end
					v_7.Image = var151.img.Texture
				end
			end
		end
	end
	if alljutsu_upvr:FindFirstChild(save3.c.Value) then
		MovesetsTab_upvr.C.Image = alljutsu_upvr:FindFirstChild(save3.c.Value).img.Texture
	end
	local Value_21 = save3.rightarmsword.Value
	local var154
	local SOME_8 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_21)
	if SOME_8 then
		var154 = SOME_8
	else
		var154 = tbl_upvr[Value_21]
	end
	if var154 then
		local Value_2 = save3.rightarmsword.Value
		local var157
		local SOME_44 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_2)
		if SOME_44 then
			var157 = SOME_44
		else
			var157 = tbl_upvr[Value_2]
		end
		MovesetsTab_upvr.wep.Image = var157.img.Texture
	end
	local Value_13 = save3.throwable.Value
	local var160
	local SOME_33 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_13)
	if SOME_33 then
		var160 = SOME_33
	else
		var160 = tbl_upvr[Value_13]
	end
	if var160 then
		MovesetsTab_upvr.E.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save3.throwable.Value).Image
	end
	local Value_40 = save3.throwable2.Value
	local var163
	local SOME_43 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_40)
	if SOME_43 then
		var163 = SOME_43
	else
		var163 = tbl_upvr[Value_40]
	end
	if var163 then
		MovesetsTab_upvr.e2.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save3.throwable2.Value).Image
	end
end)
MovesetsTab_upvr.outfit4.sear.MouseButton1Down:connect(function() -- Line 189
	--[[ Upvalues[6]:
		[1]: MovesetsTab_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
		[3]: ReplicatedStorage_upvr (readonly)
		[4]: tbl_upvr (readonly)
		[5]: alljutsu_upvr (readonly)
		[6]: ingame_upvr (readonly)
	]]
	for _, v_8 in pairs(MovesetsTab_upvr:GetChildren()) do
		if v_8:IsA("ImageLabel") then
			v_8.Image = "http://www.roblox.com/asset/?id=4855243579"
		end
	end
	local save4 = LocalPlayer_upvr.statz.movesetsaving.save4
	for _, v_9 in pairs(MovesetsTab_upvr:GetChildren()) do
		local SOME_40 = save4:FindFirstChild(string.lower(v_9.Name))
		if save4:FindFirstChild(string.lower(v_9.Name)) then
			local Value_37 = SOME_40.Value
			local var183
			local SOME_29 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_37)
			if SOME_29 then
				var183 = SOME_29
			else
				var183 = tbl_upvr[Value_37]
			end
			if var183 then
				local Value_31 = SOME_40.Value
				var183 = nil
				local var186 = var183
				local SOME_5 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_31)
				if SOME_5 then
					var186 = SOME_5
				else
					var186 = tbl_upvr[Value_31]
				end
				if var186:FindFirstChild("img") then
					local Value_30 = SOME_40.Value
					local var189
					local SOME_38 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_30)
					if SOME_38 then
						var189 = SOME_38
					else
						var189 = tbl_upvr[Value_30]
					end
					v_9.Image = var189.img.Texture
				end
			end
		end
	end
	if alljutsu_upvr:FindFirstChild(save4.c.Value) then
		MovesetsTab_upvr.C.Image = alljutsu_upvr:FindFirstChild(save4.c.Value).img.Texture
	end
	local Value_15 = save4.rightarmsword.Value
	local var192
	local SOME_4 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_15)
	if SOME_4 then
		var192 = SOME_4
	else
		var192 = tbl_upvr[Value_15]
	end
	if var192 then
		local Value_8 = save4.rightarmsword.Value
		local var195
		local SOME_14 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_8)
		if SOME_14 then
			var195 = SOME_14
		else
			var195 = tbl_upvr[Value_8]
		end
		MovesetsTab_upvr.wep.Image = var195.img.Texture
	end
	local Value_24 = save4.throwable.Value
	local var198
	local SOME_7 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_24)
	if SOME_7 then
		var198 = SOME_7
	else
		var198 = tbl_upvr[Value_24]
	end
	if var198 then
		MovesetsTab_upvr.E.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save4.throwable.Value).Image
	end
	local Value_17 = save4.throwable2.Value
	local var201
	local SOME_25 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_17)
	if SOME_25 then
		var201 = SOME_25
	else
		var201 = tbl_upvr[Value_17]
	end
	if var201 then
		MovesetsTab_upvr.e2.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save4.throwable2.Value).Image
	end
end)
MovesetsTab_upvr.outfit5.sear.MouseButton1Down:connect(function() -- Line 219
	--[[ Upvalues[6]:
		[1]: MovesetsTab_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
		[3]: ReplicatedStorage_upvr (readonly)
		[4]: tbl_upvr (readonly)
		[5]: alljutsu_upvr (readonly)
		[6]: ingame_upvr (readonly)
	]]
	for _, v_10 in pairs(MovesetsTab_upvr:GetChildren()) do
		if v_10:IsA("ImageLabel") then
			v_10.Image = "http://www.roblox.com/asset/?id=4855243579"
		end
	end
	local save5 = LocalPlayer_upvr.statz.movesetsaving.save5
	for _, v_11 in pairs(MovesetsTab_upvr:GetChildren()) do
		local SOME_34 = save5:FindFirstChild(string.lower(v_11.Name))
		if save5:FindFirstChild(string.lower(v_11.Name)) then
			local Value_26 = SOME_34.Value
			local var221
			local SOME_32 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_26)
			if SOME_32 then
				var221 = SOME_32
			else
				var221 = tbl_upvr[Value_26]
			end
			if var221 then
				local Value_33 = SOME_34.Value
				var221 = nil
				local var224 = var221
				local SOME_30 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_33)
				if SOME_30 then
					var224 = SOME_30
				else
					var224 = tbl_upvr[Value_33]
				end
				if var224:FindFirstChild("img") then
					local Value_12 = SOME_34.Value
					local var227
					local SOME_28 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_12)
					if SOME_28 then
						var227 = SOME_28
					else
						var227 = tbl_upvr[Value_12]
					end
					v_11.Image = var227.img.Texture
				end
			end
		end
	end
	if alljutsu_upvr:FindFirstChild(save5.c.Value) then
		MovesetsTab_upvr.C.Image = alljutsu_upvr:FindFirstChild(save5.c.Value).img.Texture
	end
	local Value_18 = save5.rightarmsword.Value
	local var230
	local SOME_26 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_18)
	if SOME_26 then
		var230 = SOME_26
	else
		var230 = tbl_upvr[Value_18]
	end
	if var230 then
		local Value_16 = save5.rightarmsword.Value
		local var233
		local SOME_6 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_16)
		if SOME_6 then
			var233 = SOME_6
		else
			var233 = tbl_upvr[Value_16]
		end
		MovesetsTab_upvr.wep.Image = var233.img.Texture
	end
	local Value_14 = save5.throwable.Value
	local var236
	local SOME_23 = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_14)
	if SOME_23 then
		var236 = SOME_23
	else
		var236 = tbl_upvr[Value_14]
	end
	if var236 then
		MovesetsTab_upvr.E.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save5.throwable.Value).Image
	end
	local Value_11 = save5.throwable2.Value
	local var239
	local SOME = ReplicatedStorage_upvr.saber.powers:FindFirstChild(Value_11)
	if SOME then
		var239 = SOME
	else
		var239 = tbl_upvr[Value_11]
	end
	if var239 then
		MovesetsTab_upvr.e2.Image = ingame_upvr.Menu.WeaponsTab:FindFirstChild(save5.throwable2.Value).Image
	end
end)